"""Read archived data only; rebuild the 22-instance paper summaries. No solver runs."""
from pathlib import Path
import json,ast,collections,math,hashlib,re
import numpy as np
ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'数据';BASE=SRC/'实验结果';OUT=SRC/'论文汇总';OUT.mkdir(exist_ok=True)
ALGS=['GA','WOA','GLO','ESTA','HCHAO0','HCHAO1','HCHAO']
ids=[f'{m}_{n}' for m in [4,5] for n in [5,10,20,30,40,50,60,70,80,90,100]]
def rankdata(a):
    a = np.asarray(a)
    order = np.argsort(a)
    ranks = np.zeros(len(a))
    k = 0
    while k < len(a):
        j = k + 1
        while j < len(a) and a[order[j]] == a[order[k]]:
            j += 1
        ranks[order[k:j]] = (k + 1 + j) / 2
        k = j
    return ranks

def signed_rank(h, o):
    d = o - h
    d[np.isclose(o, h, rtol=1e-10, atol=1e-09)] = 0
    nz = d[d != 0]
    r = rankdata(abs(nz))
    weights = np.rint(2 * r).astype(int)
    obs = int(weights[nz > 0].sum())
    counts = [1]
    for w in weights:
        new = [0] * (len(counts) + w)
        for i, c in enumerate(counts):
            new[i] += c
            new[i + w] += c
        counts = new
    return dict(plus=int(sum(d > 0)), equal=int(sum(d == 0)), minus=int(sum(d < 0)), R_plus=float(r[nz > 0].sum()), R_minus=float(r[nz < 0].sum()), p=min(1.0, 2 * min(sum(counts[:obs + 1]), sum(counts[obs:])) / 2 ** len(nz)))

def holm(p):
    order = np.argsort(p)
    out = np.zeros(len(p))
    last = 0
    for rank, i in enumerate(order):
        last = max(last, (len(p) - rank) * p[i])
        out[i] = min(1, last)
    return out

def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def save(name,obj):(OUT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
summary={};raw=[];representatives={}
for case in ids:
 summary[case]={}
 for alg in ALGS:
  records=[read(BASE/'compare'/f'{alg}_{case}_v00_r{r:02d}.json') for r in range(1,11)]
  y=np.array([r['best_c_sum'] for r in records]);best=int(y.argmin())
  summary[case][alg]=dict(BST=float(y.min()),AVG=float(y.mean()),VAR=float(y.var(ddof=1)),time=float(np.mean([r['cpu_time'] for r in records])))
  for r in records:
   raw.append(dict(dataset=case,algorithm=alg,repeat=r['job']['repeat'],seed=r['job']['seed'],best_c_sum=r['best_c_sum'],cpu_time=r['cpu_time']))
  if case in ['5_5','5_50','5_100']:
   r=records[best];representatives[f'{case}/{alg}']=dict(best_repeat=best+1,best_c_sum=r['best_c_sum'],time_curve=r['time_curve'],convergence_curve=r['convergence_curve'],all_10_scores=y.tolist())
old=read(SRC/'统计输入/analysis22.json')
for c in ids:
 for a in ALGS:
  for k in ['BST','AVG','VAR','time']:assert np.isclose(summary[c][a][k],old['summary'][c][a][k],rtol=1e-12,atol=1e-10),(c,a,k)
tests=[];fried=[]
for metric in ['BST','AVG','VAR']:
 h=np.array([summary[i]['HCHAO'][metric] for i in ids])
 for alg in ALGS[:-1]:
  o=np.array([summary[i][alg][metric] for i in ids]);tests.append(dict(algorithm=alg,metric=metric,**signed_rank(h,o)))
 matrix=np.array([[summary[i][a][metric] for a in ALGS] for i in ids]);ranks=np.array([rankdata(row) for row in matrix]);n,k=matrix.shape
 tie=sum(sum(c**3-c for c in collections.Counter(row).values()) for row in matrix)
 stat=(12/(n*k*(k+1))*sum(ranks.sum(axis=0)**2)-3*n*(k+1))/(1-tie/(n*k*(k*k-1)))
 fried.append(dict(metric=metric,statistic=float(stat),ranks=dict(zip(ALGS,ranks.mean(axis=0).tolist()))))
for r in tests:
 previous=next(o for o in old['tests'] if o['algorithm']==r['algorithm'] and o['metric']==r['metric'])
 for k in ['plus','equal','minus','R_plus','R_minus','p']:assert np.isclose(r[k],previous[k],rtol=1e-12)
 r['significant_at_0.05']=bool(r['p']<.05)
doe={};snapshot=read(SRC/'统计输入/analysis.json')
for alg in ['HCHAO','GA','WOA','GLO','ESTA']:
 rows=[read(p) for p in (BASE/'doe').glob(f'{alg}_*.json')];doe[alg]=[]
 for v in sorted({r['job']['variant'] for r in rows}):
  group=[r for r in rows if r['job']['variant']==v];assert len(group)==10
  item=dict(trial=v,parameters=group[0]['job']['parameters'],AVG=float(np.mean([r['best_c_sum'] for r in group])))
  assert np.isclose(item['AVG'],snapshot['doe'][alg][v-1]['AVG'],rtol=1e-12)
  doe[alg].append(item)
chaos=[]
for v in range(11):
 rows=[read(p) for p in (BASE/'chaos').glob(f'HCHAO_5_50_v{v:02d}_*.json')];assert len(rows)==10
 y=np.array([r['best_c_sum'] for r in rows]);item=dict(removed=v,AVG=float(y.mean()),SD=float(y.std(ddof=1)))
 assert np.isclose(item['AVG'],snapshot['chaos'][v]['AVG'],rtol=1e-12);chaos.append(item)
gurobi=[]
for case in ids:
 if int(case.split('_')[1])>50:continue
 r=read(BASE/'gurobi'/f'{case}.json');h=summary[case]['HCHAO'];optimal=r['status']=='OPTIMAL'
 gurobi.append(dict(dataset=case,status=r['status'],objective=r.get('objective'),paper_objective='—' if r.get('objective') is None else f"{r['objective']:.2f}"+('' if optimal else '*'),raw_runtime=r.get('runtime'),paper_runtime=r['runtime'] if optimal else 1800,HCHAO_BST=h['BST'],HCHAO_AVG=h['AVG'],HCHAO_raw_mean_time=h['time'],HCHAO_paper_budget=int(case.split('_')[1]),solver_parameters=r.get('solver_parameters')))
inputs=[r for r in read(SRC/'统计输入/manifest.json') if r['id'] in ids]
save('算例清单22.json',inputs);save('表3-4及3-8至3-11_DOE.json',doe);save('表3-5_混沌映射消融.json',chaos)
save('表3-6_Gurobi与HCHAO.json',gurobi);save('表3-7_算法参数.json',read(BASE/'selected_parameters.json'))
save('表3-12至3-14_BST_AVG_VAR.json',summary);save('表3-15_Wilcoxon_未作Holm校正.json',tests);save('表3-16_Friedman.json',fried)
save('图3-8和3-9_收敛与箱线数据.json',representatives);save('算法对比1540次运行索引.json',raw)
print('Verified 1540 comparison, 630 DOE and 110 chaos runs; rebuilt 22-instance summaries. No experiments executed.')
