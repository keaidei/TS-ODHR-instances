function create22()
% 只生成论文22个算例，写入“数据/重新生成算例”；不会覆盖归档输入或实验结果。
base=fileparts(mfilename('fullpath'));
project=fullfile(base,'MATLAB');
addpath(fullfile(project,'data'),fullfile(project,'problem'),fullfile(project,'experiments'));
out=fullfile(fileparts(base),'数据','重新生成算例');
if ~isfolder(out), mkdir(out); end
if ~isfolder(fullfile(out,'json')), mkdir(fullfile(out,'json')); end
for edge_count=[4 5]
    for task_count=[5 10 20 30 40 50 60 70 80 90 100]
        id=sprintf('%d_%d',edge_count,task_count);
        seed=20260924+edge_count*1000+task_count;
        target=fullfile(out,[id '.mat']);
        if isfile(target)
            ds=load(target);
            assert(ds.seed==seed,'Existing seed mismatch');
        else
            rng(seed,'twister');
            [m,M,D_num,D,b,B,n,T]=creat_data(edge_count,task_count,task_count);
            protocol='X3-20260924-v1';
            save(target,'m','M','D_num','D','b','B','n','T','seed','protocol');
            ds=load(target);
        end
        x3_validate_data(ds);
        ds.T=fixLastPredecessorSDEV(ds.T);
        x3_write_json(fullfile(out,'json',[id '.json']),ds);
        fprintf('Generated/validated %s\n',id);
    end
end
fprintf('Output: %s\n',out);
end
