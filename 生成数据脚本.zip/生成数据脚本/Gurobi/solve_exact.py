"""Finite MIP equivalent to X3 device/mode/resource constraints.

Only reachable device pairs and legal modes are instantiated. No infinite
coefficients, no warm start, Gurobi defaults except TimeLimit and log output.
The list decoder is not imposed on the MIP: it can insert into earlier gaps.
"""
from __future__ import annotations
import argparse, hashlib, itertools, json, math, sys, time, os, traceback, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'vendor'))
# This exact predecessor used the identical model/search settings. Only reuse
# its independently validated solutions, never arbitrary changed versions.
LEGACY_VALIDATED_HASH='8e07beb65f2ddf64c96c482f0cc9d1d21bea607c16ee1279a915bb5dd429874e'

def as_list(value):
    return value if isinstance(value,list) else ([] if value is None else [value])

def normalize(ds):
    devices={int(d['id']):d for d in as_list(ds['D'])}
    operations=[]; lookup={}; sinks=[]
    for u,t in enumerate(as_list(ds['T']),1):
        ops=as_list(t['O'])
        for v,o in enumerate(ops,1):
            q=len(operations); lookup[u,v]=q
            modes={int(d):list(map(int,as_list(md['mu']))) for d,md in zip(as_list(o['SDEV']),as_list(o['mode']))}
            operations.append(dict(o,task=u,operation=v,modes=modes))
        sinks.append(len(operations)-1)
    edges=[]
    for q,o in enumerate(operations):
        for pre in as_list(o['SIN']): edges.append((lookup[o['task'],int(pre)],q))
    return devices,operations,edges,sinks

def build_model(ds,limit=1800,log=None):
    import gurobipy as gp
    from gurobipy import GRB
    devices,ops,edges,sinks=normalize(ds)
    # A serial feasible schedule has length bounded by this sum: all maximum
    # legal processing times + all maximum reachable edge delays. This
    # bounds at least one global optimum (left-shift an optimal orientation).
    horizon=sum(max(o['cal']/(devices[d]['c']*mu) for d,ms in o['modes'].items() for mu in ms) for o in ops)
    for p,q in edges:
        delays=[ops[p]['data']/ds['b'][i-1][j-1] for i in ops[p]['modes'] for j in ops[q]['modes'] if ds['B'][i-1][j-1]]
        if not delays: raise ValueError('No reachable device pair on dependency')
        horizon+=max(delays)
    horizon=max(horizon,1.)
    model=gp.Model('TS_ODHR_X3'); model.Params.TimeLimit=limit
    if log: model.Params.LogFile=str(log)
    S=model.addVars(len(ops),lb=0,ub=horizon,name='S')
    C=model.addVars(len(ops),lb=0,ub=horizon,name='C')
    y={}; z={}; resource={}; locks={}
    for q,o in enumerate(ops):
        for d,mus in o['modes'].items():
            y[q,d]=model.addVar(vtype=GRB.BINARY,name=f'y_{q}_{d}')
            for mu in mus: z[q,d,mu]=model.addVar(vtype=GRB.BINARY,name=f'z_{q}_{d}_{mu}')
            model.addConstr(gp.quicksum(z[q,d,mu] for mu in mus)==y[q,d])
            if devices[d]['type']==3:
                for j in range(1,int(devices[d]['mi'])+1):
                    resource[q,d,j]=model.addVar(vtype=GRB.BINARY,name=f'r_{q}_{d}_{j}')
                    model.addConstr(resource[q,d,j]<=y[q,d]); locks[q,d,j]=resource[q,d,j]
                model.addConstr(gp.quicksum(resource[q,d,j] for j in range(1,int(devices[d]['mi'])+1))==gp.quicksum(mu*z[q,d,mu] for mu in mus))
            else:
                # All blocks share the same full-device lock, one is enough.
                locks[q,d,1]=y[q,d]
        model.addConstr(gp.quicksum(y[q,d] for d in o['modes'])==1)
        model.addConstr(C[q]-S[q]==gp.quicksum(o['cal']/(devices[d]['c']*mu)*z[q,d,mu] for d,ms in o['modes'].items() for mu in ms))
    for p,q in edges:
        for i in ops[p]['modes']:
            for j in ops[q]['modes']:
                if not ds['B'][i-1][j-1]:
                    model.addConstr(y[p,i]+y[q,j]<=1)
                else:
                    delay=ops[p]['data']/ds['b'][i-1][j-1]
                    # H+delay also deactivates the constraint when C_p=H.
                    model.addConstr(S[q]>=C[p]+delay-(horizon+delay)*(2-y[p,i]-y[q,j]))
    for d in devices:
        candidates=[q for q,o in enumerate(ops) if d in o['modes']]
        blocks=range(1,int(devices[d]['mi'])+1) if devices[d]['type']==3 else [1]
        for p,q in itertools.combinations(candidates,2):
            order=model.addVar(vtype=GRB.BINARY,name=f'order_{p}_{q}_{d}')
            for j in blocks:
                a,b=locks[p,d,j],locks[q,d,j]
                model.addConstr(C[p]<=S[q]+horizon*(3-a-b-order))
                model.addConstr(C[q]<=S[p]+horizon*(2-a-b+order))
    model.setObjective(gp.quicksum(C[q] for q in sinks),GRB.MINIMIZE)
    model.update()
    return model,(devices,ops,edges,sinks,S,C,y,z,resource),horizon

def validate_solution(ds,solution,tol=1e-5):
    devices,ops,edges,sinks=normalize(ds)
    def check(condition,kind,**details):
        if not condition:
            raise AssertionError(json.dumps(dict(check=kind,tolerance=tol,**details),ensure_ascii=False))
    check(len(solution)==len(ops),'operation_count',actual=len(solution),expected=len(ops))
    for q,(o,s) in enumerate(zip(ops,solution)):
        d=s['device']; mu=s['mu']; blocks=as_list(s['blocks'])
        check(d in o['modes'] and mu in o['modes'][d],'device_mode',operation=q,solution=s)
        check(len(blocks)==mu and len(set(blocks))==mu,'block_count',operation=q,solution=s)
        check(all(1<=j<=devices[d]['mi'] for j in blocks),'block_range',operation=q,solution=s)
        check(math.isfinite(s['start']) and math.isfinite(s['finish']),'finite_time',operation=q,solution=s)
        check(s['start']>=-tol,'nonnegative_start',operation=q,solution=s)
        expected=o['cal']/(mu*devices[d]['c'])
        check(abs(s['finish']-s['start']-expected)<=tol,'duration',operation=q,solution=s,expected=expected,residual=s['finish']-s['start']-expected)
    for p,q in edges:
        a,b=solution[p],solution[q]; i,j=a['device'],b['device']
        check(bool(ds['B'][i-1][j-1]),'connectivity',predecessor=a,successor=b)
        required=a['finish']+ops[p]['data']/ds['b'][i-1][j-1]
        check(b['start']+tol>=required,'precedence',predecessor=a,successor=b,violation=required-b['start'])
    for a,b in itertools.combinations(solution,2):
        if a['device']!=b['device']: continue
        d=devices[a['device']]
        if d['type']<=2 or set(as_list(a['blocks']))&set(as_list(b['blocks'])):
            check(a['finish']<=b['start']+tol or b['finish']<=a['start']+tol,'resource_overlap',first=a,second=b,violation=min(a['finish']-b['start'],b['finish']-a['start']))
    return sum(solution[q]['finish'] for q in sinks)

def polish_numerical_schedule(model,ds,solution,values,horizon):
    """Fix discrete choices exactly; repair only bounded numerical time errors.

    The MIP search is unchanged. This separate LP has its own recorded overhead.
    No validation tolerance is relaxed and no device/block/order is changed.
    """
    import gurobipy as gp
    devices,ops,edges,_=normalize(ds)
    integer_error=max((abs(values[v.VarName]-round(values[v.VarName]))
                       for v in model.getVars() if v.VType!='C'),default=0.)
    if integer_error>model.Params.IntFeasTol:
        raise ValueError('Discrete values exceed solver integrality tolerance; not a numerical timing repair')
    max_delay=max((ops[p]['data']/ds['b'][solution[p]['device']-1][solution[q]['device']-1]
                   for p,q in edges),default=0.)
    # At most three near-integer terms occur in a big-M resource constraint.
    noise_bound=3*(horizon+max_delay)*integer_error+10*model.Params.FeasibilityTol
    validate_solution(ds,solution,tol=noise_bound) # gate only; final check stays 1e-5
    started=time.perf_counter()
    fixed=model.copy()
    try:
        fixed.Params.OutputFlag=0
        fixed.Params.TimeLimit=30
        fixed.Params.FeasibilityTol=1e-9
        for v in fixed.getVars():
            if v.VType!='C':
                value=round(values[v.VarName]); v.LB=value; v.UB=value; v.VType=gp.GRB.CONTINUOUS
        shift_limit=(len(ops)+1)*noise_bound+1e-5
        for q,s in enumerate(solution):
            v=fixed.getVarByName(f'S[{q}]')
            v.LB=max(v.LB,s['start'],0.)
            v.UB=min(v.UB,s['start']+shift_limit)
        fixed.optimize()
        if fixed.Status!=gp.GRB.OPTIMAL:
            raise ValueError(f'Fixed-choice timing LP did not solve optimally: status {fixed.Status}')
        corrected=[dict(s,start=fixed.getVarByName(f'S[{q}]').X,
                        finish=fixed.getVarByName(f'C[{q}]').X) for q,s in enumerate(solution)]
        objective=validate_solution(ds,corrected)
        return corrected,objective,dict(method='fixed_integer_timing_LP',seconds=time.perf_counter()-started,
            max_integer_error=integer_error,numerical_gate=noise_bound,
            maximum_time_change=max(max(abs(a[k]-b[k]) for k in ['start','finish']) for a,b in zip(solution,corrected)))
    finally:
        fixed.dispose()

def solve(ds,limit=1800,log=None):
    import gurobipy as gp
    started=time.perf_counter(); model,parts,H=build_model(ds,limit,log)
    built=time.perf_counter(); model.optimize()
    devices,ops,edges,sinks,S,C,y,z,r=parts
    names={2:'OPTIMAL',3:'INFEASIBLE',4:'INF_OR_UNBD',5:'UNBOUNDED',9:'TIME_LIMIT',11:'INTERRUPTED',13:'SUBOPTIMAL'}
    result=dict(status=names.get(model.Status,str(model.Status)),status_code=model.Status,
        runtime=model.Runtime,build_time=built-started,wall_time=time.perf_counter()-started,
        solutions=model.SolCount,variables=model.NumVars,constraints=model.NumConstrs,
        horizon=H,gurobi_version=list(gp.gurobi.version()),objective=None,bound=None,gap=None,solution=None)
    if math.isfinite(model.ObjBound): result['bound']=model.ObjBound
    if model.SolCount:
        solution=[]
        for q,o in enumerate(ops):
            d=next(d for d in o['modes'] if y[q,d].X>.5)
            mu=next(mu for mu in o['modes'][d] if z[q,d,mu].X>.5)
            blocks=[j for j in range(1,int(devices[d]['mi'])+1) if r[q,d,j].X>.5] if devices[d]['type']==3 else list(range(1,mu+1))
            solution.append(dict(task=o['task'],operation=o['operation'],device=d,mu=mu,blocks=blocks,start=S[q].X,finish=C[q].X))
        try:
            objective=validate_solution(ds,solution)
            assert abs(objective-model.ObjVal)<1e-4*max(1,abs(objective)), 'Objective mismatch between extracted schedule and solver'
        except Exception as original_error:
            diagnostic=Path(log).with_suffix('.diagnostic.json') if log else Path('validation_failure.diagnostic.json')
            values={v.VarName:v.X for v in model.getVars()}
            diagnostic.write_text(json.dumps(dict(result=result,candidate_solution=solution,solver_objective=model.ObjVal,
                error=traceback.format_exc(),quality={k:model.getAttr(k) for k in ['ConstrVio','BoundVio','IntVio']},
                values=values),indent=2),encoding='utf-8')
            model.write(str(diagnostic.with_suffix('.sol')))
            try:
                reason=json.loads(str(original_error))
                if reason.get('check') not in {'duration','precedence','resource_overlap','nonnegative_start'}:
                    raise ValueError('Validation failure is not eligible for numerical timing repair')
                solution,objective,repair=polish_numerical_schedule(model,ds,solution,values,H)
                result.update(numerical_repair=repair,original_validation_error=reason,solver_objective=model.ObjVal)
                print('Numerical timing repair passed:',json.dumps(repair),flush=True)
            except Exception:
                model.dispose()
                raise
        reported_objective=objective if 'numerical_repair' in result else model.ObjVal
        gap=abs(reported_objective-model.ObjBound)/abs(reported_objective) if reported_objective else (0. if model.ObjBound==0 else None)
        result.update(objective=reported_objective,gap=gap,solution=solution,validated=True)
        if 'numerical_repair' in result and result['status']=='OPTIMAL':
            if not (gap is not None and gap<=model.Params.MIPGap or abs(reported_objective-model.ObjBound)<=model.Params.MIPGapAbs):
                result.update(status='SUBOPTIMAL',status_code=13)
    result['wall_time']=time.perf_counter()-started
    model.dispose()
    return result

def fixture(kind=3,tasks=1):
    D=[dict(id=1,type=kind,mi=2,c=1)]+[dict(id=i+2,type=1,mi=1,c=1) for i in range(tasks)]
    T=[]
    for i in range(tasks):
        local=i+2
        def op(v,cal,data,pre,suc,d,mu):
            return dict(id=v,cal=cal,data=data,SIN=pre,SOUT=suc,SDEV=[d],mode=[dict(mu=mu)])
        # Only a single legal block for two-task occupancy test.
        mus=[1,2] if tasks==1 else [1]
        T.append(dict(O=[op(1,1,2,[],[2],local,[1]),op(2,4,2,[1],[3],1,mus),op(3,1,0,[2],[],local,[1])]))
    size=tasks+1; B=[[int(i==j or i==0 or j==0) for j in range(size)] for i in range(size)]
    b=[[1000 if i==j else (2 if B[i][j] else 0) for j in range(size)] for i in range(size)]
    return dict(m=1,M=tasks,n=tasks,D_num=size,D=D,T=T,B=B,b=b,protocol='test-fixture')

def self_test():
    results=[]
    for kind,tasks,expected in [(3,1,6.),(3,2,16.),(2,2,20.)]:
        ds=fixture(kind,tasks); r=solve(ds,30)
        assert r['status']=='OPTIMAL' and abs(r['objective']-expected)<1e-5,(kind,tasks,r['objective'])
        bad=[dict(x) for x in r['solution']]; bad[0]['finish']+=1
        try: validate_solution(ds,bad)
        except AssertionError: pass
        else: raise AssertionError('Invalid duration was accepted')
        results.append(dict(device_type=kind,tasks=tasks,objective=r['objective'],expected=expected))
    # Reuse the small real MATLAB-decoded fixture as a feasibility cross-check.
    bridge=ROOT/'results'/'matlab_fixture.json'
    if bridge.exists():
        b=json.loads(bridge.read_text(encoding='utf-8'))
        value=validate_solution(b['dataset'],b['solution'])
        assert abs(value-b['objective'])<1e-6
        model,parts,_=build_model(b['dataset'],30)
        _,ops,_,_,S,C,y,z,r=parts
        for q,s in enumerate(b['solution']):
            model.addConstr(S[q]==s['start']); model.addConstr(C[q]==s['finish'])
            model.addConstr(y[q,s['device']]==1); model.addConstr(z[q,s['device'],s['mu']]==1)
            for j in as_list(s['blocks']):
                if (q,s['device'],j) in r: model.addConstr(r[q,s['device'],j]==1)
        model.optimize(); assert model.SolCount>0
        model.dispose(); results.append(dict(matlab_schedule_mip_feasible=True,objective=value))
    out=ROOT/'results'/'gurobi_validation.json'; out.parent.mkdir(exist_ok=True)
    out.write_text(json.dumps(dict(passed=True,tests=results),indent=2),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--self-test',action='store_true')
    ap.add_argument('--instances',nargs='*'); ap.add_argument('--time-limit',type=float,default=1800)
    ap.add_argument('--profile',default='formal'); args=ap.parse_args()
    if args.self_test: self_test(); return
    if args.profile=='formal' and args.time_limit!=1800: ap.error('Use a different profile for non-1800s runs')
    ids=args.instances or [f'{m}_{n}' for m in [4,5,6] for n in [5,10,20,30,40,50]]
    out=ROOT/'results'/args.profile/'gurobi'; out.mkdir(parents=True,exist_ok=True)
    for id in ids:
        src=ROOT/'data'/'json'/f'{id}.json'; dest=out/f'{id}.json'
        data_hash=hashlib.sha256(src.read_bytes()).hexdigest()
        code_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
        if dest.exists():
            old=json.loads(dest.read_text(encoding='utf-8'))
            if old.get('error'):
                archive=out/'archive'/f'{id}_{time.time_ns()}'
                archive.mkdir(parents=True)
                for artifact in [dest,out/f'{id}.log',out/f'{id}.diagnostic.json',out/f'{id}.diagnostic.sol']:
                    if artifact.exists(): shutil.copy2(artifact,archive/artifact.name)
                print('Retrying prior environment/solver error',id,'; previous evidence archived in',archive)
            elif (old.get('data_hash')==data_hash and old.get('time_limit')==args.time_limit
                  and old.get('profile')==args.profile and old.get('dataset')==id
                  and (old.get('code_hash')==code_hash or
                       (old.get('code_hash')==LEGACY_VALIDATED_HASH and old.get('validated')))):
                if old.get('solution'):
                    checked=validate_solution(json.loads(src.read_text(encoding='utf-8')),old['solution'])
                    assert abs(checked-old['objective'])<=1e-4*max(1,abs(checked)), 'Checkpoint objective mismatch'
                print('Reusing checked result',id)
                continue
            else: raise ValueError(f'Checkpoint differs: {dest}')
        try:
            # Native Gurobi log filenames may reject non-ASCII absolute paths.
            # A basename inside the already-existing output cwd avoids this.
            previous=Path.cwd()
            try:
                os.chdir(out)
                result=solve(json.loads(src.read_text(encoding='utf-8')),args.time_limit,Path(f'{id}.log'))
            finally:
                os.chdir(previous)
        except Exception as ex:
            result=dict(status='ERROR',error=f'{type(ex).__name__}: {ex}',traceback=traceback.format_exc(),objective=None)
        result.update(dataset=id,time_limit=args.time_limit,profile=args.profile,data_hash=data_hash,code_hash=code_hash)
        dest.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
        if result.get('error'):
            print(result['error']); raise SystemExit(2)

if __name__=='__main__': main()
