"""Isolated, explicitly recorded low-memory Gurobi continuation."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import traceback
import solve_exact as solver

CONFIG = dict(Threads=20, NodefileStart=0.25)

def read(path):
    return json.loads(path.read_text(encoding='utf-8'))

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--instances',nargs='+')
    ap.add_argument('--test',action='store_true')
    ap.add_argument('--worker',action='store_true')
    ap.add_argument('--pilot',action='store_true')
    args=ap.parse_args()
    limit=60 if args.test else 1800
    profile='memory_smoke_20t_unlimited_d' if args.test else ('pilot_20t_unlimited_d' if args.pilot else 'formal')
    root=solver.ROOT
    out=root/'results'/profile/'gurobi'
    out.mkdir(parents=True,exist_ok=True)
    ids=args.instances or [f'{m}_{n}' for m in [4,5,6] for n in [5,10,20,30,40,50]]
    if any(i not in {f'{m}_{n}' for m in [4,5,6] for n in [5,10,20,30,40,50]} for i in ids):
        ap.error('Unknown instance')
    license_path=Path('D:/Program Files (x86)/gurobi/win64/bin/gurobi.lic')
    if not os.environ.get('GRB_LICENSE_FILE') and license_path.exists():
        os.environ['GRB_LICENSE_FILE']=str(license_path)
    core_hash=hashlib.sha256(Path(solver.__file__).read_bytes()).hexdigest()
    wrapper_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if not args.worker:
        for instance in ids:
            command=[sys.executable,str(Path(__file__).resolve()),'--worker','--instances',instance]
            if args.test: command.append('--test')
            if args.pilot: command.append('--pilot')
            print('Starting isolated instance',instance,flush=True)
            process=subprocess.run(command)
            if process.returncode:
                print('Stopped after instance error; inspect saved traceback.',flush=True)
                return process.returncode
        return 0
    if len(ids)!=1: ap.error('Worker requires exactly one instance')
    instance=ids[0]
    src=root/'data/json'/f'{instance}.json'
    data_hash=hashlib.sha256(src.read_bytes()).hexdigest()
    dest=out/f'{instance}.json'
    ds=read(src)
    if dest.exists():
        old=read(dest)
        if not old.get('error'):
            if old.get('data_hash')!=data_hash or old.get('time_limit')!=limit:
                raise ValueError('Existing result has different data/budget')
            if old.get('code_hash') not in {core_hash,solver.LEGACY_VALIDATED_HASH}:
                raise ValueError('Existing result has unreviewed source hash')
            expected_parameters=dict(CONFIG,NodefileDir=str(Path('D:/X3_Gurobi_Nodefiles')/profile/instance),Seed=0)
            if old.get('execution_mode')!='isolated_20t_unlimited_d_disk' or old.get('solver_parameters')!=expected_parameters or old.get('runner_hash')!=wrapper_hash:
                raise ValueError('Low-memory runner/configuration changed; archive old run before retry')
            if old.get('solution'):
                objective=solver.validate_solution(ds,old['solution'])
                assert abs(objective-old['objective'])<=1e-4*max(1,abs(objective))
            elif old.get('objective') is not None:
                raise ValueError('Objective without validated schedule')
            print('Reusing existing result (original settings preserved):',instance,flush=True)
            return 0
        archive=out/'archive'/f'{instance}_{time.time_ns()}'
        archive.mkdir(parents=True)
        for p in out.glob(f'{instance}.*'):
            if p.is_file(): shutil.copy2(p,archive/p.name)
    os.chdir(out)
    # Relative ASCII paths avoid native-library path encoding issues.
    nodes=Path('D:/X3_Gurobi_Nodefiles')/profile/instance
    nodes.mkdir(parents=True,exist_ok=True)
    original_build=solver.build_model
    def build(*a,**kw):
        model,parts,h=original_build(*a,**kw)
        for key,value in CONFIG.items(): model.setParam(key,value)
        model.Params.Seed=0
        assert model.Params.SoftMemLimit >= 1e90, "Unexpected finite SoftMemLimit"
        print("SoftMemLimit: unlimited (verified default)",flush=True)
        model.Params.NodefileDir=str(nodes)
        return model,parts,h
    solver.build_model=build
    began=time.perf_counter()
    try:
        result=solver.solve(ds,limit,Path(f'{instance}.log'))
        if result.get('status_code')==17:
            result['status']='MEM_LIMIT'
        result['termination_reason']='soft_memory_limit' if result.get('status_code')==17 else result['status']
    except Exception as ex:
        result=dict(status='ERROR',error=f'{type(ex).__name__}: {ex}',traceback=traceback.format_exc(),objective=None)
    result.update(dataset=instance,time_limit=limit,profile=profile,data_hash=data_hash,
                  code_hash=core_hash,runner_hash=wrapper_hash,solver_parameters=dict(CONFIG,NodefileDir=str(nodes),Seed=0),
                  soft_memory_limit='unlimited_default_verified',execution_mode='isolated_20t_unlimited_d_disk',process_elapsed=time.perf_counter()-began)
    temporary=dest.with_suffix('.tmp.json')
    temporary.write_text(json.dumps(result,indent=2,allow_nan=False),encoding='utf-8')
    temporary.replace(dest)
    print(instance,result['status'],result.get('error',''),flush=True)
    return 2 if result.get('error') else 0

if __name__=='__main__':
    raise SystemExit(main())
