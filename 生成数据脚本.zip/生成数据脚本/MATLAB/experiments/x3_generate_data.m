function manifest=x3_generate_data()
% Immutable, seeded 33-instance benchmark; never silently regenerate a file.
root=fileparts(fileparts(mfilename('fullpath')));
edges=[4 5 6]; tasks=[5 10 20 30 40 50 60 70 80 90 100];
manifest=struct('id',{},'m',{},'n',{},'operations',{},'seed',{},'protocol',{}); k=0;
for m=edges
    for n=tasks
        id=sprintf('%d_%d',m,n); seed=20260924+m*1000+n;
        matpath=fullfile(root,'data',[id '.mat']);
        if isfile(matpath)
            ds=load(matpath);
            assert(isfield(ds,'protocol') && strcmp(ds.protocol,'X3-20260924-v1'));
            assert(ds.seed==seed);
        else
            rng(seed,'twister');
            [m,M,D_num,D,b,B,n,T]=creat_data(m,n,n);
            protocol='X3-20260924-v1';
            save(matpath,'m','M','D_num','D','b','B','n','T','seed','protocol');
            ds=load(matpath);
        end
        x3_validate_data(ds);
        % Export repaired candidate sets, exactly as get_problem sees them.
        ds.T=fixLastPredecessorSDEV(ds.T);
        x3_write_json(fullfile(root,'data','json',[id '.json']),ds);
        k=k+1;
        manifest(k)=struct('id',id,'m',m,'n',n,'operations',sum(arrayfun(@(t)numel(t.O),ds.T)), ...
            'seed',seed,'protocol',ds.protocol);
    end
end
writetable(struct2table(manifest),fullfile(root,'data','manifest.csv'));
x3_write_json(fullfile(root,'data','manifest.json'),manifest);
fprintf('Validated and exported %d datasets.\n',numel(manifest));
end
