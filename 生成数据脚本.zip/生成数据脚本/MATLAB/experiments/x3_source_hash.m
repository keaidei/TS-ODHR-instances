function hash=x3_source_hash(root)
files=dir(fullfile(root,'**','*.m'));
names=sort(string(fullfile({files.folder},{files.name})));
md=java.security.MessageDigest.getInstance('SHA-256');
for name=names(:)'
    relative=erase(name,string(root));
    md.update(uint8(unicode2native(char(relative),'UTF-8')));
    md.update(uint8(x3_file_hash(char(name))));
end
md.update(uint8(x3_file_hash(fullfile(root,'experiments','doe_design.json'))));
hash=lower(reshape(dec2hex(typecast(md.digest(),'uint8'),2)',1,[]));
end
