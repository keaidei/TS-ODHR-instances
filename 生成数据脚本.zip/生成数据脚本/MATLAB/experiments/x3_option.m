function value=x3_option(options,name,fallback)
if isfield(options,name), value=options.(name); else, value=fallback; end
end
