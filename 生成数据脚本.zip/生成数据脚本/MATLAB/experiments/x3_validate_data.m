function x3_validate_data(ds)
assert(ds.M==ds.n && numel(ds.D)==ds.m+ds.n);
assert(isequal(ds.b,ds.b') && all(diag(ds.b)==1000));
assert(all(diag(ds.B)==1));
for i=1:numel(ds.D)
    d=ds.D(i); assert(d.c>=1 && d.c<=10);
    if i>ds.m, assert(d.type==1); end
    if d.type==1, assert(d.mi==1); else, assert(ismember(d.mi,2:4)); end
end
assert(all(ds.B(1:ds.m,:)==1,'all'));
assert(isequal(ds.B(ds.m+1:end,ds.m+1:end),eye(ds.n)));
for u=1:ds.n
    O=ds.T(u).O; count=numel(O);
    assert(ismember(count,5:10));
    assert(isequal(O(1).SDEV,ds.m+u) && O(1).cal==1 && O(end).cal==1 && O(end).data==0);
    assert(numel(O(end).SDEV)==1 && O(end).SDEV>ds.m);
    assert(isempty(O(1).SIN) && isempty(O(end).SOUT));
    for v=1:count
        if v<count, assert(O(v).data>=20 && O(v).data<=100); end
        if v>1 && v<count
            assert(O(v).cal>=20 && O(v).cal<=100);
            assert(isequal(sort(O(v).SDEV),[1:ds.m ds.m+u]));
        end
        if v>1, assert(~isempty(O(v).SIN) && all(O(v).SIN<v)); end
        if v<count, assert(~isempty(O(v).SOUT) && all(O(v).SOUT>v)); end
        for pre=O(v).SIN, assert(ismember(v,O(pre).SOUT)); end
        for j=1:numel(O(v).SDEV)
            mu=O(v).mode(j).mu;
            assert(~isempty(mu) && all(mu>=1 & mu<=ds.D(O(v).SDEV(j)).mi));
        end
    end
end
end
