function x3_write_json(path,value)
parent=fileparts(path); if ~isfolder(parent), mkdir(parent); end
fid=fopen(path,'w','n','UTF-8'); assert(fid>=0,'Cannot open %s',path);
cleanup=onCleanup(@() fclose(fid));
fprintf(fid,'%s',jsonencode(value,PrettyPrint=true));
end
