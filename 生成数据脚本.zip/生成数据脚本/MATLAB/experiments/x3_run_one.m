function output=x3_run_one(algorithm,dataset,options,seed,max_time)
% Loading and final validation are excluded; initialization is included.
[lb,ub,dim,~,info,problem]=get_problem([dataset '.mat']);
problem.strict=true;
rng(seed,'twister');
budget=X3Budget(max_time);
% Anonymous closure exposes problem to existing heuristic initialization.
fobj=@(x) budget.evaluate(x,problem);
reason='algorithm_time_limit';
try
    feval(algorithm,max_time,lb,ub,dim,fobj,'heuristic',options);
catch ex
    if ~strcmp(ex.identifier,'X3:TimeLimit'), rethrow(ex); end
    reason='evaluation_time_limit';
end
elapsed=toc(budget.clock);
assert(isfinite(budget.score),'No feasible solution evaluated');
times=[budget.times elapsed]; scores=[budget.scores budget.score];
default_pop=20;
if startsWith(algorithm,'HCHAO') || strcmp(algorithm,'GA'), default_pop=30; end
if strcmp(algorithm,'WOA'), default_pop=50; end
output=build_algorithm_output(algorithm,x3_option(options,'Pop',default_pop),elapsed,max_time, ...
    budget.count,budget.position,budget.score,scores,times,budget.detail);
output.seed=seed; output.parameters=options; output.dataset=dataset;
output.operation_count=info.operation_num; output.stop_reason=reason;
output.protocol='X3-20260924-v1';
output.overshoot_s=max(0,elapsed-max_time);
output.curve_semantics='incumbent improvements plus final observation; not generations';
output.iterations=NaN;
x3_validate_schedule(problem,output.best_detail);
end
