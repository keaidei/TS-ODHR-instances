function x3_validate_schedule(problem,detail)
% Independent assertions on precedence, eligibility, duration and lock overlap.
s=detail.schedule_result; N=numel(s.finish_time); tol=1e-7;
assert(all(isfinite(s.finish_time)) && all(s.start_time>=-tol));
locks=cell(N,1);
for q=1:N
    u=problem.operation_map(2,q); v=problem.operation_map(3,q);
    o=problem.T(u).O(v); d=s.device_of(q); blocks=s.block_of{q};
    a=find(o.SDEV==d,1); assert(~isempty(a));
    assert(ismember(numel(blocks),o.mode(a).mu));
    assert(numel(unique(blocks))==numel(blocks) && all(blocks>=1 & blocks<=problem.D(d).mi));
    expected=o.cal/(problem.D(d).c*numel(blocks));
    assert(abs(s.finish_time(q)-s.start_time(q)-expected)<=tol*max(1,expected));
    for p=o.SIN
        pred=problem.operation_lookup(u,p); from=s.device_of(pred);
        assert(problem.B(from,d)==1);
        arrival=s.finish_time(pred)+problem.T(u).O(p).data/problem.b(from,d);
        assert(s.start_time(q)+tol>=arrival);
    end
    if problem.D(d).type<=2, locks{q}=1:problem.D(d).mi; else, locks{q}=blocks; end
end
for a=1:N
    for b=a+1:N
        if s.device_of(a)==s.device_of(b) && ~isempty(intersect(locks{a},locks{b}))
            assert(s.finish_time(a)<=s.start_time(b)+tol || s.finish_time(b)<=s.start_time(a)+tol, ...
                'Overlapping resource locks');
        end
    end
end
completion=zeros(1,numel(problem.T));
for u=1:numel(problem.T), completion(u)=s.finish_time(problem.operation_lookup(u,numel(problem.T(u).O))); end
assert(abs(sum(completion)-detail.total_task_completion_time)<=tol*max(1,sum(completion)));
end
