﻿function [Best_pos_inner, Best_score_inner, FEs, Best_detail] = ESTA_translation_op(Best_pos_inner, Best_score_inner, BestArchive_inner, SE_inner, Range_inner, beta_inner, fobj_inner, max_time_inner, FEs, Best_detail)
% ESTA_translation_op 执行 ESTA 平移变换并尝试更新当前最优解。
% -------------------------------------------------------------------------
% 额外输入变量说明：
%   BestArchive_inner : 历史最优档案，translation 算子从中抽取方向。
%   beta_inner        : 平移步长控制参数。
%
% 平移公式由 ESTA_op_translate 给出：
%   State1 = Best + beta*r*(Best - Archive_a)
%   State2 = Best + beta*r*(Archive_a - Archive_b)
% 其中 r 属于 [-1,1]。第一类候选沿“当前最好点相对历史点”的方向移动，
% 第二类候选沿两个历史点的差分方向移动，用历史搜索轨迹预测可能的改进方向。
% -------------------------------------------------------------------------

    % 底层算子先选片段，再只在允许维度计算档案差分平移。
    State = ESTA_op_translate(Best_pos_inner, BestArchive_inner, SE_inner, beta_inner);
    State = ESTA_bound_state(State, Range_inner);
    [newBest_pos, newBest_score, FEs, Best_detail] = ...
        ESTA_select_best(State, fobj_inner, max_time_inner, FEs, Best_score_inner, Best_detail);
    if newBest_score < Best_score_inner
        Best_score_inner = newBest_score;
        Best_pos_inner = newBest_pos;
    end
end
