﻿function [Best_pos_inner, Best_score_inner, FEs, Best_detail] = ESTA_select_best(State, fobj_inner, max_time_inner, FEs, current_best_score, Best_detail)
% ESTA_select_best 评价一批状态候选并返回其中最优者。
% -------------------------------------------------------------------------
% 输入变量说明：
%   State              : 候选状态矩阵，每一行是一条连续编码候选解。
%   fobj_inner         : 目标函数句柄。
%   max_time_inner     : 当前算法允许的最大运行时间，配合 toc 做超时保护。
%   FEs                : 已累计的目标函数评价次数。
%   current_best_score : 调用本函数前的全局/局部最好目标值。
%   Best_detail        : 当前最好调度细节，若候选更优则同步更新。
%
% 输出变量说明：
%   Best_pos_inner   : State 中目标值最小的候选位置。
%   Best_score_inner : State 中目标值最小的候选目标值。
%   FEs              : 更新后的评价次数。
%   Best_detail      : 若本批候选刷新当前最好值，则返回对应调度细节。
%
% 算法含义：
%   ESTA 的 rotation/expansion/axesion/translation 算子都会一次生成多个候选点。
%   本函数统一完成“逐个评价 -> 统计 FEs -> 选择最优候选 -> 保存最好调度细节”。
%   若达到 max_time_inner，则停止继续评价，未评价位置保持 Inf。
% -------------------------------------------------------------------------

    SE_inner = size(State, 1);             % 候选状态数量
    fState = inf(SE_inner, 1);             % 每个候选的目标函数值，未评价候选保持 Inf
    for ii = 1:SE_inner
        if toc >= max_time_inner
            break;
        end
        [fState(ii), detail_inner] = fobj_inner(State(ii, :));
        FEs = FEs + 1;
        if fState(ii) < current_best_score || isempty(fieldnames(Best_detail))
            current_best_score = fState(ii);
            Best_detail = detail_inner;
        end
    end

    [Best_score_inner, index] = min(fState);
    Best_pos_inner = State(index, :);
end
