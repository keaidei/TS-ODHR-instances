﻿function State = ESTA_op_axes(Best, SE_inner, delta_inner)
    % ESTA_OP_AXES 坐标轴变换算子。
    % 每个候选解只随机选择一个维度进行扰动：
    %   State1 = Best + delta * e_j * randn .* Best
    %   State2 = Best + delta * e_j * randn .* 1
    % e_j 是只在第 j 维为 1 的坐标轴向量，因此该算子适合做单维精细搜索。
    n = length(Best); % 连续编码维度
    State1 = repmat(Best, SE_inner, 1);
    State2 = repmat(Best, SE_inner, 1);
    for candidate_index = 1:SE_inner
        allowed_indices = select_random_segment_indices(n);
        selected_dimension = allowed_indices(randi(numel(allowed_indices)));
        State1(candidate_index, selected_dimension) = ...
            Best(selected_dimension) + delta_inner * randn() * Best(selected_dimension);

        allowed_indices = select_random_segment_indices(n);
        selected_dimension = allowed_indices(randi(numel(allowed_indices)));
        State2(candidate_index, selected_dimension) = ...
            Best(selected_dimension) + delta_inner * randn();
    end
    State = [State1; State2];
end

