﻿function [Best_pos_inner, Best_score_inner, FEs, Best_detail] = ESTA_axesion_op(Best_pos_inner, Best_score_inner, SE_inner, Range_inner, delta_inner, fobj_inner, max_time_inner, FEs, Best_detail)
% ESTA_axesion_op 执行 ESTA 坐标轴变换并尝试更新当前最优解。
% -------------------------------------------------------------------------
% 变量含义与 ESTA_rotation_op 相同，差别在于本函数调用 axesion 算子。
%
% 坐标轴扰动公式由 ESTA_op_axes 给出：
%   State = Best + delta * e_j * randn .* scale
% 其中 e_j 是只在一个随机维度上为 1 的坐标轴向量。该算子一次只扰动少量
% 维度，适合在当前最优附近做单维细搜索。
% -------------------------------------------------------------------------

    % axesion 先选片段，再从允许维度中保持原算法“一次只扰动一维”。
    State = ESTA_op_axes(Best_pos_inner, SE_inner, delta_inner);
    State = ESTA_bound_state(State, Range_inner);
    [newBest_pos, newBest_score, FEs, Best_detail] = ...
        ESTA_select_best(State, fobj_inner, max_time_inner, FEs, Best_score_inner, Best_detail);
    if newBest_score < Best_score_inner
        Best_score_inner = newBest_score;
        Best_pos_inner = newBest_pos;
    end
end
