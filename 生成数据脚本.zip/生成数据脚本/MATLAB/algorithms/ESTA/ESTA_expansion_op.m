﻿function [Best_pos_inner, Best_score_inner, FEs, Best_detail] = ESTA_expansion_op(Best_pos_inner, Best_score_inner, SE_inner, Range_inner, gamma_inner, fobj_inner, max_time_inner, FEs, Best_detail)
% ESTA_expansion_op 执行 ESTA 扩展变换并尝试更新当前最优解。
% -------------------------------------------------------------------------
% 变量含义与 ESTA_rotation_op 相同，差别在于本函数调用 expansion 算子。
%
% 扩展公式由 ESTA_op_expand 给出：
%   State1 = Best + gamma * randn .* Best
%   State2 = Best + gamma * randn .* 1
% 其中 State1 是按当前解尺度做比例扰动，State2 是按单位尺度做绝对扰动。
% expansion 通常用于扩大搜索范围，补充 rotation 的局部球形搜索。
% -------------------------------------------------------------------------

    % 底层算子先选片段，再在允许维度上执行原两类扩展公式。
    State = ESTA_op_expand(Best_pos_inner, SE_inner, gamma_inner);
    State = ESTA_bound_state(State, Range_inner);
    [newBest_pos, newBest_score, FEs, Best_detail] = ...
        ESTA_select_best(State, fobj_inner, max_time_inner, FEs, Best_score_inner, Best_detail);
    if newBest_score < Best_score_inner
        Best_score_inner = newBest_score;
        Best_pos_inner = newBest_pos;
    end
end
