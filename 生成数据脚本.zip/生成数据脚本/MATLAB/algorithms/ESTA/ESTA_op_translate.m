﻿function State = ESTA_op_translate(Best, BestArchive_inner, SE_inner, beta_inner)
    % ESTA_OP_TRANSLATE 平移变换算子，也对应原 hybrid predictive models。
    % 两类候选：
    %   State1 = Best + beta*r*(Best - Archive_a)
    %   State2 = Best + beta*r*(Archive_a - Archive_b)
    % 其中 r 属于 [-1,1]，BestArchive_inner 保存历史最好点，用差分方向预测新位置。
    half_SE = ceil(SE_inner / 2); % 两类平移候选各生成约一半
    State1 = repmat(Best, half_SE, 1);
    State2 = repmat(Best, half_SE, 1);
    archive_count = size(BestArchive_inner, 1);
    for candidate_index = 1:half_SE
        update_indices = select_random_segment_indices(length(Best));
        archive_index = randi(archive_count);
        random_scale = beta_inner * (-1 + 2 * rand());
        State1(candidate_index, update_indices) = Best(update_indices) + ...
            random_scale .* (Best(update_indices) - ...
            BestArchive_inner(archive_index, update_indices));

        update_indices = select_random_segment_indices(length(Best));
        archive_indices = randi(archive_count, 1, 2);
        random_scale = beta_inner * (-1 + 2 * rand());
        State2(candidate_index, update_indices) = Best(update_indices) + ...
            random_scale .* ( ...
            BestArchive_inner(archive_indices(1), update_indices) - ...
            BestArchive_inner(archive_indices(2), update_indices));
    end
    State = [State1; State2];
end

