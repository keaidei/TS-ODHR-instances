﻿function State = ESTA_op_rotate(Best, SE_inner, alpha_inner)
    % ESTA_OP_ROTATE 旋转变换算子。
    % 公式：State = Best + alpha * Rr * u / ||u||。
    % u 是随机方向向量，Rr 是随机半径，alpha 控制旋转搜索半径。
    n = length(Best);                  % 连续编码维度
    State = repmat(Best, SE_inner, 1);
    for candidate_index = 1:SE_inner
        update_indices = select_random_segment_indices(n);
        u = 2 * rand(1, numel(update_indices)) - 1;
        norm_u = max(norm(u), eps);
        Rr = rand();
        State(candidate_index, update_indices) = Best(update_indices) + ...
            alpha_inner * Rr .* u ./ norm_u;
    end
end

