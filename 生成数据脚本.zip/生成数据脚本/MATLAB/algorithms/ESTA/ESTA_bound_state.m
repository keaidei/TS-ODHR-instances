﻿function State = ESTA_bound_state(State, Range_inner)
% ESTA_bound_state 对 ESTA 候选状态执行随机回弹式边界处理。
% -------------------------------------------------------------------------
% 输入变量说明：
%   State       : 候选状态矩阵，每一行是一条连续编码候选解。
%   Range_inner : 2 x dim 边界矩阵，第一行为下界，第二行为上界。
%
% 输出变量说明：
%   State : 边界修复后的候选状态矩阵。
%
% 边界处理逻辑：
%   对越界维度不直接截断到 lb/ub，而是在该维合法区间内重新随机采样：
%      x_j = lb_j + (ub_j - lb_j) * rand
%   这样可以避免大量候选点堆积在边界上，同时保留 ESTA 原始实现的随机回弹特性。
% -------------------------------------------------------------------------

    SE_inner = size(State, 1);
    Lb = repmat(Range_inner(1, :), SE_inner, 1);
    Ub = repmat(Range_inner(2, :), SE_inner, 1);

    idxLow = State < Lb;                    % 低于下界的位置掩码
    idxHigh = State > Ub;                   % 高于上界的位置掩码

    State(idxLow) = Lb(idxLow) + (Ub(idxLow) - Lb(idxLow)) .* rand(nnz(idxLow), 1);
    State(idxHigh) = Lb(idxHigh) + (Ub(idxHigh) - Lb(idxHigh)) .* rand(nnz(idxHigh), 1);
end
