﻿function [Best_pos_inner, Best_score_inner, FEs, Best_detail] = ESTA_rotation_op(Best_pos_inner, Best_score_inner, SE_inner, Range_inner, alpha_inner, fobj_inner, max_time_inner, FEs, Best_detail)
% ESTA_rotation_op 执行 ESTA 旋转变换并尝试更新当前最优解。
% -------------------------------------------------------------------------
% 输入变量说明：
%   Best_pos_inner   : 当前最优位置。
%   Best_score_inner : 当前最优目标值。
%   SE_inner         : 本次算子生成的候选状态数量。
%   Range_inner      : 2 x dim 边界矩阵。
%   alpha_inner      : 旋转半径控制参数。
%   fobj_inner       : 目标函数句柄。
%   max_time_inner   : 最大运行时间。
%   FEs              : 已累计评价次数。
%   Best_detail      : 当前最好调度细节。
%
% 算子流程：
%   1) ESTA_op_rotate 在当前 Best 周围生成随机方向候选；
%   2) ESTA_bound_state 修复越界候选；
%   3) ESTA_select_best 评价候选并返回本批最优；
%   4) 若本批最优优于当前 Best，则更新 Best_pos_inner/Best_score_inner。
% -------------------------------------------------------------------------

    % 底层算子先选片段，再在允许维度上执行原旋转公式。
    State = ESTA_op_rotate(Best_pos_inner, SE_inner, alpha_inner);
    State = ESTA_bound_state(State, Range_inner);
    [newBest_pos, newBest_score, FEs, Best_detail] = ...
        ESTA_select_best(State, fobj_inner, max_time_inner, FEs, Best_score_inner, Best_detail);
    if newBest_score < Best_score_inner
        Best_score_inner = newBest_score;
        Best_pos_inner = newBest_pos;
    end
end
