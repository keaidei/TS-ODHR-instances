﻿function BestArchive_inner = ESTA_update_BestArchive(Best, BestArchive_inner)
% ESTA_update_BestArchive 更新 ESTA 的历史最优档案。
% -------------------------------------------------------------------------
% 输入变量说明：
%   Best              : 当前迭代得到的最好位置。
%   BestArchive_inner : 历史最好位置档案，第一行为最近一次记录。
%
% 输出变量说明：
%   BestArchive_inner : 更新后的档案矩阵。
%
% 档案规则：
%   1) 若当前 Best 与档案首行不同，则把 Best 插入到档案头部；
%   2) 最多保留 archiveSize=100 条记录，超过部分从尾部删除；
%   3) translation 算子会从该档案中随机抽取历史方向，用于生成预测性位移。
% -------------------------------------------------------------------------

    if ~isequal(Best, BestArchive_inner(1, :))
        BestArchive_inner = [Best; BestArchive_inner]; %#ok<AGROW>
    end
    archiveSize = 100;
    if size(BestArchive_inner, 1) > archiveSize
        BestArchive_inner(archiveSize+1:end, :) = [];
    end
end
