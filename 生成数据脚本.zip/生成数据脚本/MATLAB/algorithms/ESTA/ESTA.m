function output = ESTA(max_time, lb, ub, dim, fobj, init_mode, options)
    if nargin < 7, options = struct(); end
% ESTA 原始 ESTA 状态转移算法的时间终止适配版
% -------------------------------------------------------------------------
% 本文件参考 1.ESTA-main.zip 中 ESTA/ESTA.m 及其基础模块：
%   rotation.m、expansion.m、axesion.m、translation.m
%   ESTA_op_rotate.m、ESTA_op_expand.m、ESTA_op_axes.m、ESTA_op_translate.m
%   bound.m、selection.m、ESTA_update_BestArchive.m、ESTA_update_parameters.m
%
% 适配原则：
%   1. 保留 ESTA 原始搜索顺序：
%      rotation -> expansion -> axesion -> translation。
%   2. 保留 BestArchive 档案机制和 ESTA_update_parameters 参数更新规则。
%   3. 删除 EXSTA 及其 X 增强模块，不引入压缩包 benchmark。
%   4. 只把原 while(1) / 收敛停止改为 tic/toc 时间终止。
%   5. 每次调用 fobj 由 eval_one 统一统计 FEs，并保存当前最优调度细节。
%   6. Time_curve 是横轴时间，Convergence_curve 是同一时刻的当前最优值。
%   7. 四类状态变换均先选择片段，再按各自原有的维度数量和公式更新。
%   8. 参数表 para 三列依次为：搜索强度 SE、平移步长 beta、坐标轴步长 delta。
% -------------------------------------------------------------------------
    init_mode = 'random';

    algorithm_name = 'ESTA';
    popsize = 20;
    FEs = 0;                                % 函数评价次数
    fit = inf(popsize, 1);                  % 种群适应度
    Best_score = inf;                       % 当前最好适应度
    Best_pos = zeros(1, dim);               % 当前最好个体
    Best_detail = struct();                 % 当前最好调度细节
    Convergence_curve = [];                 % 最优值曲线，横轴为 Time_curve
    Time_curve = [];                        % 运行时间曲线
    % ESTA 原代码用 Range(1,:) / Range(2,:) 表示边界。
    lb = lb(:)';
    ub = ub(:)';
    Range = [lb; ub];

    % 初始化种群，统一采用 algorithms/common 中的公共初始化函数；ESTA 主体仍维护一个当前 Best 点。
    % 计时从初始化之前开始，Time_curve 第一条记录包含初始化和初始评价耗时。
    tic;
    Positions = initialize_population(popsize, dim, lb, ub, fobj, init_mode);

    para = [
        20  1.0  1.0
        20  2.0  2.0
        20  3.0  3.0
        30  1.0  3.0
        30  2.0  2.0
        30  3.0  1.0
        50  1.0  2.0
        50  2.0  1.0
        50  3.0  3.0
    ];
    paraindex = 3;                          % 第 5 行保持原始 ESTA 默认参数：SE=30, beta=2, delta=2
    SE = para(paraindex, 1);                % 每个状态变换算子生成的候选解数量
    beta = para(paraindex, 2);              % translation 平移算子步长
    delta = para(paraindex, 3);             % axesion 坐标轴算子步长

    SE = x3_option(options,'SE',SE);
    beta = x3_option(options,'alpha0',beta);
    delta = x3_option(options,'alpha1',delta);
    % alpha/gamma 仍保留原自适应更新规则，不纳入当前正交参数表。
    alpha = 2;
    gamma_value = 2;
    epsilon = 1e-8;

    for i = 1:popsize
        [fitness, detail] = fobj(Positions(i,:));
        FEs = FEs + 1;
        if fitness <= Best_score
            Best_score = fitness;
            Best_pos = Positions(i,:);
            Best_detail = detail;
        end
    end

    BestArchive = Best_pos;
    CPU_time = toc;
    Convergence_curve(end+1) = Best_score;
    Time_curve(end+1) = CPU_time;

    while toc < max_time
        prevBest = Best_pos;

        % rotation：原 rotation.m 调用 ESTA_op_rotate、bound、selection。
        [Best_pos, Best_score, FEs, Best_detail] = ESTA_rotation_op(Best_pos, Best_score, SE, Range, alpha, fobj, max_time, FEs, Best_detail);
        BestArchive = ESTA_update_BestArchive(Best_pos, BestArchive);

        % expansion：原 expansion.m 调用 ESTA_op_expand、bound、selection。
        [Best_pos, Best_score, FEs, Best_detail] = ESTA_expansion_op(Best_pos, Best_score, SE, Range, gamma_value, fobj, max_time, FEs, Best_detail);
        BestArchive = ESTA_update_BestArchive(Best_pos, BestArchive);

        % axesion：原 axesion.m 调用 ESTA_op_axes、bound、selection。
        [Best_pos, Best_score, FEs, Best_detail] = ESTA_axesion_op(Best_pos, Best_score, SE, Range, delta, fobj, max_time, FEs, Best_detail);
        BestArchive = ESTA_update_BestArchive(Best_pos, BestArchive);

        % translation：原 translation.m 使用 BestArchive 作为预测档案。
        [Best_pos, Best_score, FEs, Best_detail] = ESTA_translation_op(Best_pos, Best_score, BestArchive, SE, Range, beta, fobj, max_time, FEs, Best_detail);
        BestArchive = ESTA_update_BestArchive(Best_pos, BestArchive);

        % 原 ESTA 在每轮末尾用 ESTA_update_parameters 更新 alpha 和 gamma。
        % 这里不使用固定迭代次数，只在时间循环内保留该参数更新规则。
        [alpha, gamma_value] = ESTA_update_parameters(prevBest, Best_pos, epsilon);

        CPU_time = toc;
        Convergence_curve(end+1) = Best_score; %#ok<AGROW>
        Time_curve(end+1) = CPU_time; %#ok<AGROW>


    end

    CPU_time = toc;
    output = build_algorithm_output(algorithm_name, popsize, CPU_time, max_time, FEs, Best_pos, Best_score, Convergence_curve, Time_curve, Best_detail);

end
