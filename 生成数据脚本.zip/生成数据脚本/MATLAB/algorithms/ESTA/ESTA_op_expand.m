﻿function State = ESTA_op_expand(Best, SE_inner, gamma_inner)
    % ESTA_OP_EXPAND 扩展变换算子。
    % 公式分两组：
    %   State1 = Best + gamma * randn .* Best
    %   State2 = Best + gamma * randn .* 1
    % State1 按当前 Best 的尺度做比例扩展，State2 按单位尺度做绝对扩展。
    n = length(Best);                    % 连续编码维度
    half_SE = round(SE_inner / 2);       % 两类扩展候选各生成约一半
    State1 = repmat(Best, half_SE, 1);
    State2 = repmat(Best, half_SE, 1);
    for candidate_index = 1:half_SE
        update_indices = select_random_segment_indices(n);
        State1(candidate_index, update_indices) = Best(update_indices) + ...
            gamma_inner * randn(1, numel(update_indices)) .* Best(update_indices);

        update_indices = select_random_segment_indices(n);
        State2(candidate_index, update_indices) = Best(update_indices) + ...
            gamma_inner * randn(1, numel(update_indices));
    end
    State = [State1; State2];
end

