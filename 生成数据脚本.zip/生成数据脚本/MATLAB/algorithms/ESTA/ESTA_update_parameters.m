﻿function [alpha_inner, gamma_inner] = ESTA_update_parameters(oldBest, newBest, epsilon_inner)
    % ESTA_UPDATE_PARAMETERS 根据 Best 变化幅度调整 alpha/gamma。
    % diffBest 是新旧最优解在所有维度上的最大变化量：
    %   变化大：alpha/gamma 取较大值，继续扩大搜索；
    %   变化小：alpha/gamma 收缩到 diffBest 或 epsilon，做精细开发。
    diffBest = max(abs(oldBest - newBest));
    if diffBest > 1
        alpha_inner = min(2, diffBest);
        gamma_inner = min(2, diffBest);
    elseif diffBest > 1e-2
        alpha_inner = 1;
        gamma_inner = 1;
    elseif diffBest > epsilon_inner
        alpha_inner = diffBest;
        gamma_inner = diffBest;
    else
        alpha_inner = epsilon_inner;
        gamma_inner = epsilon_inner;
    end
end
