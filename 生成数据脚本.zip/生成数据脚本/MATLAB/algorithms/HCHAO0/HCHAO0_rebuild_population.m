function [Positions, fit, details] = HCHAO0_rebuild_population( ...
        combined_positions, combined_fit, combined_details, ...
        popsize, best_score, characteristic_difference)
% HCHAO0_REBUILD_POPULATION 按质量阈值和轻量距离参考重构停滞种群。
% -------------------------------------------------------------------------
% 父代和子代已由入口函数合并。本函数先应用
% F_limit = F_best + delta_F 质量阈值，再按适应度去除重复调度。
% 新种群先保留阈值内最优的质量核心；随后固定两个远距离参考个体，
% 每次随机抽取一个质量参考和一个远距离参考，对剩余候选进行轻量距离
% 打分，避免完整最大最小距离矩阵带来的额外开销。
% -------------------------------------------------------------------------

    % 先按适应度升序排列，使去重和后续补齐都优先保留更优个体。
    [~, fitness_order] = sort(combined_fit, 'ascend');

    fitness_limit = best_score + characteristic_difference;
    eligible_indices = fitness_order( ...
        combined_fit(fitness_order) <= fitness_limit);

    % 同一调度若重复，只保留适应度排序中最靠前的个体。
    unique_eligible = zeros(1, 0);
    for candidate_index = eligible_indices(:)'
        if HCHAO0_is_new_schedule( ...
                candidate_index, unique_eligible, ...
                combined_fit, combined_details)
            unique_eligible(end + 1) = candidate_index; %#ok<AGROW>
        end
    end

    selected_indices = zeros(1, 0);
    if ~isempty(unique_eligible)
        eligible_count = numel(unique_eligible);

        if eligible_count <= popsize
            selected_indices = unique_eligible;
        else

        % 质量核心仍按适应度选取，保持重构后的基本收敛方向。
        quality_count = min(ceil(popsize / 4), eligible_count);
        quality_positions = 1:quality_count;
        selected_positions = quality_positions;
        remaining_positions = quality_count + 1:eligible_count;

        % 先从剩余候选中找出相对质量核心最远和次远的两个参考个体。
        diversity_reference_positions = zeros(1, 0);
        if ~isempty(remaining_positions) && ~isempty(quality_positions)
            reference_scores = zeros(1, numel(remaining_positions));
            for candidate_offset = 1:numel(remaining_positions)
                candidate_position = remaining_positions(candidate_offset);
                candidate_index = unique_eligible(candidate_position);
                minimum_distance = inf;
                for quality_position = quality_positions
                    quality_index = unique_eligible(quality_position);
                    distance = HCHAO0_schedule_distance( ...
                        combined_details{candidate_index}.vector, ...
                        combined_details{quality_index}.vector);
                    minimum_distance = min(minimum_distance, distance);
                end
                reference_scores(candidate_offset) = minimum_distance;
            end

            [~, reference_order] = sort(reference_scores, 'descend');
            reference_count = min(2, numel(reference_order));
            diversity_reference_positions = ...
                remaining_positions(reference_order(1:reference_count));
        end

        % 用“随机质量参考 + 随机远距离参考”替代完整最大最小距离循环。
        while numel(selected_positions) < popsize && ...
                ~isempty(remaining_positions)
            selection_scores = zeros(1, numel(remaining_positions));
            for candidate_offset = 1:numel(remaining_positions)
                candidate_position = remaining_positions(candidate_offset);
                candidate_index = unique_eligible(candidate_position);

                quality_reference_position = ...
                    quality_positions(randi(numel(quality_positions)));
                quality_reference_index = ...
                    unique_eligible(quality_reference_position);
                quality_distance = HCHAO0_schedule_distance( ...
                    combined_details{candidate_index}.vector, ...
                    combined_details{quality_reference_index}.vector);

                diversity_candidates = diversity_reference_positions( ...
                    diversity_reference_positions ~= candidate_position);
                if isempty(diversity_candidates)
                    selection_scores(candidate_offset) = quality_distance;
                else
                    diversity_reference_position = diversity_candidates( ...
                        randi(numel(diversity_candidates)));
                    diversity_reference_index = ...
                        unique_eligible(diversity_reference_position);
                    diversity_distance = HCHAO0_schedule_distance( ...
                        combined_details{candidate_index}.vector, ...
                        combined_details{diversity_reference_index}.vector);
                    selection_scores(candidate_offset) = min( ...
                        quality_distance, diversity_distance);
                end
            end

            [~, selected_offset] = max(selection_scores);
            selected_positions(end + 1) = ...
                remaining_positions(selected_offset); %#ok<AGROW>
            remaining_positions(selected_offset) = [];
        end

        selected_indices = unique_eligible(selected_positions);
        end
    end

    % 合格不重复方案不足时，先按适应度补充其他不重复方案。
    for candidate_index = fitness_order(:)'
        if numel(selected_indices) >= popsize
            break;
        end
        if ~ismember(candidate_index, selected_indices) && ...
                HCHAO0_is_new_schedule( ...
                    candidate_index, selected_indices, ...
                    combined_fit, combined_details)
            selected_indices(end + 1) = candidate_index; %#ok<AGROW>
        end
    end

    % 不重复方案仍不足时，允许重复调度，并从完整合并种群中随机补齐。
    random_order = randperm(numel(combined_fit));
    for candidate_index = random_order
        if numel(selected_indices) >= popsize
            break;
        end
        if ~ismember(candidate_index, selected_indices)
            selected_indices(end + 1) = candidate_index; %#ok<AGROW>
        end
    end

    Positions = combined_positions(selected_indices, :);
    fit = combined_fit(selected_indices);
    details = combined_details(selected_indices);
    fit = fit(:);
    details = details(:);
end
