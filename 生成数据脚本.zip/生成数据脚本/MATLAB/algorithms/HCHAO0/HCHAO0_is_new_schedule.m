function is_new = HCHAO0_is_new_schedule( ...
        candidate_index, selected_indices, fitness, details)
% HCHAO0_IS_NEW_SCHEDULE 判断候选调度是否与已选集合重复。
% -------------------------------------------------------------------------
% 同一调度在确定性评价下必然具有相同适应度，因此先比较 fitness；只有
% 适应度相同才使用 detail.vector 做完整比较，避免不必要的矩阵 isequal。
% -------------------------------------------------------------------------

    % 缺少离散调度表示的候选不能作为有效的不重复方案。
    candidate_detail = details{candidate_index};
    if ~isstruct(candidate_detail) || ...
            ~isfield(candidate_detail, 'vector') || ...
            isempty(candidate_detail.vector)
        is_new = false;
        return;
    end

    % 与已选集合逐一比较；发现完全相同的 vector 后立即返回。
    is_new = true;
    candidate_fitness = fitness(candidate_index);
    for selected_index = selected_indices
        if fitness(selected_index) ~= candidate_fitness
            continue;
        end

        selected_detail = details{selected_index};
        if isstruct(selected_detail) && ...
                isfield(selected_detail, 'vector') && ...
                isequal(candidate_detail.vector, selected_detail.vector)
            is_new = false;
            return;
        end
    end
end
