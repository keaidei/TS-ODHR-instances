function output = HCHAO0(max_time,lb,ub,dim,fobj,init_mode,options)
if nargin < 7, options=struct(); end
init_mode = 'random';
output=HCHAO(max_time,lb,ub,dim,fobj,init_mode,options);
output.algorithm_name='HCHAO0';
end
