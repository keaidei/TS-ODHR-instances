function output = build_algorithm_output(algorithm_name, popsize, cpu_time, max_time, ...
    evaluation_count, best_position, best_score, convergence_curve, time_curve, best_detail)
% BUILD_ALGORITHM_OUTPUT 统一封装算法运行结果。
% -------------------------------------------------------------------------
% 所有算法入口最终都返回本函数生成的 output 结构。公开结果字段统一使用
% 小写下划线命名，避免算法内部变量名和项目结果字段混用。
%
% 输入变量说明：
%   algorithm_name     : 算法名称。
%   popsize            : 种群规模。
%   cpu_time           : 实际运行时间。
%   max_time           : 本次运行允许的最大时间。
%   evaluation_count   : 目标函数评价次数。
%   best_position      : 当前最优连续编码。
%   best_score         : 当前最优目标函数值。
%   convergence_curve  : 每个记录点的最优目标值。
%   time_curve         : 每个记录点对应的运行时间。
%   best_detail        : 当前最优解的解码和调度细节。
% -------------------------------------------------------------------------

    output.algorithm_name = algorithm_name;
    output.popsize = popsize;
    output.cpu_time = cpu_time;
    output.max_time = max_time;
    output.evaluation_count = evaluation_count;
    output.best_position = best_position;
    output.best_score = best_score;
    output.convergence_curve = convergence_curve;
    output.time_curve = time_curve;
    output.num_records = length(convergence_curve);
    output.iterations = max(0, length(convergence_curve) - 1);
    output.best_detail = best_detail;
    output.best_c_sum = best_score;
    if isstruct(best_detail) && isfield(best_detail, 'makespan')
        output.best_makespan = best_detail.makespan;
    else
        output.best_makespan = nan;
    end
    output.time_convergence_curve = [time_curve(:), convergence_curve(:)];
end
