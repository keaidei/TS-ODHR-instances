﻿function best_exec = compute_best_exec_time(operation_map, task_set, devices, operation_count)
% COMPUTE_BEST_EXEC_TIME 估计每个工序的最快执行时间。
% -------------------------------------------------------------------------
% 输入变量说明：
%   operation_map   : 全局工序索引表，用于定位任务和任务内工序。
%   task_set        : 任务结构体数组，包含工序计算量 cal、可执行设备 SDEV、资源模式 mode。
%   devices         : 设备结构体数组，devices(dev).c 为计算能力，devices(dev).type 为设备资源占用类型。
%   operation_count : 全局工序总数。
%
% 输出变量说明：
%   best_exec(idx) : 第 idx 个工序在所有合法设备/资源组合下的最短执行时间。
%
% 计算公式：
%   exec_time = cal / (device_capacity * resource_count)
%   best_exec = min(exec_time)
% 其中 type=2 的设备按整机占用处理，仅保留最大合法资源模式，避免向上秩低估
% 该类设备的实际可执行配置。
% -------------------------------------------------------------------------

    best_exec = zeros(1, operation_count);
    for operation_index = 1:operation_count
        task_id = operation_map(2, operation_index);      % 当前工序所属任务编号
        operation_id = operation_map(3, operation_index); % 当前工序在任务内的编号
        operation = task_set(task_id).O(operation_id);    % 当前工序结构体

        current_best = inf;
        for device_option_index = 1:numel(operation.SDEV)
            device_id = operation.SDEV(device_option_index);
            resource_options = get_operation_device_mu_list(operation, device_id);
            if devices(device_id).type == 2
                resource_options = max(resource_options);
            end
            for resource_option_index = 1:numel(resource_options)
                resource_count = resource_options(resource_option_index);
                exec_time = operation.cal / (devices(device_id).c * resource_count);
                current_best = min(current_best, exec_time);
            end
        end

        if isfinite(current_best)
            best_exec(operation_index) = current_best;
        end
    end
end
