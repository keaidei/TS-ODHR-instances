﻿function successors = build_successor_list(operation_map, task_set, operation_lookup, operation_count)
% BUILD_SUCCESSOR_LIST 构造每个全局工序的直接后继列表。
% -------------------------------------------------------------------------
% 输入变量说明：
%   operation_map    : 全局工序索引表，operation_map(2,idx) 为任务编号。
%   task_set         : 任务结构体数组，task_set(u).O(v).SOUT 保存工序 (u,v) 的后继工序编号。
%   operation_lookup : 反向索引表，operation_lookup(u,v) 可把任务内工序映射回全局工序编号。
%   operation_count  : 全局工序总数。
%
% 输出变量说明：
%   successors{idx} : 第 idx 个全局工序的直接后继全局编号数组。
%
% 算法含义：
%   该函数把调度问题中的有向无环图依赖关系从“任务内编号”转换为
%   “全局工序编号”，供拓扑排序和 upward rank 递推使用。
% -------------------------------------------------------------------------

    successors = cell(1, operation_count);
    for operation_index = 1:operation_count
        task_id = operation_map(2, operation_index);      % 当前工序所属任务编号
        operation_id = operation_map(3, operation_index); % 当前工序在任务内的编号
        operation = task_set(task_id).O(operation_id);    % 当前工序结构体

        successor_buffer = zeros(1, numel(operation.SOUT));
        successor_count = 0;
        for successor_id = operation.SOUT
            successor_index = operation_lookup(task_id, successor_id);
            if successor_index >= 1 && successor_index <= operation_count
                successor_count = successor_count + 1;
                successor_buffer(successor_count) = successor_index;
            end
        end
        successors{operation_index} = successor_buffer(1:successor_count);
    end
end
