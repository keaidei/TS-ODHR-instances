﻿function topo_order = build_topological_order(indegree, successors, N)
% BUILD_TOPOLOGICAL_ORDER 根据前驱数量和后继表生成拓扑序。
% -------------------------------------------------------------------------
% 输入变量说明：
%   indegree   : 每个工序尚未满足的前驱数量。
%   successors : 每个工序的直接后继全局编号列表。
%   N          : 全局工序总数。
%
% 输出变量说明：
%   topo_order : 满足前驱约束的全局工序顺序。
%
% 算法含义：
%   采用 Kahn 算法：每次取一个入度为 0 的工序加入序列，并将其后继入度减 1。
%   若异常数据中存在环或缺失边导致未能遍历全部工序，则把剩余工序按原编号
%   补到末尾，避免初始化阶段直接中断。
% -------------------------------------------------------------------------

    topo_order = zeros(1, N);
    order_count = 0;
    ready_set = find(indegree == 0);        % 当前所有可排入拓扑序的工序

    while ~isempty(ready_set)
        operation_index = ready_set(1);     % 保持稳定顺序，取最早进入 ready_set 的工序
        ready_set(1) = [];
        order_count = order_count + 1;
        topo_order(order_count) = operation_index;

        successor_indices = successors{operation_index};
        for successor_offset = 1:numel(successor_indices)
            successor_index = successor_indices(successor_offset);
            indegree(successor_index) = indegree(successor_index) - 1;
            if indegree(successor_index) == 0
                ready_set(end+1) = successor_index; %#ok<AGROW>
            end
        end
    end

    if order_count < N
        missing_indices = setdiff(1:N, topo_order(1:order_count), 'stable');
        topo_order(order_count+1:N) = missing_indices;
    end
end
