function Positions = heuristic_population_initialization( ...
    popsize, lb, ub, dim, fobj)
% HEURISTIC_POPULATION_INITIALIZATION 构造公共启发式初始种群。
% -------------------------------------------------------------------------
% 本函数是一个完整函数体，不再拆成多个启发式辅助函数文件。流程为：
%   1) 从 fobj 闭包中提取 problem；
%   2) 用考虑执行时间和最大可达传输速率的 HEFT 风格 upward_rank 做一次贪婪列表调度；
%   3) 将离散调度结果编码成连续位置，作为种群第一条启发式种子；
%   4) 其余个体使用随机初始化补齐。
%
% 贪婪选择规则：
%   每次只从所有前驱已完成的 ready_set 中选择一个工序。对该工序枚举所有
%   候选设备和资源模式，估计其最早完成时间，并加入关键路径奖励：
%       cost = finish_time + alpha * max(resource_times) - critical_bonus
%   当前 alpha 固定为 0，因此初始化阶段只使用完成时间和关键工序奖励。
%
% 注意：本函数只生成位置，不调用 fobj(position) 做真实评价。所有初始个体
% 的适应度评价仍由各算法入口统一完成。
% -------------------------------------------------------------------------

    lb = lb(:)';
    ub = ub(:)';

    % 统一算法接口只传入 fobj，没有直接传入 problem。这里利用 MATLAB
    % 匿名函数闭包读取 get_problem 中捕获的 problem 结构体。
    problem = [];
    try
        function_info = functions(fobj);
        if isfield(function_info, 'workspace') && ...
                ~isempty(function_info.workspace)
            captured_workspace = function_info.workspace{1};
            if isfield(captured_workspace, 'problem')
                problem = captured_workspace.problem;
            end
        end
    catch
        problem = [];
    end

    % 若无法获得调度语义信息，或编码维度不是三段结构，则退回随机初始化。
    if isempty(problem) || mod(dim, 3) ~= 0
        Positions = initialization(popsize, dim, lb, ub);
        Positions = boundary_check(Positions, lb, ub);
        return;
    end

    operation_count = dim / 3;
    alpha = 0;                              % 初始化不叠加资源拥挤惩罚
    critical_weight = 0.35;                 % upward_rank 关键工序奖励权重
    % upward_rank 越大，说明工序越接近含通信代价的关键路径，贪婪选择时会得到更高奖励。
    upward_rank = compute_upward_rank(problem, dim);

    % 取出调度问题常用字段，避免在主循环中反复访问 problem.xxx。
    task_set = problem.T;
    devices = problem.D;
    connectivity_matrix = problem.B;
    bandwidth_matrix = problem.b;
    operation_map = problem.operation_map;
    operation_lookup = problem.operation_lookup;
    indegree = problem.indegree(:)';
    rank_scale = max(upward_rank);

    % resource_ready_time{d}(r) 记录设备 d 的第 r 个资源块何时可再次使用。
    device_count = numel(devices);
    resource_ready_time = cell(device_count, 1);
    for device_id = 1:device_count
        resource_ready_time{device_id} = zeros(1, devices(device_id).mi);
    end

    % 这些数组保存贪婪离散调度的中间结果，后面会被重新编码成连续位置。
    scheduled = false(1, operation_count);
    finish_time = zeros(1, operation_count);
    device_of = zeros(1, operation_count);
    chosen_device = zeros(1, operation_count);
    chosen_resource = zeros(1, operation_count);
    operation_sequence = zeros(1, operation_count);
    sequence_count = 0;
    % ready_set 中只包含所有前驱已经完成、当前可以被调度的工序。
    ready_set = find(indegree == 0);

    % 主循环：每轮从 ready_set 中选出一个代价最小的工序-设备-资源组合。
    while ~isempty(ready_set)
        best_cost = inf;
        best_item = [];

        for ready_index = 1:numel(ready_set)
            operation_index = ready_set(ready_index);
            task_id = operation_map(2, operation_index);
            operation_id = operation_map(3, operation_index);
            operation = task_set(task_id).O(operation_id);

            % 枚举当前 ready 工序的所有候选设备，以及该设备上的所有资源模式。
            for device_option_index = 1:numel(operation.SDEV)
                device_id = operation.SDEV(device_option_index);
                resource_options = get_operation_device_mu_list( ...
                    operation, device_id);
                if devices(device_id).type == 2
                    % type=2 按整机占用处理，初始化中直接使用最大合法资源模式。
                    resource_options = max(resource_options);
                end

                for resource_option_index = 1:numel(resource_options)
                    resource_count = resource_options(resource_option_index);
                    dependency_ready_time = 0;
                    feasible = true;

                    % 前驱约束：当前工序必须等待所有前驱完成；若设备不同，还要
                    % 叠加数据传输时间，得到由依赖关系决定的最早开始时间。
                    for predecessor_id = operation.SIN
                        predecessor_index = operation_lookup( ...
                            task_id, predecessor_id);
                        if predecessor_index < 1 || ...
                                ~scheduled(predecessor_index)
                            feasible = false;
                            break;
                        end

                        communication_time = calc_trans( ...
                            task_set(task_id).O(predecessor_id).data, ...
                            device_of(predecessor_index), ...
                            device_id, ...
                            connectivity_matrix, ...
                            bandwidth_matrix);
                        dependency_ready_time = max( ...
                            dependency_ready_time, ...
                            finish_time(predecessor_index) + ...
                            communication_time);
                    end

                    if ~feasible
                        continue;
                    end

                    resource_times = resource_ready_time{device_id};
                    [~, selected_blocks] = mink( ...
                        resource_times, resource_count);
                    % 资源约束：选当前设备上最早可用的 resource_count 个资源块。
                    resource_ready = max(resource_times(selected_blocks));
                    start_time_value = max( ...
                        dependency_ready_time, resource_ready);
                    execution_time = operation.cal / ...
                        (devices(device_id).c * resource_count);
                    finish_time_value = start_time_value + execution_time;

                    if rank_scale <= 0
                        critical_bonus = 0;
                    else
                        critical_bonus = critical_weight * ...
                            upward_rank(operation_index) / rank_scale * ...
                            finish_time_value;
                    end
                    % alpha 当前为 0，所以资源拥挤项保留在公式中，但不实际生效。
                    cost = finish_time_value + ...
                        alpha * max(resource_times) - critical_bonus;

                    if cost < best_cost
                        best_cost = cost;
                        best_item = struct( ...
                            'operation_index', operation_index, ...
                            'device_id', device_id, ...
                            'resource_count', resource_count, ...
                            'finish_time_value', finish_time_value, ...
                            'selected_blocks', selected_blocks);
                    end
                end
            end
        end

        % 理论上 ready_set 中的工序都应该可调度。该兜底用于异常数据下仍然
        % 给出一个合法连续编码，避免初始化阶段中断整个算法。
        if isempty(best_item)
            operation_index = ready_set(1);
            task_id = operation_map(2, operation_index);
            operation_id = operation_map(3, operation_index);
            operation = task_set(task_id).O(operation_id);
            device_id = operation.SDEV(1);
            legal_resource_options = get_operation_device_mu_list( ...
                operation, device_id);
            resource_count = legal_resource_options(1);
            best_item = struct( ...
                'operation_index', operation_index, ...
                'device_id', device_id, ...
                'resource_count', resource_count, ...
                'finish_time_value', 0, ...
                'selected_blocks', 1:resource_count);
        end

        operation_index = best_item.operation_index;
        device_id = best_item.device_id;
        resource_count = best_item.resource_count;
        selected_blocks = best_item.selected_blocks;
        finish_time_value = best_item.finish_time_value;

        % 将本轮选中的组合正式写入离散调度结果。
        sequence_count = sequence_count + 1;
        operation_sequence(sequence_count) = operation_index;
        scheduled(operation_index) = true;
        finish_time(operation_index) = finish_time_value;
        device_of(operation_index) = device_id;
        chosen_device(operation_index) = device_id;
        chosen_resource(operation_index) = resource_count;

        % 更新所占设备资源块的下一次可用时间。
        if devices(device_id).type == 1 || devices(device_id).type == 2
            resource_ready_time{device_id}(:) = finish_time_value;
        else
            resource_ready_time{device_id}(selected_blocks) = ...
                finish_time_value;
        end

        % 当前工序完成后，释放其后继工序的入度；入度降为 0 的后继进入 ready_set。
        ready_set(ready_set == operation_index) = [];
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        for successor_id = task_set(task_id).O(operation_id).SOUT
            successor_key = sprintf('%d_%d', task_id, successor_id);
            if isKey(problem.index_map, successor_key)
                successor_index = problem.index_map(successor_key);
                indegree(successor_index) = indegree(successor_index) - 1;
                if indegree(successor_index) == 0
                    ready_set(end + 1) = successor_index; %#ok<AGROW>
                end
            end
        end
    end

    % 将离散调度结果编码回三段连续位置：
    %   第 1 段：工序优先级，数值越小越优先；
    %   第 2 段：候选设备下标编码；
    %   第 3 段：资源模式下标编码。
    heuristic_position = zeros(1, dim);
    priority_code = zeros(1, operation_count);
    priority_code(operation_sequence) = 1:operation_count;
    heuristic_position(1:operation_count) = priority_code;

    for operation_index = 1:operation_count
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        operation = task_set(task_id).O(operation_id);

        device_option_index = find( ...
            operation.SDEV == chosen_device(operation_index), 1);
        if isempty(device_option_index)
            device_option_index = 1;
        end

        resource_options = operation.mode(device_option_index).mu;
        resource_option_index = find( ...
            resource_options == chosen_resource(operation_index), 1);
        if isempty(resource_option_index)
            resource_option_index = 1;
        end

        % 用“下标 - 1 + 0.01”稳定落入 map_method 的对应离散选项。
        heuristic_position(operation_count + operation_index) = ...
            device_option_index - 1 + 0.01;
        heuristic_position(2 * operation_count + operation_index) = ...
            resource_option_index - 1 + 0.01;
    end

    heuristic_position = boundary_check(heuristic_position, lb, ub);
    % proxy_score 只用于判断启发式调度是否有效，不作为真实适应度记录。
    proxy_score = max(finish_time);

    % 第一条为启发式种子，其余个体随机补齐，保持公共种群规模 popsize 不变。
    if isfinite(proxy_score) && popsize > 0
        Positions = zeros(popsize, dim);
        Positions(1, :) = heuristic_position;
        if popsize > 1
            Positions(2:end, :) = initialization(popsize - 1, dim, lb, ub);
        end
    else
        Positions = initialization(popsize, dim, lb, ub);
    end

    Positions = boundary_check(Positions, lb, ub);
end
