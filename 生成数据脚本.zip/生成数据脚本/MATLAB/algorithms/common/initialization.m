﻿function Positions = initialization(PopSize, dim, lb, ub)
% initialization 算法/公共辅助函数。
% 该文件属于 algorithms 模块，服务于统一算法接口、种群初始化、边界处理
% 或结果封装。算法入口统一返回 build_algorithm_output 生成的 output 结构。
Positions = zeros(PopSize, dim);
for i = 1:PopSize
    for j = 1:dim
        Positions(i,j) = (ub(j) - lb(j)) * rand() + lb(j);
    end
end
end