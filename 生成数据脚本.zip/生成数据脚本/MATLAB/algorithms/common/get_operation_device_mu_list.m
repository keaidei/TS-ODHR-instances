function mu_list = get_operation_device_mu_list(operation, device_id)
% GET_OPERATION_DEVICE_MU_LIST Return legal resource modes for one device.
% -------------------------------------------------------------------------
% operation.SDEV(k) corresponds to operation.mode(k).mu.
% -------------------------------------------------------------------------

    device_index = find(operation.SDEV == device_id, 1);

    if isempty(device_index)
        error('Device %d is not a candidate device for this operation.', device_id);
    end

    if ~isfield(operation, 'mode') || numel(operation.mode) < device_index || ...
            ~isfield(operation.mode(device_index), 'mu')
        error('Missing mode.mu for device %d in this operation.', device_id);
    end

    mu_list = unique(max(1, floor(operation.mode(device_index).mu(:)')), 'stable');

    if isempty(mu_list)
        error('No legal resource mode for device %d in this operation.', device_id);
    end
end
