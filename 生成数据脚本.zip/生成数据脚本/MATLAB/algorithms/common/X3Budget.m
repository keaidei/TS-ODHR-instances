classdef X3Budget < handle
    % Tracks the incumbent independently of algorithm-specific replacement.
    properties
        clock; limit; count=0; score=Inf; position=[]; detail=struct();
        times=[]; scores=[];
    end
    methods
        function self=X3Budget(limit)
            self.limit=limit; self.clock=tic;
        end
        function [score,detail]=evaluate(self,x,problem)
            if self.count>0 && toc(self.clock)>=self.limit
                error('X3:TimeLimit','Evaluation budget reached.');
            end
            [score,detail]=evaluate_solution(x,problem);
            assert(isfinite(score),'X3:Infeasible','Unexpected infeasible schedule');
            self.count=self.count+1;
            if score<self.score
                self.score=score; self.position=x; self.detail=detail;
                self.times(end+1)=toc(self.clock); self.scores(end+1)=score;
            end
        end
    end
end
