﻿function upward_rank = compute_upward_rank(problem, dim)
% COMPUTE_UPWARD_RANK 计算启发式初始化使用的 HEFT 风格向上秩。
% -------------------------------------------------------------------------
% 输入变量说明：
%   problem : 调度问题结构体，包含 operation_map、T、D、operation_lookup、indegree 等字段。
%   dim     : 连续编码维度，项目中 dim = 3 * 工序数。
%
% 输出变量说明：
%   upward_rank(idx) : 第 idx 个工序到出口工序的最长估计路径代价。
%
% 递推公式：
%   rank_u(i) = w_i,                                      i 为出口工序
%   rank_u(i) = w_i + max_{j in succ(i)}(c_ij+rank_u(j)), i 有后继工序
% 其中 w_i 为工序 i 的最快执行时间估计，c_ij 直接使用候选设备组合中的
% 最大可达传输速率估计为 data_i/max_rate。rank_u 越大，说明该工序越接近关键路径，公共
% 启发式初始化会更倾向于优先处理它。
% -------------------------------------------------------------------------

    operation_count = dim / 3;                   % 全局工序总数
    operation_map = problem.operation_map;       % 全局工序索引表
    task_set = problem.T;                        % 任务结构体数组
    devices = problem.D;                         % 设备结构体数组
    operation_lookup = problem.operation_lookup; % 任务内工序到全局工序的反向索引
    connectivity_matrix = problem.B;             % 设备连通性矩阵
    bandwidth_matrix = problem.b;                % 设备间传输速率矩阵

    best_exec = compute_best_exec_time(operation_map, task_set, devices, operation_count);
    successors = build_successor_list(operation_map, task_set, operation_lookup, operation_count);
    topo_order = build_topological_order(problem.indegree(:)', successors, operation_count);

    communication_estimate = zeros(operation_count);
    for operation_index = 1:operation_count
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        operation = task_set(task_id).O(operation_id);
        successor_indices = successors{operation_index};

        for successor_offset = 1:numel(successor_indices)
            successor_index = successor_indices(successor_offset);
            successor_task_id = operation_map(2, successor_index);
            successor_operation_id = operation_map(3, successor_index);
            successor_operation = ...
                task_set(successor_task_id).O(successor_operation_id);

            maximum_transfer_rate = 0;
            for source_device_id = operation.SDEV
                for target_device_id = successor_operation.SDEV
                    if connectivity_matrix(source_device_id, target_device_id) == 1
                        maximum_transfer_rate = max( ...
                            maximum_transfer_rate, ...
                            bandwidth_matrix(source_device_id, target_device_id));
                    end
                end
            end

            if maximum_transfer_rate > 0
                communication_estimate(operation_index, successor_index) = ...
                    operation.data / maximum_transfer_rate;
            end
        end
    end

    upward_rank = best_exec;                     % 先用 w_i 初始化，再按逆拓扑序递推
    for order_index = numel(topo_order):-1:1
        operation_index = topo_order(order_index);
        successor_indices = successors{operation_index};
        if isempty(successor_indices)
            upward_rank(operation_index) = best_exec(operation_index);
        else
            successor_scores = zeros(1, numel(successor_indices));
            for successor_offset = 1:numel(successor_indices)
                successor_index = successor_indices(successor_offset);
                successor_scores(successor_offset) = ...
                    communication_estimate(operation_index, successor_index) + ...
                    upward_rank(successor_index);
            end
            upward_rank(operation_index) = best_exec(operation_index) + ...
                max(successor_scores);
        end
    end
end
