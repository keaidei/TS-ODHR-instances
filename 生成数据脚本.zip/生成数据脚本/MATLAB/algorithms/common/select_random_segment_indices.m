function [dimension_indices, selected_segments, combination_id] = ...
    select_random_segment_indices(dim)
% SELECT_RANDOM_SEGMENT_INDICES 先从七种片段组合中等概率选择允许更新的维度。
% -------------------------------------------------------------------------
% 三段依次为工序优先级、设备选择和资源模式。七种非空组合的概率均为
% 1/7。本函数只确定本次算法算子允许访问的维度；具体更新多少个维度、
% 如何产生新值，仍完全由调用算法原有策略决定。
% -------------------------------------------------------------------------

    if ~isscalar(dim) || dim <= 0 || dim ~= floor(dim) || mod(dim, 3) ~= 0
        error('select_random_segment_indices:InvalidDimension', ...
            '调度编码维度必须是能被 3 整除的正整数。');
    end

    segment_combinations = { ...
        1, 2, 3, [1 2], [1 3], [2 3], [1 2 3]};
    combination_id = randi(7);
    selected_segments = segment_combinations{combination_id};

    segment_length = dim / 3;
    dimension_indices = zeros(1, segment_length * numel(selected_segments));
    write_index = 1;
    for segment_id = selected_segments
        segment_indices = ...
            (segment_id - 1) * segment_length + (1:segment_length);
        next_write_index = write_index + segment_length - 1;
        dimension_indices(write_index:next_write_index) = segment_indices;
        write_index = next_write_index + 1;
    end
end
