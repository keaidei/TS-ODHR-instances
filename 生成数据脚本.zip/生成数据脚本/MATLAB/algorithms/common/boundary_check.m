﻿function X = boundary_check(X, lb, ub)
% BOUNDARY_CHECK 统一边界处理函数
% -------------------------------------------------------------------------
% 功能：
%   将个体或种群限制在 [lb, ub] 范围内。
%   支持 X 为 1×dim 个体，也支持 X 为 N×dim 种群。
%   这里使用 repmat 显式构造上下界矩阵，让行向量和种群矩阵的尺寸关系更清晰。
% -------------------------------------------------------------------------

    lb = lb(:)';
    ub = ub(:)';

    if size(X,2) ~= numel(lb)
        X = X(:)';
    end

    lb_mat = repmat(lb, size(X,1), 1);
    ub_mat = repmat(ub, size(X,1), 1);

    X = min(max(X, lb_mat), ub_mat);
end
