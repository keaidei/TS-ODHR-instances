function Positions = initialize_population(popsize, dim, lb, ub, fobj, init_mode)
% INITIALIZE_POPULATION 统一种群初始化入口。
% -------------------------------------------------------------------------
% 输入变量说明：
%   popsize   : 种群规模，即需要生成多少个初始个体。
%   dim       : 连续编码维度，调度问题中通常为 3 * 工序数。
%   lb, ub    : 每个维度的下界和上界。
%   fobj      : 目标函数句柄；启发式模式仅从闭包提取问题数据，不执行评价。
%   init_mode : 初始化模式，可选 random / heuristic。
%
% 输出变量说明：
%   Positions : popsize x dim 的初始种群矩阵。
%
% 设计说明：
%   所有算法都通过这个函数获得初始种群，避免每个算法各自处理路径、边界
%   和初始化策略。random 与 heuristic 都只生成位置，不调用真实目标函数；
%   初始种群的适应度和评价次数统一由各算法入口负责。
% -------------------------------------------------------------------------

    init_mode = lower(string(init_mode));
    valid_modes = ["random", "heuristic"];
    if ~any(init_mode == valid_modes)
        error('initialize_population:InvalidInitMode', ...
            'init_mode 必须为 random 或 heuristic。');
    end

    lb = lb(:)';                            % 统一为行向量，便于矩阵广播
    ub = ub(:)';                            % 统一为行向量，便于矩阵广播

    use_heuristic = (init_mode == "heuristic");
    if ~use_heuristic
        % 普通随机初始化：只负责生成合法位置，真实评价由各算法主体自己完成。
        Positions = initialization(popsize, dim, lb, ub);
        Positions = boundary_check(Positions, lb, ub);
        return;
    end

    % 启发式初始化：构造调度语义种子，按代理值选择后用随机位置补齐。
    Positions = heuristic_population_initialization( ...
        popsize, lb, ub, dim, fobj);

    Positions = boundary_check(Positions, lb, ub);
end
