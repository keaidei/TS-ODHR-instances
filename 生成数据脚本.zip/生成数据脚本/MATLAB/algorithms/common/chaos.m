function chaotic_value = chaos(map_index, initial_value, map_steps)
% CHAOS 生成指定步数后的混沌映射值。

    sequence = zeros(1, map_steps + 1);
    sequence(1) = initial_value;

    switch map_index
        case 1
            for step = 1:map_steps
                sequence(step + 1) = cos(2 * acos(sequence(step)));
            end
        case 2
            circle_a = 0.5;
            circle_b = 0.2;
            for step = 1:map_steps
                sequence(step + 1) = mod(sequence(step) + circle_b - ...
                    (circle_a / (2 * pi)) * ...
                    sin(2 * pi * sequence(step)), 1);
            end
        case 3
            for step = 1:map_steps
                if sequence(step) == 0
                    sequence(step + 1) = 1;
                else
                    sequence(step + 1) = mod( ...
                        1 / (sequence(step) + eps), 1);
                end
            end
        case 4
            iterative_a = 0.7;
            for step = 1:map_steps
                sequence(step + 1) = sin( ...
                    iterative_a * pi / (sequence(step) + eps));
            end
            sequence = (sequence + 1) / 2;
        case 5
            logistic_a = 4;
            for step = 1:map_steps
                sequence(step + 1) = logistic_a * sequence(step) * ...
                    (1 - sequence(step));
            end
        case 6
            piecewise_p = 0.4;
            for step = 1:map_steps
                value = sequence(step);
                if value >= 0 && value < piecewise_p
                    sequence(step + 1) = value / piecewise_p;
                elseif value < 0.5
                    sequence(step + 1) = ...
                        (value - piecewise_p) / (0.5 - piecewise_p);
                elseif value < 1 - piecewise_p
                    sequence(step + 1) = ...
                        (1 - piecewise_p - value) / (0.5 - piecewise_p);
                elseif value < 1
                    sequence(step + 1) = (1 - value) / piecewise_p;
                end
            end
        case 7
            for step = 1:map_steps
                sequence(step + 1) = sin(pi * sequence(step));
            end
        case 8
            singer_u = 1.07;
            for step = 1:map_steps
                value = sequence(step);
                sequence(step + 1) = singer_u * ( ...
                    7.86 * value - 23.31 * value ^ 2 + ...
                    28.75 * value ^ 3 - 13.302875 * value ^ 4);
            end
        case 9
            for step = 1:map_steps
                sequence(step + 1) = ...
                    sequence(step) ^ 2 * sin(pi * sequence(step));
            end
        case 10
            for step = 1:map_steps
                if sequence(step) < 0.7
                    sequence(step + 1) = sequence(step) / 0.7;
                else
                    sequence(step + 1) = ...
                        (10 / 3) * (1 - sequence(step));
                end
            end
        otherwise
            error('未知混沌映射编号：%d。', map_index);
    end

    chaotic_value = real(sequence(end));
end
