function distance = HCHAO1_schedule_distance(vector_a, vector_b)
% HCHAO1_SCHEDULE_DISTANCE 计算两个离散调度方案的结构差异。
% -------------------------------------------------------------------------
% vector 前两行共同标识任务和任务内工序，第 3、4 行表示设备和资源模式。
% 总距离由归一化工序顺序距离和设备-资源联合配置距离等权组成，范围 [0,1]。
% -------------------------------------------------------------------------

    % 编码结构不完整或工序数量不同，直接视为最大差异。
    if size(vector_a, 1) < 4 || size(vector_b, 1) < 4 || ...
            size(vector_a, 2) ~= size(vector_b, 2)
        distance = 1;
        return;
    end

    operation_count = size(vector_a, 2);
    if operation_count == 0
        distance = 0;
        return;
    end

    % 使用“任务号、任务内工序号”定位同一工序在两个方案中的排序位置。
    operations_a = vector_a(1:2, :)';
    operations_b = vector_b(1:2, :)';
    [is_present, positions_in_b] = ismember(operations_a, operations_b, 'rows');
    if all(is_present)
        if operation_count > 1
            % Spearman footrule 的最大值为 floor(n^2/2)，用于归一化。
            maximum_footrule = floor(operation_count ^ 2 / 2);
            order_distance = sum(abs((1:operation_count)' - positions_in_b)) / ...
                maximum_footrule;
        else
            order_distance = 0;
        end
    else
        order_distance = 1;
    end

    % 设备或资源任一项不同，就将该工序视为执行配置不同。
    configuration_distance = mean(any( ...
        vector_a(3:4, :) ~= vector_b(3:4, :), 1));
    % 两部分等权组合，并截断浮点误差造成的范围越界。
    distance = (order_distance + configuration_distance) / 2;
    distance = min(max(real(distance), 0), 1);
end
