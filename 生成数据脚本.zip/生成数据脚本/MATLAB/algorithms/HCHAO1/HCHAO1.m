function output = HCHAO1(max_time,lb,ub,dim,fobj,init_mode,options)
if nargin < 7, options=struct(); end
init_mode = 'heuristic'; options.Gen = Inf;
output=HCHAO(max_time,lb,ub,dim,fobj,init_mode,options);
output.algorithm_name='HCHAO1';
end
