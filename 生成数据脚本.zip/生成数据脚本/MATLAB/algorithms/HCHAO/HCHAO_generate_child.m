function child_pos = HCHAO_generate_child(parent_pos, lb, ub, dim, maps)
    if nargin < 5, maps = 1:10; end
    assert(~isempty(maps) && all(ismember(maps,1:10)), 'Invalid chaos map list');
% HCHAO_GENERATE_CHILD 随机选择编码片段并对其中 1~5 维执行混沌映射。
% -------------------------------------------------------------------------
% 输入 parent_pos 为选中的搜索父代。函数先从三段编码的七种非空组合中
% 等概率确定允许修改的维度范围，再随机抽取 1~5 维。每个被选维度随机
% 使用 maps 参数指定的混沌映射之一，最后统一执行边界修复。
% -------------------------------------------------------------------------

    % 子代以父代为基础，未被选中的维度保持不变。
    child_pos = parent_pos;
    % 这里只确定允许访问的片段组合，实际修改数量仍由本函数随机决定。
    allowed_indices = select_random_segment_indices(dim);
    change_count = randi([1, min(5, numel(allowed_indices))]);
    change_indices = allowed_indices( ...
        randperm(numel(allowed_indices), change_count));

    for k = change_indices
        % 将父代分量缩放并截断到混沌映射需要的开区间 (0,1)，避免
        % 端点导致部分映射退化；映射结果再恢复到该维编码范围。
        chaos_id = maps(randi(numel(maps)));
        init_value = abs(child_pos(k)) / max(abs(ub(k)), eps);
        init_value = min(max(init_value, eps), 1 - eps);
        child_pos(k) = chaos(chaos_id, init_value, 1) * ub(k);
    end

    % 混沌映射可能产生边界外数值，评价前统一修复。
    child_pos = boundary_check(child_pos, lb, ub);
end
