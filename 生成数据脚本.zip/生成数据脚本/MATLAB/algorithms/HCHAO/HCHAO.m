function output = HCHAO(max_time, lb, ub, dim, fobj, init_mode, options)
    if nargin < 7, options = struct(); end
% HCHAO 基于种群选择和随机混沌映射的调度搜索算法。
% -------------------------------------------------------------------------
% 输入：
%   max_time : 最大运行时间，初始化耗时包含在内；
%   lb, ub   : 连续调度编码各维度的下界和上界；
%   dim      : 三段连续编码的总维度；
%   fobj     : 返回 C_sum 和调度 detail 的目标函数；
%   init_mode: random 或 heuristic 初始化方式。
%
% 正常代采用一对一贪婪更新，以较低开销快速收敛；连续若干代没有改善时，
% 合并父代和子代，并在动态质量阈值内按调度距离重构种群以恢复多样性。
% 运行时间是唯一停止条件。
% -------------------------------------------------------------------------

    % ===== 1. 算法参数 =====
    algorithm_name = 'HCHAO';
    popsize = 30;                           % 固定父代数量和每代子代上限
    characteristic_difference_ratio = 0.05; % 质量阈值相对 Best_score 的比例
    stall_generation_limit = 5;             % 连续无改善达到 5 代后重构种群

    popsize = x3_option(options, 'Pop', popsize);
    characteristic_difference_ratio = x3_option(options, 'rho', characteristic_difference_ratio);
    stall_generation_limit = x3_option(options, 'Gen', stall_generation_limit);
    maps = x3_option(options, 'maps', 1:10);
    % ===== 2. 种群与统计状态 =====
    FEs = 0;                          % fobj 的累计调用次数
    fit = inf(popsize, 1);            % 当前父代种群的 C_sum
    population_details = cell(popsize, 1); % 当前父代的完整调度结果
    Best_score = inf;                 % 历史最优 C_sum
    Best_pos = zeros(1, dim);         % 历史最优连续编码
    Best_detail = struct();           % 历史最优调度结果
    Convergence_curve = [];           % 每代结束时的历史最优值
    Time_curve = [];                  % 与收敛曲线逐点对应的运行时间
    iteration_count = 0;              % 已完成的有效代数
    stall_count = 0;                  % 连续未改善代数

    % 统一为行向量，保证后续按维度访问边界时方向一致。
    lb = lb(:)';
    ub = ub(:)';

    % ===== 3. 初始化并统一评价 =====
    % 公共初始化只生成位置，所有初始个体由算法入口统一评价一次。
    tic;
    Positions = initialize_population( ...
        popsize, dim, lb, ub, fobj, init_mode);

    for i = 1:popsize
        % 每个初始位置只评价一次，同时保存适应度和完整调度细节。
        [fit(i), population_details{i}] = fobj(Positions(i, :));
        FEs = FEs + 1;
        if fit(i) <= Best_score
            Best_score = fit(i);
            Best_pos = Positions(i, :);
            Best_detail = population_details{i};
        end
    end

    % 动态质量差值 delta_F=max(rho*abs(F_best),1)，用于停滞重构。
    characteristic_difference = max( ...
        characteristic_difference_ratio * abs(Best_score), 1);

    % 曲线第一个点表示初始化结束后的最优结果，不计为外层迭代。
    CPU_time = toc;
    Convergence_curve(1) = Best_score;
    Time_curve(1) = CPU_time;

    % ===== 4. 时间控制的种群迭代 =====
    while toc < max_time
        % 保存代初全局最优，用于判断本代是否取得严格改善。
        best_before_generation = Best_score;

        % 子代先完整保存，代末再根据正常或停滞状态统一选择更新方式。
        Offspring = zeros(popsize, dim);
        offspring_fit = inf(popsize, 1);
        offspring_details = cell(popsize, 1);
        offspring_count = 0;

        % 每个位置生成一个子代：50%使用全局最优，否则由当前位置与
        % 一个随机位置执行二元锦标赛选出适应度更好的父代。
        for i = 1:popsize
            % 固定以 50% 概率直接使用全局最优，另外 50% 执行二元锦标赛。
            if rand < 0.50
                parent_pos = Best_pos;
            else
                % 二元锦标赛固定包含第 i 个位置，再随机抽取另一个位置；
                % 选择适应度更小者，相等时以 50% 概率任选一方。
                random_index = randi(popsize);
                if fit(i) < fit(random_index)
                    parent_index = i;
                elseif fit(random_index) < fit(i)
                    parent_index = random_index;
                elseif rand < 0.50
                    parent_index = i;
                else
                    parent_index = random_index;
                end
                parent_pos = Positions(parent_index, :);
            end

            % 每个被选父代仅生成并评价一个随机混沌子代。
            child_pos = HCHAO_generate_child(parent_pos, lb, ub, dim, maps);
            [child_fit, child_detail] = fobj(child_pos);
            FEs = FEs + 1;

            offspring_count = offspring_count + 1;
            Offspring(offspring_count, :) = child_pos;
            offspring_fit(offspring_count) = child_fit;
            offspring_details{offspring_count} = child_detail;

            % 历史全局最优独立于种群替换
            if child_fit <= Best_score
                Best_score = child_fit;
                Best_pos = child_pos;
                Best_detail = child_detail;
                characteristic_difference = max( ...
                    characteristic_difference_ratio * abs(Best_score), 1);
            end
        end

        iteration_count = iteration_count + 1;

        % 只有严格更新全局最优才清零停滞计数，相等替换不算改善。
        generation_improved = Best_score < best_before_generation;
        if generation_improved
            stall_count = 0;
        else
            stall_count = stall_count + 1;
        end

        if stall_count >= stall_generation_limit
            % 停滞时合并父代和子代，在 F_best+delta_F 阈值内优先选择
            % 调度距离大的不重复个体，再按适应度补齐固定种群规模。
            % 停滞代不执行一对一替换，而是将当前父代和本代子代合并。
            combined_positions = [Positions; Offspring(1:offspring_count, :)];
            combined_fit = [fit; offspring_fit(1:offspring_count)];
            combined_details = [ ...
                population_details; offspring_details(1:offspring_count)];
            [Positions, fit, population_details] = ...
                HCHAO_rebuild_population( ...
                    combined_positions, combined_fit, combined_details, ...
                    popsize, Best_score, characteristic_difference);
            % 一次多样性重构完成后重新开始统计连续无改善代数。
            stall_count = 0;
        else
            % 正常代采用一对一替换：子代更优时必然替换；适应度相等时
            % 以 50% 概率替换，使同质量的不同调度能够在种群中移动。
            for i = 1:offspring_count
                % 相对容差用于识别浮点意义下的相等适应度。
                fitness_tolerance = 1e-12 * max(1, abs(fit(i)));
                fitness_difference = offspring_fit(i) - fit(i);
                replace_parent = fitness_difference < -fitness_tolerance;
                if abs(fitness_difference) <= fitness_tolerance
                    % 父子适应度相等时，固定以 50% 概率接受子代。
                    replace_parent = rand < 0.50;
                end

                if replace_parent
                    Positions(i, :) = Offspring(i, :);
                    fit(i) = offspring_fit(i);
                    population_details{i} = offspring_details{i};
                end
            end
        end

        % ===== 5. 记录本代结果 =====
        CPU_time = toc;
        Convergence_curve(iteration_count + 1) = Best_score; %#ok<AGROW>
        Time_curve(iteration_count + 1) = CPU_time; %#ok<AGROW>

    end

    % ===== 6. 封装统一输出 =====
    CPU_time = toc;
    output = build_algorithm_output( ...
        algorithm_name, popsize, CPU_time, max_time, FEs, ...
        Best_pos, Best_score, Convergence_curve, Time_curve, Best_detail);
end
