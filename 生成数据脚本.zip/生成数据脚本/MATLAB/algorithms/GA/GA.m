function output=GA(max_time,lb,ub,dim,fobj,~,options)
% Real-coded generational GA: binary tournament, arithmetic crossover,
% individual-level mutation event with one uniformly reset allowed gene,
% one elite. Each child selects one of seven nonempty segment combinations.
if nargin<7, options=struct(); end
P=x3_option(options,'Pop',30); pc=x3_option(options,'pc',0.5); pm=x3_option(options,'pm',0.2);
tic; X=initialize_population(P,dim,lb,ub,fobj,'random'); F=zeros(P,1);
best=Inf; bestx=[]; bestdetail=struct(); count=0; times=[]; curve=[];
for i=1:P
    [F(i),d]=fobj(X(i,:)); count=count+1;
    if F(i)<best, best=F(i); bestx=X(i,:); bestdetail=d; end
end
while toc<max_time
    next=X; nextF=F; [~,elite]=min(F); next(1,:)=X(elite,:); nextF(1)=F(elite);
    for i=2:P
        pair=randi(P,1,2); [~,j]=min(F(pair)); a=X(pair(j),:);
        pair=randi(P,1,2); [~,j]=min(F(pair)); b=X(pair(j),:);
        indices=select_random_segment_indices(dim); child=a;
        if rand<pc
            mix=rand(1,numel(indices));
            child(indices)=mix.*a(indices)+(1-mix).*b(indices);
        end
        if rand<pm
            k=indices(randi(numel(indices))); child(k)=lb(k)+rand*(ub(k)-lb(k));
        end
        [nextF(i),d]=fobj(child); count=count+1; next(i,:)=child;
        if nextF(i)<best, best=nextF(i); bestx=child; bestdetail=d; end
    end
    X=next; F=nextF; times(end+1)=toc; curve(end+1)=best;
end
output=build_algorithm_output('GA',P,toc,max_time,count,bestx,best,curve,times,bestdetail);
end
