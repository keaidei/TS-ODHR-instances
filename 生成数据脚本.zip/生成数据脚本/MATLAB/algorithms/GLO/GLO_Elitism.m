﻿function [Group, Best_pos, Best_score, FEs, Best_detail] = GLO_Elitism(Group, Best_pos, Best_score, new, fobj, i, lb, ub, FEs, Best_detail)
% GLO_Elitism 评价候选灰叶猴并执行精英保留。
% -------------------------------------------------------------------------
% 输入/输出变量说明：
%   Group       : 当前群体结构体，Group.Member(i) 为被更新的成员。
%   Best_pos    : 全局最优位置。
%   Best_score  : 全局最优目标值，越小越好。
%   new         : 新候选成员，new.X 为候选位置。
%   fobj        : 调度目标函数句柄。
%   i           : 当前群体内成员编号。
%   lb, ub      : 搜索空间上下界。
%   FEs         : 函数评价次数。
%   Best_detail : 全局最优调度细节。
%
% 精英更新逻辑：
%   1) 用 boundary_check 保证候选解在合法边界内；
%   2) 若 new.Cost 优于当前成员，则替换当前成员；
%   3) 若 new.Cost 优于群体 Alpha 或全局最优，则同步更新。
% -------------------------------------------------------------------------

    new.X = boundary_check(new.X, lb, ub);
    [new.Cost, detail] = fobj(new.X);
    FEs = FEs + 1;

    if new.Cost < Group.Member(i).Cost
        Group.Member(i) = new;
    end
    if new.Cost < Group.Alpha.Cost
        Group.Alpha = new;
    end
    if new.Cost < Best_score
        Best_score = new.Cost;
        Best_pos = new.X;
        Best_detail = detail;
    end
end
