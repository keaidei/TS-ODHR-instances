function newX = GLO_update_alpha( ...
        X, Best_X, ASF, search_progress, lb, ub, D, update_indices)
% GLO_UPDATE_ALPHA 根据时间进度更新群体中的 alpha 个体。

    search_progress = min(max(search_progress, 0), 1);
    newX = X;
    if rand < 0.5
        levy = 1 ./ (abs(randn(1, D)) .^ (1 / 1.5));
        direction_scale = -5 + 10 * rand;
        step_scale = ASF * max(1 - search_progress, 0.4) * ...
            (ub - lb) / 30;
        newX(update_indices) = X(update_indices) + ...
            direction_scale * step_scale(update_indices) .* ...
            levy(update_indices);
    else
        mu = -0.1 + 0.2 * rand(1, D);
        C1 = (10 - search_progress) * mu;
        newX(update_indices) = X(update_indices) + ...
            C1(update_indices) .* ...
            (X(update_indices) - Best_X(update_indices));
    end
end
