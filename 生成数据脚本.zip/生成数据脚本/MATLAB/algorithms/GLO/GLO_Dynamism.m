﻿function Group = GLO_Dynamism(Group, omega, phi)
% GLO_Dynamism 执行灰叶猴群体之间的迁移机制。
% -------------------------------------------------------------------------
% 输入变量说明：
%   Group : 三类灰叶猴群体结构体，Group(g).Member 保存第 g 组成员。
%   omega : 单个成员发生迁移的概率。
%   phi   : 每个群体允许迁出的最小成员数量阈值，避免某个群体被迁空。
%
% 算法含义：
%   GLO 把种群划分为 one-male、multi-male、all-male 三个社会群体。
%   动态迁移算子以概率 omega 将成员从当前群体移动到另一个随机群体：
%      Group_dst <- Group_dst union member
%      Group_src <- Group_src \ member
%   迁移可以在群体之间传播优秀结构，同时维持多群体探索。
% -------------------------------------------------------------------------

    group_count = 3;                         % GLO 固定使用三类社会群体
    for source_group = 1:group_count
        migrated_member_indices = [];
        member_count = numel(Group(source_group).Member);
        for member_index = 1:member_count
            if rand <= omega && numel(Group(source_group).Member) > phi
                candidate_groups = setdiff(1:group_count, source_group);
                destination_group = candidate_groups(randi(numel(candidate_groups)));

                destination_index = numel(Group(destination_group).Member) + 1;
                Group(destination_group).Member(destination_index).X = ...
                    Group(source_group).Member(member_index).X;
                Group(destination_group).Member(destination_index).Cost = ...
                    Group(source_group).Member(member_index).Cost;

                migrated_member_indices = [migrated_member_indices member_index]; %#ok<AGROW>
                if numel(Group(source_group).Member) - numel(migrated_member_indices) < phi
                    break;
                end
            end
        end

        if ~isempty(migrated_member_indices)
            Group(source_group).Member(migrated_member_indices) = [];
        end
    end
end
