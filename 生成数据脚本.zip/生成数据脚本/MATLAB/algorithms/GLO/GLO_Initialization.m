﻿function Group = GLO_Initialization(Sol, N)
% GLO_Initialization 初始化灰叶猴算法的三类社会群体。
% -------------------------------------------------------------------------
% 输入变量说明：
%   Sol : 初始个体结构体数组，Sol(i).X 为位置，Sol(i).Cost 为目标值。
%   N   : 种群规模。
%
% 输出变量说明：
%   Group(1) : one-male 群体。
%   Group(2) : multi-male 群体。
%   Group(3) : all-male 群体。
%
% 算法含义：
%   原始 GLO 将种群划分为三种社会结构。每个群体内部按 Cost 升序排序，
%   排名第一的个体作为该群体 Alpha，后续 male/female/child 更新都会
%   基于这个排序结构进行。
% -------------------------------------------------------------------------

    group_sizes = cumsum([floor(N/3), floor(N/3), N - 2 * floor(N/3)]);
    Group(1).Member = Sol(1:group_sizes(1));
    Group(2).Member = Sol(group_sizes(1)+1:group_sizes(2));
    Group(3).Member = Sol(group_sizes(2)+1:group_sizes(3));

    for group_index = 1:3
        [~, sorted_index] = sort([Group(group_index).Member.Cost]);
        Group(group_index).Member = Group(group_index).Member(sorted_index);
        Group(group_index).Alpha = Group(group_index).Member(1);
    end
end
