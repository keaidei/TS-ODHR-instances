﻿function newX = GLO_update_female(Member, Nm, i, D, ASF, update_indices)
% GLO_update_female 根据 mate 引导更新 female 个体位置。
% -------------------------------------------------------------------------
% female 个体更新公式：
%   newX = X_i + randn*0.8*ASF .* (X_mate - X_i)
% mate 由轮盘赌从前 Nm 个成员中选出。ASF 控制移动幅度，迭代后期减小，
% 因此 female 个体前期更容易靠近配偶方向探索，后期更偏局部开发。
% -------------------------------------------------------------------------


    mate = GLO_RouletteWheelSelection([Member(1:Nm).Cost]); % 按适应度选择配偶个体
    newX = Member(i).X;
    random_weight = randn(1, D) * .8 * ASF;
    newX(update_indices) = Member(i).X(update_indices) + ...
        random_weight(update_indices) .* ...
        (Member(mate).X(update_indices) - Member(i).X(update_indices));

end


%%


%__________________________________________________________________ %
%                                                                   %
%                                                                   %
%                    Gray Langurs Optimizer (GLO)                   %
%                                                                   %
%                                                                   %
%               Developed in MATLAB R2024b (MacOs-Monterey)         %
%                                                                   %
%                                                                   %
%                                                                   %
%                                                                   %
%                                                                   %
%                            e-Mail                                 %
%                ---------------------------------                  %
%                         nimakhan@berkeley.edu                     %                                                                  %
%                                                                   %
%                                                                   % 
%                    https://nimakhodadadi.com                      %
%                                                                   %
%                                                                   %
%                                                                   %
%                                                                   %
%                        Cite this article                          %
%       Barshandeh, S., Khodadadi, N., Abdollahzadeh, B. et al.     %
%  Gray langurs optimizer: a multi-group bio-inspired optimization  %
%               algorithm. Artif Intell Rev (2026)                  %
%           https://doi.org/10.1007/s10462-026-11529-2              %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
