function [Group, Best_pos, Best_score, FEs, Best_detail] = GLO_Autonomy( ...
        Group, Best_pos, Best_score, search_progress, max_time, ...
        lb, ub, D, fobj, FEs, Best_detail)
% GLO_AUTONOMY 执行由时间进度控制的 Levy 自主游走。

    search_progress = min(max(search_progress, 0), 1);
    stop_requested = false;
    for group_index = 1:3
        for member_index = 1:numel(Group(group_index).Member)
            if toc >= max_time
                stop_requested = true;
                break;
            end

            update_indices = select_random_segment_indices(D);
            levy_scale = rand .* (ub - lb) * ...
                exp(-20 * search_progress ^ 2);
            levy = 1 ./ (abs(randn(1, D)) .^ (1 / 1.5));
            direction = 2 * rand(1, D) - 1;
            step = direction .* levy_scale .* levy * 0.001;
            new.X = Group(group_index).Member(member_index).X;
            new.X(update_indices) = ...
                Group(group_index).Member(member_index).X(update_indices) + ...
                step(update_indices);

            [Group(group_index), Best_pos, Best_score, FEs, Best_detail] = ...
                GLO_Elitism( ...
                    Group(group_index), Best_pos, Best_score, new, fobj, ...
                    member_index, lb, ub, FEs, Best_detail);
        end

        if stop_requested
            break;
        end
    end
end
