﻿function selected_index = GLO_RouletteWheelSelection(p)
% GLO_RouletteWheelSelection 根据权重执行轮盘赌选择。
% -------------------------------------------------------------------------
% 输入变量说明：
%   p : 候选个体的目标函数值，目标越小代表个体越优。
%
% 输出变量说明：
%   selected_index : 被选中的候选个体下标。
%
% 算法含义：
%   面向最小化问题，将较小 Cost 转换成较大权重后再执行轮盘赌选择。
%   该函数主要用于 female 个体选择 mate。
% -------------------------------------------------------------------------

    cost = p(:)';
    finite_mask = isfinite(cost);
    if any(finite_mask)
        worst_cost = max(cost(finite_mask));
        weight = zeros(size(cost));
        weight(finite_mask) = worst_cost - cost(finite_mask) + eps;
    else
        weight = ones(size(cost));
    end

    if ~any(weight > 0)
        weight = ones(size(cost));
    end

    random_threshold = rand * sum(weight);
    cumulative_weight = cumsum(weight);
    selected_index = find(random_threshold <= cumulative_weight, 1, 'first');
    if isempty(selected_index)
        selected_index = numel(weight);
    end
end
