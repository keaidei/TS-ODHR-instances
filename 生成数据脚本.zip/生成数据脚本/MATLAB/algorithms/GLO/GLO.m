function output = GLO(max_time, lb, ub, dim, fobj, init_mode, options)
    if nargin < 7, options = struct(); end
% GLO 按用户提供的原始灰叶猴算法主体适配为时间终止版本
% 保留原三群体、迁移、自治和精英更新结构，只做统一接口、时间终止、FEs/曲线/output 输出。
% -------------------------------------------------------------------------
% 算子说明：
%   Group(1) one-male：alpha、female、child 三类个体分别调用不同更新公式；
%   Group(2) multi-male：male/female/child 并存，使用不同社会行为更新；
%   Group(3) all-male：第一个个体按 alpha 更新，其余按 male 更新；
%   GLO_Dynamism 负责群体迁移，GLO_Autonomy 使用 Levy 步长做自主游走；
%   每个社会行为算子在更新前先选择片段，再在允许维度执行原公式；
%   GLO_Elitism 只负责评价和精英接受。迁移仍只搬运完整成员。
%
% ASF = 0.1 + (1-progress)^2*0.9 是自适应缩放因子，前期较大便于
% 探索，后期减小以强化局部开发。
% 参数表 para 五列依次为：
%   种群规模 popsize、one-male 群体 female 比例 FP_om、
%   multi-male 群体 female 比例 FP_mm、multi-male 群体 male 比例 MP_mm、
%   迁移概率 omega。phi 固定为 5，不参与参数表选择。
% -------------------------------------------------------------------------
    init_mode = 'random';

    algorithm_name = 'GLO';
    para = [
        20  0.40  0.20  0.20  0.02
        20  0.40  0.30  0.30  0.05
        20  0.40  0.40  0.40  0.10
        30  0.50  0.20  0.30  0.10
        30  0.50  0.30  0.40  0.02
        30  0.50  0.40  0.20  0.05
        50  0.60  0.20  0.40  0.05
        50  0.60  0.30  0.20  0.10
        50  0.60  0.40  0.30  0.02
    ];
    paraindex = 1;                          % 第 2 行保持原始 GLO 默认参数
    popsize = para(paraindex, 1);
    FP_om = para(paraindex, 2);             % Female percentage in one-male group
    FP_mm = para(paraindex, 3);             % Female percentage in multi-male group
    MP_mm = para(paraindex, 4);             % Male percentage in multi-male group
    omega = para(paraindex, 5);             % Migration percentage
    popsize = x3_option(options,'Pop',popsize);
    FP_om = x3_option(options,'FP0',FP_om);
    FP_mm = x3_option(options,'FP1',FP_mm);
    MP_mm = x3_option(options,'MP',MP_mm);
    omega = x3_option(options,'omega',omega);
    phi = 5;                                % Minimum member count
    FEs = 0;                                % 函数评价次数
    fit = inf(popsize, 1);                  % 种群适应度
    Best_score = inf;                       % 当前最好适应度
    Best_pos = zeros(1, dim);               % 当前最好个体
    Best_detail = struct();                 % 当前最好调度细节
    Convergence_curve = [];                 % 最优值曲线，横轴为 Time_curve
    Time_curve = [];                        % 运行时间曲线
    % 初始化种群，统一采用 algorithms/common 中的公共初始化函数。
    % 计时从初始化之前开始，Time_curve 第一条记录包含初始化和初始评价耗时。
    tic;
    Positions = initialize_population(popsize, dim, lb, ub, fobj, init_mode);
    N = popsize;
    D = dim;

    Sol = repmat(struct('X', [], 'Cost', inf), 1, N);
    for i = 1:popsize
        Sol(i).X = Positions(i, :);
        [fit(i), detail] = fobj(Positions(i, :));
        Sol(i).Cost = fit(i);
        FEs = FEs + 1;
        if fit(i) < Best_score
            Best_score = fit(i);
            Best_pos = Positions(i, :);
            Best_detail = detail;
        end
    end

    %% Initialization
    Group = GLO_Initialization(Sol, N);

    %% Optimization
    CPU_time = toc;
    Convergence_curve(end+1) = Best_score;
    Time_curve(end+1) = CPU_time;
    while toc < max_time
        search_progress = min(CPU_time / max_time, 1);
        ASF = 0.1 + (1 - search_progress)^2 * .9; % 随时间进度衰减
        %% Group 1: One-male (including women and children)
        S_om = numel(Group(1).Member); % Size of all male group
        Nf = floor(S_om*FP_om);        % Eq. (11) number of female langurs
        
        for i = 1 : S_om
            update_indices = select_random_segment_indices(D);
            if i == 1
                % The first langur is alpha
                new.X = GLO_update_alpha(Group(1).Member(i).X, Best_pos, ASF, search_progress, lb, ub, D, update_indices);
            elseif i <= Nf
                % The next Nf langures are females
                new.X = GLO_update_female(Group(1).Member, 1, i, D, ASF, update_indices); 
            else
                % The ramaining langures are children
                new.X = GLO_update_child(Group(1).Member, 1, Nf, i, D, ASF, lb, ub, update_indices);
            end
            
            % Evaluation and GLO_Elitism
            [Group(1), Best_pos, Best_score, FEs, Best_detail] = GLO_Elitism(Group(1), Best_pos, Best_score, new, fobj, i, lb, ub, FEs, Best_detail);
        end
        
        % Maintaning the social structure (reordering the langurs)
        [~,sind] = sort([Group(1).Member.Cost]);
        Group(1).Member = Group(1).Member(sind);

        %% Group 2: Multi-male (women and children)
        S_mm = numel(Group(2).Member);    % Size of multi-male group
        Nm = max(floor(S_mm*MP_mm),1);    % Number of males Eq. (16)
        Nf = max(floor(S_mm*FP_mm),1);    % Number of females Eq. (17)
        
        for i = 1 : S_mm
            update_indices = select_random_segment_indices(D);
            if i == 1
                % The first langur is alpha
                new.X = GLO_update_alpha(Group(2).Member(i).X, Best_pos, ASF, search_progress, lb, ub, D, update_indices);
            elseif i <= Nm
                % The next Nm langurs are males
                new.X = GLO_update_male(Group(2).Member(i).X, Best_pos, search_progress, lb, ub, update_indices);
            elseif i <= Nm+Nf
                % The next Mf langurs are females
                new.X = GLO_update_female(Group(2).Member, Nm, i, D, ASF, update_indices);
            else
                % The remaining langures are children
                new.X = GLO_update_child(Group(2).Member, Nm, Nf, i, D, ASF, lb, ub, update_indices);
            end

            % Evaluation and GLO_Elitism
            [Group(2), Best_pos, Best_score, FEs, Best_detail] = GLO_Elitism(Group(2), Best_pos, Best_score, new, fobj, i, lb, ub, FEs, Best_detail);
        end
        
        % Maintaning the social structure (reordering the langurs)
        [~,sind] = sort([Group(2).Member.Cost]);
        Group(2).Member = Group(2).Member(sind);
        
        %% Group 3: All-male
        S_am = numel(Group(3).Member);   % Size of all-male group
        
        for i = 1 : S_am
            update_indices = select_random_segment_indices(D);
            if i==1
                % The first langur is alpha
                new.X = GLO_update_alpha(Group(3).Member(i).X, Best_pos, ASF, search_progress, lb, ub, D, update_indices);
            else
                % The remaining langurs are male
                new.X = GLO_update_male(Group(3).Member(i).X, Best_pos, search_progress, lb, ub, update_indices);
            end
            
            % Evaluation and GLO_Elitism
            [Group(3), Best_pos, Best_score, FEs, Best_detail] = GLO_Elitism(Group(3), Best_pos, Best_score, new, fobj, i, lb, ub, FEs, Best_detail);
        end
        
        % Maintaning the social structure (reordering the langurs)
        [~,sind] = sort([Group(3).Member.Cost]);
        Group(3).Member = Group(3).Member(sind);

        %% GLO_Dynamism (Migration)   
        Group = GLO_Dynamism(Group, omega, phi);
        
        %% GLO_Autonomy (roaming around)
        [Group, Best_pos, Best_score, FEs, Best_detail] = GLO_Autonomy( ...
            Group, Best_pos, Best_score, search_progress, max_time, ...
            lb, ub, D, fobj, FEs, Best_detail);
        
        %% Reporting
        CPU_time = toc;
        Convergence_curve(end+1) = Best_score; %#ok<AGROW>
        Time_curve(end+1) = CPU_time; %#ok<AGROW>


    end
CPU_time = toc;
output = build_algorithm_output(algorithm_name, popsize, CPU_time, max_time, FEs, Best_pos, Best_score, Convergence_curve, Time_curve, Best_detail);
end
