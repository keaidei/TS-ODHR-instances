﻿function newX = GLO_update_child(Member, Nm, Nf, current_index, D, ASF, lb, ub, update_indices)
% GLO_update_child 根据父代/母代组合更新 child 个体位置。
% -------------------------------------------------------------------------
% child 个体更新公式：
%   newX = fi*father + (1-fi)*mother + randn*0.05*ASF*(ub-lb)
% fi 是随机遗传权重，mi=1-fi；最后一项是小幅高斯扰动。
% -------------------------------------------------------------------------


    mother = randi([Nm+1 max(Nm+Nf,2)]); % 母代个体下标
    father = randi([1 Nm]);              % 父代个体下标
    fi = randn(1,D) .* ASF;              % 父代遗传权重
    mi = 1-fi;                           % 母代遗传权重
    newX = Member(current_index).X;
    random_step = randn(1, D) .* 0.05 * ASF .* (ub - lb);
    newX(update_indices) = ...
        fi(update_indices) .* Member(father).X(update_indices) + ...
        mi(update_indices) .* Member(mother).X(update_indices) + ...
        random_step(update_indices);  % Eq. (12)

end


%%

%__________________________________________________________________ %
%                                                                   %
%                                                                   %
%                    Gray Langurs Optimizer (GLO)                   %
%                        Cite this article                          %
%       Barshandeh, S., Khodadadi, N., Abdollahzadeh, B. et al.     %
%  Gray langurs optimizer: a multi-group bio-inspired optimization  %
%               algorithm. Artif Intell Rev (2026)                  %
%           https://doi.org/10.1007/s10462-026-11529-2              %
%                                                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

