function newX = GLO_update_male( ...
        X, Best_pos, search_progress, lb, ub, update_indices)
% GLO_UPDATE_MALE 根据时间进度更新 male 个体。

    search_progress = min(max(search_progress, 0), 1);
    C2 = 1 + randn;
    inertia = max(0.4, 0.9 * (1 - search_progress));
    gaussian_step = randn * (ub - lb);
    newX = X;
    newX(update_indices) = X(update_indices) + ...
        inertia * (X(update_indices) - Best_pos(update_indices)) + ...
        C2 * gaussian_step(update_indices);
end
