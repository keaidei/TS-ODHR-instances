function output = WOA(max_time, lb, ub, dim, fobj, init_mode, options)
    if nargin < 7, options = struct(); end
% WOA 基础鲸鱼优化算法（仅使用运行时间终止）
% -------------------------------------------------------------------------
% 核心公式说明：
%   A = 2*a*r1 - a，C = 2*r2
%     a 按已用时间比例从 2 线性递减到 0；|A|>=1 时偏全局探索，
%     |A|<1 时偏向当前最优解开发。
%   D = |C*X_ref - X_i|
%     表示当前个体 X_i 到参考个体 X_ref 的加权距离。
%   X_i = X_ref - A*D
%     当 X_ref 为随机个体时执行探索；当 X_ref 为 Best_pos 时执行包围猎物。
%   X_i = |Best_pos-X_i|*exp(b*l)*cos(2*pi*l)+Best_pos
%     螺旋气泡网捕食模型，围绕当前最优解做螺旋式开发。
%   参数表 para 三列依次为：种群数 popsize、螺旋形状常数 b_const、
%     包围/搜索算子选择阈值 operator_select_probability。
%   每只鲸鱼先从七种非空片段组合中等概率选出允许维度，再仅在这些维度
%   上执行原 WOA 更新公式；未选维度从始至终不参与本次公式计算。
% -------------------------------------------------------------------------
    init_mode = 'random';

    algorithm_name = 'WOA';
    para = [
        20  0.50  0.20
        20  1.00  0.50
        20  1.50  0.80
        30  0.50  0.50
        30  1.00  0.80
        30  1.50  0.20
        50  0.50  0.80
        50  1.00  0.20
        50  1.50  0.50
    ];
    paraindex = 9;                          % 第 2 行保持原始 WOA 默认参数：20, 1.00, 0.50
    popsize = para(paraindex, 1);
    b_const = para(paraindex, 2);
    operator_select_probability = para(paraindex, 3);
    popsize = x3_option(options,'Pop',popsize);
    b_const = x3_option(options,'beta',b_const);
    operator_select_probability = x3_option(options,'p',operator_select_probability);
    FEs = 0;                                % 函数评价次数
    fit = inf(popsize, 1);                  % 种群适应度
    Best_score = inf;                       % 当前最好适应度
    Best_pos = zeros(1, dim);               % 当前最好个体
    Best_detail = struct();                 % 当前最好调度细节
    Convergence_curve = [];                 % 最优值曲线，横轴为 Time_curve
    Time_curve = [];                        % 运行时间曲线
    % ===== 1. 使用 algorithms/common 中的统一种群初始化入口 =====
    % 计时从初始化之前开始，Time_curve 第一条记录包含初始化和初始评价耗时。
    tic;
    Positions = initialize_population(popsize, dim, lb, ub, fobj, init_mode);

    % ===== 2. 初始化和初始评价共用同一个计时器，这里读取当前已耗时间。
 
    % ===== 3. 初始种群评价 =====
    for i = 1:popsize
        [fitness, detail] = fobj(Positions(i,:));
        FEs = FEs + 1;
        fit(i) = fitness;
        if fitness <= Best_score
            Best_score = fitness;
            Best_pos = Positions(i,:);
            Best_detail = detail;
        end
    end
    CPU_time = toc;
    Convergence_curve(end+1) = Best_score;
    Time_curve(end+1) = CPU_time;

    % ===== 4. 主循环：仅由运行时间终止 =====
    while toc < max_time
        search_progress = min(CPU_time / max_time, 1);

        % WOA 自适应因子只依赖时间进度。
        a = 2 * (1 - search_progress);
        a2 = -1 - search_progress;

        % ===== 4.1 位置更新：基础 WOA 搜索算子 =====
        for i = 1:popsize
            update_indices = select_random_segment_indices(dim);

            r1 = rand();
            r2 = rand();
            A = 2 * a * r1 - a;       % 收缩包围系数，绝对值决定探索或开发
            C = 2 * r2;               % 距离扰动系数，用于调整参考个体的影响
            l = (a2 - 1) * rand() + 1; % 螺旋路径参数，随时间逐渐偏向开发
            p = rand();               % 算子选择随机值：低于阈值用包围/搜索，否则用螺旋

            for j = update_indices
                if p < operator_select_probability
                    if abs(A) >= 1
                        % 探索阶段：远离/靠近随机鲸鱼，增加跳出局部最优的机会。
                        rand_leader_index = randi(popsize);
                        X_rand = Positions(rand_leader_index, :);
                        D_X_rand = abs(C * X_rand(j) - Positions(i,j));
                        Positions(i,j) = X_rand(j) - A * D_X_rand;
                    else
                        % 开发阶段：以当前全局最优 Best_pos 为参考进行收缩包围。
                        D_Leader = abs(C * Best_pos(j) - Positions(i,j));
                        Positions(i,j) = Best_pos(j) - A * D_Leader;
                    end
                else
                    % 螺旋更新：模拟鲸鱼围绕猎物收缩游动，强化最优解附近搜索。
                    distance2Leader = abs(Best_pos(j) - Positions(i,j));
                    Positions(i,j) = distance2Leader * exp(b_const * l) * cos(2*pi*l) + Best_pos(j);
                end
            end
        end

        Positions = boundary_check(Positions, lb, ub);

        % ===== 4.2 评价新种群并更新最优解 =====
        for i = 1:popsize
            [fitness, detail] = fobj(Positions(i,:));
            FEs = FEs + 1;
            fit(i) = fitness;
            if fitness <= Best_score
                Best_score = fitness;
                Best_pos = Positions(i,:);
                Best_detail = detail;
            end
        end

        CPU_time = toc;
        Convergence_curve(end+1) = Best_score; %#ok<AGROW>
        Time_curve(end+1) = CPU_time; %#ok<AGROW>


    end

    % ===== 5. 输出单次运行信息 =====
    CPU_time = toc;
    output = build_algorithm_output(algorithm_name, popsize, CPU_time, max_time, FEs, Best_pos, Best_score, Convergence_curve, Time_curve, Best_detail);
end
