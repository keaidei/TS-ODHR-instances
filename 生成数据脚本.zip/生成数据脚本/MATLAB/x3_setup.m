function root=x3_setup()
% Place this experiment snapshot before legacy folders on the MATLAB path.
root=fileparts(mfilename('fullpath'));
addpath(genpath(fullfile(root,'algorithms')),'-begin');
addpath(fullfile(root,'problem'),fullfile(root,'data'), ...
    fullfile(root,'experiments'),fullfile(root,'tests'),'-begin');
end
