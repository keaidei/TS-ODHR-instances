﻿function operation_sequence = decode_priority(priority_values, task_set, operation_map, indegree, index_map)
% DECODE_PRIORITY 在满足 DAG 依赖的前提下解码工序优先级。
% -------------------------------------------------------------------------
% priority_values 是算法给出的连续优先级片段；数值越小，越倾向于更早调度。
% 但同一任务内部必须满足 DAG 前驱约束，所以这里采用拓扑排序思想：
%   1. 先找入度为 0 的 ready 工序；
%   2. 每次只在 ready 集合中选择 priority_values 最小的工序；
%   3. 选择后降低其后继工序入度；
%   4. 新入度为 0 的后继加入 ready 集合。
% 这样既利用算法搜索出的优先级，又不会产生违反依赖关系的调度顺序。
% -------------------------------------------------------------------------

    operation_count = size(operation_map, 2);
    operation_sequence = [];

    % ===== 初始 ready 集合 =====
    % ready_set 中保存“当前所有前驱都已被安排”的全局工序索引。
    ready_set = find(indegree == 0);

    % ===== 主循环 =====
    while ~isempty(ready_set)

        % 只在 ready_set 内选择优先级最小的工序，保证不会越过前驱约束。
        [~, local_ready_index] = min(priority_values(ready_set));
        chosen_operation_index = ready_set(local_ready_index);

        task_id = operation_map(2, chosen_operation_index);
        operation_id = operation_map(3, chosen_operation_index);

        operation_sequence = [operation_sequence; task_id, operation_id]; %#ok<AGROW>

        % 被安排的工序从 ready_set 移除。
        ready_set(local_ready_index) = [];

        % ===== 更新后继入度 =====
        successors = task_set(task_id).O(operation_id).SOUT;

        for successor_id = successors
            successor_key = sprintf('%d_%d', task_id, successor_id);
            successor_index = index_map(successor_key);

            indegree(successor_index) = indegree(successor_index) - 1;

            if indegree(successor_index) == 0
                ready_set = [ready_set; successor_index]; %#ok<AGROW>
            end
        end

    end

    % 如果没有解码出全部工序，说明输入 DAG 可能不连通或存在环。
    if size(operation_sequence, 1) ~= operation_count
        error('DAG 有问题：可能不连通或存在环，无法完成拓扑解码。');
    end

    operation_sequence = operation_sequence';
end
