﻿function transfer_time = calc_trans(data_size, source_device_id, target_device_id, connectivity_matrix, bandwidth_matrix)
% CALC_TRANS 计算两个设备之间的数据传输时间。
% -------------------------------------------------------------------------
% 输入：
%   data_size           : 前驱工序输出的数据量；
%   source_device_id    : 前驱工序所在设备；
%   target_device_id    : 当前工序所在设备；
%   connectivity_matrix : 联通性矩阵，1 表示设备间可通信；
%   bandwidth_matrix    : 传输速率矩阵。
%
% 输出：
%   transfer_time       : data_size / bandwidth；若不可直连则返回 inf。
% -------------------------------------------------------------------------

    if connectivity_matrix(source_device_id, target_device_id) == 1
        transfer_time = data_size / bandwidth_matrix(source_device_id, target_device_id);
    else
        % 不可通信的设备组合视为不可行，通过 inf 让调度结果自然被淘汰。
        transfer_time = inf;
    end

end
