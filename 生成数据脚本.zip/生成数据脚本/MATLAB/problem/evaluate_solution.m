function [fitness, detail] = evaluate_solution(position, problem)
% EVALUATE_SOLUTION 统一适应度函数。
% -------------------------------------------------------------------------
% 输入：
%   position : 算法产生的一条连续编码个体；
%   problem  : get_problem 打包后的调度问题结构体。
%
% 输出：
%   fitness : 所有任务完成时间之和 C_sum；
%   detail  : 解码向量和调度细节，供最优解绘制甘特图时使用。
%
% 说明：
%   所有算法只需要调用 fobj(position)，不直接访问任务、设备和网络数据。
%   这样可以把“算法搜索逻辑”和“边缘计算调度评价逻辑”隔离开。
% -------------------------------------------------------------------------

    detail = struct();

    try
        % 1. 将连续编码映射为调度向量。
        schedule_vector = map_method(position, problem.dim, problem.lb, problem.ub, ...
            problem.operation_map, problem.T, problem.indegree, problem.index_map);

        % 2. 仅校正 type=2 设备：这类设备强制使用最大合法资源模式。
        for operation_index = 1:size(schedule_vector, 2)
            device_id = schedule_vector(3, operation_index);
            if problem.D(device_id).type ~= 2
                continue;
            end

            task_id = problem.operation_map(2, operation_index);
            operation_id = problem.operation_map(3, operation_index);
            operation = problem.T(task_id).O(operation_id);
            device_option_index = find(operation.SDEV == device_id, 1);
            legal_mu_list = unique(max(1, floor( ...
                operation.mode(device_option_index).mu(:)')), 'stable');

            if isempty(legal_mu_list)
                error('当前工序在设备 %d 下没有合法资源模式。', device_id);
            end

            schedule_vector(4, operation_index) = max(legal_mu_list);
        end

        % 3. 调用调度函数计算 C_sum，并继续记录 makespan 作为评价指标。
        schedule_result = schedule_with_detail(schedule_vector, problem.T, problem.D, ...
            problem.B, problem.b, problem.operation_lookup);

        % 优化目标仅为所有任务完成时间之和，不再包含 makespan。
        fitness = schedule_result.total_task_completion_time;
        detail.vector = schedule_vector;
        detail.schedule_result = schedule_result;
        detail.makespan = schedule_result.makespan;
        detail.task_completion_times = schedule_result.task_completion_times;
        detail.total_task_completion_time = ...
            schedule_result.total_task_completion_time;
        detail.objective_value = fitness;

        if ~isfinite(fitness)
            fitness = inf;
        end

    catch exception
        if isfield(problem,'strict') && problem.strict, rethrow(exception); end
        % 解码或调度失败时，该个体视为不可行解。
        fitness = inf;
        detail.error = exception.message;
    end
end
