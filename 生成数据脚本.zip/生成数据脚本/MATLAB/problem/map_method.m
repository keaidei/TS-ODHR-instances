﻿function schedule_vector = map_method(position, dim, ~, ~, operation_map, task_set, indegree, index_map)
% MAP_METHOD 将算法产生的连续编码映射为可调度的离散向量。
% -------------------------------------------------------------------------
% 连续编码被拆成三段：
%   priority_code : 工序优先级段，交给 decode_priority 做满足 DAG 约束的拓扑解码；
%   device_code   : 设备选择段，通过取模映射到该工序的候选设备 SDEV；
%   resource_code : 资源模式段，通过取模映射到所选设备对应的合法 mode.mu。
%
% 输出 schedule_vector 为 4 x N 矩阵：
%   第 1 行：调度顺序中的任务编号 u；
%   第 2 行：调度顺序中的工序编号 v；
%   第 3 行：按全局工序索引保存的设备编号；
%   第 4 行：按全局工序索引保存的资源块数量 mu。
% -------------------------------------------------------------------------

    position = abs(position);
    operation_count = dim / 3;

    priority_code = position(1, 1:operation_count);
    device_code = position(1, operation_count+1:2*operation_count);
    resource_code = position(1, 2*operation_count+1:3*operation_count);

    % 工序顺序不能只按连续值排序，否则可能破坏同一任务 DAG 的前驱约束。
    % decode_priority 会在“当前入度为 0 的 ready 集合”中按优先级挑选工序。
    operation_sequence = decode_priority( ...
        priority_code, task_set, operation_map, indegree, index_map);

    selected_devices = device_code;
    selected_resources = resource_code;

    for operation_index = 1:size(operation_map, 2)
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        operation = task_set(task_id).O(operation_id);

        % 将连续设备编码折算到候选设备列表下标，再取出真实设备编号。
        device_option_index = mod( ...
            fix(selected_devices(1, operation_index)), ...
            numel(operation.SDEV)) + 1;
        selected_devices(1, operation_index) = operation.SDEV(device_option_index);

        % 资源模式必须与已选设备匹配，因此先定位设备下标，再从 mode.mu 中选合法 mu。
        resource_option_index = mod( ...
            fix(selected_resources(1, operation_index)), ...
            numel(operation.mode(device_option_index).mu)) + 1;
        selected_resources(1, operation_index) = ...
            operation.mode(device_option_index).mu(resource_option_index);
    end

    schedule_vector = [operation_sequence; selected_devices; selected_resources];
end
