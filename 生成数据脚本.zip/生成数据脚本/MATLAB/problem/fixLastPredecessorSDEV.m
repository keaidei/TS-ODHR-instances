﻿function T = fixLastPredecessorSDEV(T)
% fixLastPredecessorSDEV
% 功能：
%   若某个任务的首操作唯一候选设备与末操作唯一候选设备不同，
%   则删除“末操作直接前驱操作”的候选设备集合 SDEV 中的首操作本地设备。
%
% 输入：
%   T        任务结构体数组，T(u).O 为第 u 个任务的操作结构体数组
%
% 输出：
%   T        修正后的任务结构体数组

for u = 1:numel(T)

    if ~isfield(T(u), 'O') || isempty(T(u).O)
        continue;
    end

    O = T(u).O;
    nOp = numel(O);

    if nOp < 2
        continue;
    end

    % 首操作唯一候选设备
    startDev = O(1).SDEV;

    % 末操作唯一候选设备
    endDev = O(nOp).SDEV;

    % 只有首操作和末操作都是唯一候选设备，且二者不同时，才进行修正
    if ~(isnumeric(startDev) && isnumeric(endDev))
        continue;
    end

    if numel(startDev) ~= 1 || numel(endDev) ~= 1
        continue;
    end

    if startDev == endDev
        continue;
    end

    % 末操作的直接前驱操作集合
    preOps = O(nOp).SIN;

    if isempty(preOps)
        continue;
    end

    for kk = 1:numel(preOps)

        opId = preOps(kk);

        % 默认操作 id 与数组下标一致
        opIdx = opId;

        % 若结构体中存在 id 字段，则按 id 查找真实下标，更稳妥
        if isfield(O, 'id')
            tmpIdx = find([O.id] == opId, 1);
            if ~isempty(tmpIdx)
                opIdx = tmpIdx;
            end
        end

        if opIdx < 1 || opIdx > nOp
            error('任务 %d 中前驱操作编号 %d 超出范围。', u, opId);
        end

        oldSDEV = O(opIdx).SDEV;

        % 查找首操作本地设备在该前驱操作候选设备集合中的位置
        delIdx = find(oldSDEV == startDev);

        if isempty(delIdx)
            continue;
        end

        newSDEV = oldSDEV;
        newSDEV(delIdx) = [];

        % 防止删空候选设备集合
        if isempty(newSDEV)
            error('任务 %d 的操作 %d 删除设备 %d 后 SDEV 为空，请检查数据生成逻辑。', ...
                u, opId, startDev);
        end

        % 更新 SDEV
        O(opIdx).SDEV = newSDEV;

        % 如果 mode 与 SDEV 一一对应，则同步删除对应 mode
        if isfield(O, 'mode') && numel(O(opIdx).mode) == numel(oldSDEV)
            O(opIdx).mode(delIdx) = [];
        end

    end

    T(u).O = O;
end

end
