function [lb, ub, dim, fobj, problem_info, problem] = get_problem(data_file)
% -------------------------------------------------------------------------
% 输入：
%   data_file : 数据集文件名，例如 '3_20_148.mat'、'3_3_24.mat'、'3_4_31.mat'
%
% 输出：
%   lb, ub          : 三段连续编码的上下界
%   dim             : 连续编码维度
%   fobj            : 目标函数句柄，所有算法统一调用该句柄求解同一问题
%   problem_info    : 数据集与问题规模信息，用于 main.m 打印和保存
%   problem         : 调度问题结构体，封装任务、设备、网络和编码映射
% -------------------------------------------------------------------------

    % ===== 1. 定位数据文件 =====
    % 数据集统一保存在项目 data/ 目录下。这里不再使用 which(data_file)，
    % 避免 MATLAB 路径中存在同名 MAT 文件时误加载到根目录或其他目录的数据。
    project_root = fileparts(fileparts(mfilename('fullpath')));
    data_dir = fullfile(project_root, 'data');
    data_path = fullfile(data_dir, data_file);

    if ~isfile(data_path)
        error('未找到数据文件 %s。请确认该文件位于 data/ 目录中：%s', data_file, data_dir);
    end

    % ===== 2. 读取项目统一 MAT 数据格式 =====
    % 使用结构体接收 load 结果，避免 MAT 文件变量和路径上的函数重名时产生歧义。
    dataset = load(data_path);
    required_fields = {'m', 'M', 'D_num', 'D', 'b', 'B', 'n', 'T'};
    missing_fields = required_fields(~isfield(dataset, required_fields));
    if ~isempty(missing_fields)
        error('数据文件 %s 缺少必要变量：%s', data_file, strjoin(missing_fields, ', '));
    end

    edge_device_count = dataset.m;     % 边缘设备数量
    local_device_count = dataset.M;    % 本地设备数量
    device_count = dataset.D_num;      % 系统设备总数
    D = dataset.D;                     % 设备结构体数组
    b = dataset.b;                     % 设备间传输速率矩阵
    B = dataset.B;                     % 设备间联通性矩阵
    task_count = dataset.n;            % 任务数量
    T = dataset.T;                     % 任务结构体数组，每个任务包含多个工序

    % ===== 3. 记录当前输入数据集信息 =====
    % problem_info 仅用于显示与结果保存，不参与改变问题本身。
    problem_info = struct();
    problem_info.data_file = data_file;
    problem_info.data_path = data_path;

    problem_info.task_num = task_count;
    problem_info.device_num = device_count;
    % creat_data 中约定：m 表示边缘设备数，M 表示本地设备数。
    % 这里仅修正显示/记录字段名，不改变优化问题本身。
    problem_info.edge_num = edge_device_count;
    problem_info.local_num = local_device_count;

    % ===== 4. 修复不可行候选设备 =====
    % 这里保留原工程中对候选设备的修复逻辑，不改调度问题定义。
    T = fixLastPredecessorSDEV(T);

    % ===== 5. 构建操作映射 operation_map =====
    % operation_map 的三行含义：
    %   第 1 行：全局操作编号
    %   第 2 行：该操作所属任务编号 u
    %   第 3 行：该操作在任务内部的操作编号 v
    % 该映射用于后续连续编码解码和调度评价。
    operation_counter = 0;             % 已累计的全局工序数量
    operation_map = [];                % 3 x N 操作映射表，列号即全局工序编号
    for task_id = 1:task_count
        operation_num = numel(T(task_id).O);                 % 当前任务包含的工序数量
        operation_range = operation_counter + (1:operation_num); % 当前任务工序对应的全局编号
        operation_map(1, operation_range) = operation_range;
        operation_map(2, operation_range) = task_id;
        operation_map(3, operation_range) = 1:operation_num;
        operation_counter = operation_counter + operation_num;
    end

    % ===== 6. 构建反向映射 operation_lookup(u,v)=全局操作编号 =====
    % 当已知任务编号 u 和任务内操作编号 v 时，可以快速找到全局操作编号。
    operation_lookup = zeros(task_count, max(operation_map(3, :))); % 从 (任务号, 工序号) 反查全局编号
    for operation_index = 1:size(operation_map, 2)
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        operation_lookup(task_id, operation_id) = operation_map(1, operation_index);
    end

    % ===== 7. 建立容器映射 index_map =====
    % key 形式为 'u_v'，value 为全局操作索引。
    % 这个结构用于优先级解码和依赖关系处理。
    index_map = containers.Map;        % 字符串键 'u_v' 到全局工序编号的映射
    for operation_index = 1:size(operation_map, 2)
        key = sprintf('%d_%d', operation_map(2, operation_index), operation_map(3, operation_index));
        index_map(key) = operation_index;
    end

    % ===== 8. 初始化每个操作的入度 =====
    % 入度表示当前操作有多少直接前驱。
    % decode_priority 会根据入度进行类似拓扑排序的优先级解码。
    indegree = zeros(size(operation_map, 2), 1); % 每个全局工序当前未满足的前驱数量
    for operation_index = 1:size(operation_map, 2)
        task_id = operation_map(2, operation_index);
        operation_id = operation_map(3, operation_index);
        indegree(operation_index) = numel(T(task_id).O(operation_id).SIN);
    end

    % ===== 9. 构建连续编码维度和上下界 =====
    % 项目统一采用三段编码：
    %   一段表示操作优先级；
    %   一段表示候选设备选择；
    %   一段表示资源/模式选择。
    operation_count = size(operation_map, 2);     % 全部任务的工序总数
    max_candidate_device_count = 0;               % 任一工序的最大候选设备数量
    max_resource_choice_count = 0;                % 任一候选设备下的最大资源模式数量

    for task_id = 1:task_count
        for operation_id = 1:numel(T(task_id).O)
            operation = T(task_id).O(operation_id); % 当前工序，用于扫描候选设备和资源模式规模
            max_candidate_device_count = max(max_candidate_device_count, numel(operation.SDEV));
            for device_option_index = 1:numel(operation.SDEV)
                max_resource_choice_count = max( ...
                    max_resource_choice_count, ...
                    numel(operation.mode(device_option_index).mu));
            end
        end
    end

    % 连续编码总维度为 3 * 操作数。
    dim = 3 * operation_count;
    problem_info.dim = dim;
    problem_info.operation_num = operation_count;
    problem_info.max_candidate_device_num = max_candidate_device_count;
    problem_info.max_resource_choice_num = max_resource_choice_count;

    % 三段分别按工序数、候选设备数和资源模式数确定连续编码范围。
    lb = [ ...
        -2 * operation_count * ones(1, dim/3), ...
        -2 * max_candidate_device_count * ones(1, dim/3), ...
        -2 * max_resource_choice_count * ones(1, dim/3)];
    ub = -lb;

    % ===== 10. 打包问题数据，供统一目标函数使用 =====
    % 注意：算法文件不直接访问这些结构，只调用 fobj(x)。
    problem.T = T;
    problem.D = D;
    problem.B = B;
    problem.b = b;
    problem.operation_map = operation_map;
    problem.operation_lookup = operation_lookup;
    problem.indegree = indegree;
    problem.index_map = index_map;
    problem.lb = lb;
    problem.ub = ub;
    problem.dim = dim;
    problem.data_file = data_file;

    % ===== 11. 构造统一目标函数句柄 =====
    % 所有算法都通过同一个 fobj 评价个体，保证问题定义与目标函数完全一致。
    fobj = @(x) evaluate_solution(x, problem);
end
