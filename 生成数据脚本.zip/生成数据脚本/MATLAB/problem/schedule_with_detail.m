%% =================== 完整调度  ===================
function result = schedule_with_detail(schedule_vector, task_set, devices, connectivity_matrix, bandwidth_matrix, operation_lookup)
% SCHEDULE_WITH_DETAIL 对任务向量进行调度
% -------------------------------------------------------------------------
% 本函数是适应度评价的核心：给定已经解码好的工序顺序、设备选择和资源
% 模式，按照列表调度策略计算每个工序的开始/结束时间。除 makespan 外，
% 本函数还提取每个任务末工序的完成时间，用于计算优化目标 C_sum。
%
% 调度约束：
%   1. DAG 前驱约束：工序必须等待所有前驱完成；
%   2. 通信约束：前驱和当前工序不在同一设备或链路速率有限时，需要加入传输时间；
%   3. 资源约束：设备资源块同一时间只能服务有限数量的工序；
%   4. 设备类型约束：type=1/2 的设备采用整机占用，type=3 可按选中资源块释放。
% -------------------------------------------------------------------------
% 输入：
%   schedule_vector      - [4 x N] 矩阵，每列为 [任务号u; 操作号v; 设备号i; 占用资源块数mu]
%   task_set             - 任务结构体数组，包含 DAG 信息
%   devices              - 设备结构体数组，包含资源块数量和计算能力
%   connectivity_matrix  - 联通性矩阵 (0/1)
%   bandwidth_matrix     - 传输速率矩阵
%   operation_lookup     - operation_lookup(u,v)=全局操作编号
%
% 输出：
%   result - 结构体，包含：
%       makespan, task_completion_times, total_task_completion_time,
%       start_time, finish_time, trans_time, device_of, resource_schedule

operation_count = size(schedule_vector, 2);       % 调度方案中的总工序数
device_count = numel(devices);                    % 可用设备总数

% ===== 初始化结果矩阵 =====
start_time  = ones(1, operation_count) * -1;       % 操作开始时间
finish_time = ones(1, operation_count) * -1;       % 操作结束时间
trans_time  = sparse(operation_count, operation_count);          % 前驱到当前操作的通信耗时
device_of   = ones(1, operation_count) * -1;       % 操作所在设备
block_of    = cell(1, operation_count);            % 操作实际占用的资源块编号

% ===== 初始化资源块状态 =====
resource_ready_time = cell(device_count, 1);       % 每个设备各资源块的下一次可用时间
resource_schedule = cell(device_count, 1);         % 每个设备各资源块上的甘特图记录

for device_id = 1:device_count
    resource_ready_time{device_id} = zeros(1, devices(device_id).mi);
    resource_schedule{device_id} = cell(1, devices(device_id).mi);
end

%% ================== 调度核心 ==================
for sequence_index = 1:operation_count
    task_id = schedule_vector(1, sequence_index);          % 调度顺序中的任务编号
    operation_id = schedule_vector(2, sequence_index);     % 调度顺序中的任务内工序编号
    operation_index = operation_lookup(task_id, operation_id); % 当前工序的全局编号
    device_id = schedule_vector(3, operation_index);       % 当前工序被分配到的设备编号
    resource_count = schedule_vector(4, operation_index);  % 当前工序占用的资源块数量
    
    operation = task_set(task_id).O(operation_id);         % 当前待调度工序的原始属性
    
    % ----- DAG依赖 + 通信约束 -----
    % 当前工序的最早可开始时间由所有前驱的“完成时间 + 通信时间”共同决定。
    dependency_ready_time = 0;
    for predecessor_id = operation.SIN
        predecessor_index = operation_lookup(task_id, predecessor_id); % 前驱工序全局编号

        predecessor_finish_time = finish_time(predecessor_index);      % 前驱完成时间
        predecessor_device_id = device_of(predecessor_index);          % 前驱所在设备
      
        communication_time = calc_trans( ...
            task_set(task_id).O(predecessor_id).data, ...
            predecessor_device_id, ...
            device_id, ...
            connectivity_matrix, ...
            bandwidth_matrix);
        dependency_ready_time = max(dependency_ready_time, ...
            predecessor_finish_time + communication_time);

        trans_time(operation_index, predecessor_index) = communication_time;
    end
    
    % ----- 贪婪选择资源块 -----
    % 在所选设备上挑选最早空闲的 mu 个资源块；多资源模式下取这些资源块
    % 的最晚空闲时间作为资源就绪时间。
    resource_times = resource_ready_time{device_id};       % 当前设备每个资源块的空闲时间
    
    [~, selected_blocks] = mink(resource_times, resource_count); % 最早可用的资源块集合
    
    resource_ready = max(resource_times(selected_blocks));  % 所选资源块全部就绪的时间点
    
    start_time_value = max(dependency_ready_time, resource_ready); % 同时满足依赖和资源后的开工时间
    
    start_time(operation_index) = start_time_value;
       
    block_of{operation_index} = selected_blocks;

    % ----- 执行操作 -----
    execution_time = operation.cal / (devices(device_id).c * resource_count); % 当前工序执行耗时
    finish_time_value =  start_time_value + execution_time;                   % 当前工序完成时间
    finish_time(operation_index) = finish_time_value;
    device_of(operation_index) = device_id;
    
    % ----- 更新资源块状态 -----
    % type=1/2 按整机占用处理；type=3 只更新本次实际使用的资源块。
    if devices(device_id).type == 1 || devices(device_id).type == 2
        resource_ready_time{device_id}(:) = finish_time_value;
    else
        resource_ready_time{device_id}(selected_blocks) = finish_time_value;
    end
    for block_id = selected_blocks
        resource_schedule{device_id}{block_id} = [resource_schedule{device_id}{block_id};
            task_id, operation_id, start_time_value, finish_time_value];
    end
end

%% ===== 输出结构 =====
% 一个任务只有在其 DAG 末工序完成后才算完成。operation_lookup 将
% “任务编号 + 任务内工序编号”转换为 finish_time 使用的全局工序编号。
task_count = numel(task_set);
task_completion_times = zeros(1, task_count);
for task_id = 1:task_count
    sink_operation_id = numel(task_set(task_id).O);
    sink_operation_index = operation_lookup(task_id, sink_operation_id);
    task_completion_times(task_id) = finish_time(sink_operation_index);
end

result.makespan    = max(finish_time);
result.task_completion_times = task_completion_times;
result.total_task_completion_time = sum(task_completion_times);
result.start_time  = start_time;
result.finish_time = finish_time;
result.trans_time  = trans_time;
result.device_of   = device_of;
result.block_of    = block_of;
result.resource_schedule = resource_schedule;

end
