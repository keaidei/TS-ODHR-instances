function report=x3_tests()
root=x3_setup(); manifest=x3_generate_data();
x3_model_bridge();
assert(numel(manifest)==33);
% Check every pair of columns has equally frequent ordered level pairs.
design=jsondecode(fileread(fullfile(root,'experiments','doe_design.json')));
for name=fieldnames(design)'
    rows=design.(name{1}).rows;
    for a=1:size(rows,2)
        for b=a+1:size(rows,2)
            [~,~,ids]=unique(rows(:,[a b]),'rows'); counts=accumarray(ids,1);
            assert(numel(counts)==9 && numel(unique(counts))==1,'Non-orthogonal DOE');
        end
    end
end
[lb,ub,dim,fobj,~,p]=get_problem('4_5.mat'); p.strict=true;
rng(7); X=initialize_population(3,dim,lb,ub,fobj,'heuristic');
[score,detail]=evaluate_solution(X(1,:),p); x3_validate_schedule(p,detail);
assert(isfinite(score));
% Identical seed must reproduce the initial population exactly.
rng(7); Y=initialize_population(3,dim,lb,ub,fobj,'heuristic'); assert(isequal(X,Y));
% A deliberately corrupted duration must be rejected by the validator.
bad=detail; bad.schedule_result.finish_time(1)=bad.schedule_result.finish_time(1)+1;
caught=false; try, x3_validate_schedule(p,bad); catch, caught=true; end
assert(caught);
% All ten maps are finite and masked mutation modifies <=5 genes.
for k=1:10
    y=HCHAO_generate_child(X(1,:),lb,ub,dim,k);
    assert(all(isfinite(y)) && nnz(y~=X(1,:))<=5);
    [~,d]=evaluate_solution(y,p); x3_validate_schedule(p,d);
end
% Run all algorithm entry points and both ablations through the real budget.
algs={'GA','WOA','GLO','ESTA','HCHAO','HCHAO0','HCHAO1'};
rows=struct('algorithm',{},'score',{},'runtime',{},'evaluations',{});
for a=1:numel(algs)
    o=x3_run_one(algs{a},'4_5',struct('Pop',20,'Gen',1),100+a,0.5);
    assert(all(diff(o.convergence_curve)<=0));
    rows(a)=struct('algorithm',algs{a},'score',o.best_c_sum,'runtime',o.cpu_time,'evaluations',o.evaluation_count);
end
report=struct('passed',true,'datasets',33,'checks', ...
    {{'dataset semantics','DOE orthogonality','seed reproducibility','independent schedule feasibility', ...
    'corrupt schedule rejection','ten maps','seven algorithms','monotonic incumbent'}},'runs',rows);
x3_write_json(fullfile(root,'results','validation.json'),report);
disp(struct2table(rows));
end
