function x3_model_bridge()
% Two tasks, shared edge with two blocks; analytical optimum C_sum = 16.
root=fileparts(fileparts(mfilename('fullpath')));
m=1; M=2; n=2; D_num=3;
D=struct('id',{1,2,3},'type',{3,1,1},'mi',{2,1,1},'c',{1,1,1});
B=[1 1 1;1 1 0;1 0 1]; b=[1000 2 2;2 1000 0;2 0 1000];
for u=1:2
    for v=1:3
        o=struct('id',v,'cal',1,'data',2,'SIN',[],'SOUT',[],'SDEV',u+1,'mode',struct('mu',1));
        if v>1, o.SIN=v-1; end
        if v<3, o.SOUT=v+1; else, o.data=0; end
        if v==2, o.cal=4; o.SDEV=1; end
        T(u).O(v)=o;
    end
end
save(fullfile(root,'data','test_fixture.mat'),'m','M','n','D_num','D','B','b','T');
[~,~,dim,fobj,~,problem]=get_problem('test_fixture.mat');
[score,detail]=fobj(zeros(1,dim)); x3_validate_schedule(problem,detail);
assert(abs(score-16)<1e-8);
s=detail.schedule_result;
solution=struct('task',{},'operation',{},'device',{},'mu',{},'blocks',{},'start',{},'finish',{});
for q=1:dim/3
    solution(q)=struct('task',problem.operation_map(2,q),'operation',problem.operation_map(3,q), ...
        'device',s.device_of(q),'mu',numel(s.block_of{q}),'blocks',s.block_of{q},'start',s.start_time(q),'finish',s.finish_time(q));
end
dataset=struct('D',D,'T',T,'B',B,'b',b,'m',m,'M',M,'n',n,'D_num',D_num);
x3_write_json(fullfile(root,'results','matlab_fixture.json'),struct('dataset',dataset,'solution',solution,'objective',score));
end
