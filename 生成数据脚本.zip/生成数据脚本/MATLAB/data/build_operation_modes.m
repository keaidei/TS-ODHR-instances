function modes = build_operation_modes(split_options, candidate_devices, D)
% BUILD_OPERATION_MODES 为一个工序的每台候选设备生成合法资源模式。
% -------------------------------------------------------------------------
% 输入变量说明：
%   split_options    : 工序自身允许的拆分/资源块数量集合。
%   candidate_devices: 当前工序可执行的设备编号列表，即 operation.SDEV。
%   D                : 设备结构体数组，D(device).mi 是设备资源块上限。
%
% 输出变量说明：
%   modes : 结构体数组，modes(k).mu 与 candidate_devices(k) 一一对应。
%
% 生成逻辑：
%   对每台候选设备，调用 build_device_mode_mu 将 split_options 与该设备资源上限
%   取交集，得到该设备下真正可用的资源模式。这样同一工序在不同设备上的
%   mode.mu 可以不同。
% -------------------------------------------------------------------------

    candidate_devices = candidate_devices(:)';
    modes = repmat(struct('mu', []), 1, numel(candidate_devices));

    for device_index = 1:numel(candidate_devices)
        device_id = candidate_devices(device_index);
        modes(device_index).mu = build_device_mode_mu(split_options, D(device_id).mi);
    end
end
