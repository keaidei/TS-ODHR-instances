function split_options = generate_task_split_options(max_split)
% GENERATE_TASK_SPLIT_OPTIONS 生成工序自身允许的资源拆分数量集合。
% -------------------------------------------------------------------------
% 输入变量说明：
%   max_split : 该工序理论上最多允许的拆分数量/资源块数量上界。
%
% 输出变量说明：
%   split_options : 工序层面的可拆选项，例如 [1 2 4]。
%
% 生成逻辑：
%   1 始终保留，保证每道工序至少存在一种可执行模式；
%   2:max_split 中的每个拆分数以 0.5 概率加入，模拟不同工序可并行化程度不同；
%   本函数生成时已经保证 split_options 为不超过 max_split 的正整数集合。
%
% 注意：
%   split_options 只表示工序自身允许的拆分方式。实际落到某台设备时，
%   还要经过 build_operation_modes，根据 D(device).mi 过滤出该设备可用的 mode.mu。
% -------------------------------------------------------------------------

    max_split = max(1, floor(max_split));
    split_options = 1;

    for split_num = 2:max_split
        % 随机保留部分拆分方式，生成不同复杂度的工序资源模式。
        if rand < 0.5
            split_options(end+1) = split_num; %#ok<AGROW>
        end
    end

end
