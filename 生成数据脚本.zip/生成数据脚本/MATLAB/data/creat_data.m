function [m, M, D_num, D, b, B, n, T] = creat_data(edge_device_count, local_device_count, task_count)
% CREAT_DATA 随机生成边缘计算调度算例。
% -------------------------------------------------------------------------
% 输入使用规范化命名：
%   edge_device_count : 边缘设备数量；
%   local_device_count: 本地设备数量；
%   task_count        : 任务数量。
%
% 输出字段沿用历史 MAT 数据格式：
%   m, M, D_num, D, b, B, n, T
% 其中 D 为设备结构体数组，T 为任务结构体数组。保留这些字段名是为了让
% get_problem 和已有数据文件保持兼容。
% -------------------------------------------------------------------------

%% ================== 1. 兼容历史数据字段 ==================
m = edge_device_count;
M = local_device_count;
n = task_count;
device_count = edge_device_count + local_device_count;
D_num = device_count;

%% ================== 2. 设备初始化 ==================
D = struct();

for device_id = 1:device_count
    D(device_id).id = device_id;

    % belong=1 表示边缘设备，belong=2 表示本地设备。
    if device_id <= edge_device_count
        D(device_id).belong = 1;
    else
        D(device_id).belong = 2;
    end

    % type=1 为单资源块设备；type=2/3 为多资源块设备。
    % 本地设备固定为 type=1，边缘设备随机生成资源类型。
    if device_id <= edge_device_count
        D(device_id).type = randi([1, 3]);
        D(device_id).c = round((rand() * 9 + 1) * 100) / 100; % 单个资源块计算能力，保留 2 位小数

    else
        D(device_id).type = 1;
        D(device_id).c = round((rand() * 9 + 1) * 100) / 100; % 单个资源块计算能力，保留 2 位小数
    end

    if D(device_id).type == 1
        D(device_id).mi = 1;
    else
        D(device_id).mi = randi([2, 4]);
    end

    D(device_id).Rid = 1:D(device_id).mi; % 资源块编号
end

%% ================== 3. 网络连接 ==================
B = zeros(device_count);                              % 联通性矩阵，1 表示可直接通信
b = round((rand(device_count) * 9 + 1) * 100) / 100;  % 传输速率矩阵，保留 2 位小数
b = triu(b, 1);
b = b + b.';

B(1:edge_device_count, 1:edge_device_count) = 1; % 边缘设备之间全连通
B(edge_device_count+1:device_count, 1:edge_device_count) = 1;
B(1:edge_device_count, edge_device_count+1:device_count) = 1;

for device_id = 1:device_count
    B(device_id, device_id) = 1;
    b(device_id, device_id) = 1000;
end
b(B == 0) = 0;

%% ================== 4. DAG 任务生成 ==================
T = struct();

for task_id = 1:task_count
    % 每个任务独立生成 5~10 个工序；task_count 本身由调用方固定配置。
    operation_count = randi([5, 10]);
    is_connected = false;
    local_device_id = edge_device_count + task_id;
    while ~is_connected
        operations = struct();

        for operation_id = 1:operation_count
            operations(operation_id).id = operation_id;
            operations(operation_id).data = round((rand() * 80 + 20) * 100) / 100; % 输出数据量，保留 2 位小数
            operations(operation_id).cal = round((rand() * 80 + 20) * 100) / 100;  % 计算量，保留 2 位小数
            operations(operation_id).SIN = [];                % 前驱工序集合
            operations(operation_id).SOUT = [];               % 后继工序集合

            edge_device_subset = randperm(edge_device_count, edge_device_count);
            operations(operation_id).SDEV = unique([edge_device_subset, local_device_id]);%

            % 源工序固定在该任务所属本地设备上，保证任务入口位置清晰。
            if operation_id == 1
                operations(operation_id).SDEV = local_device_id;
            elseif operation_id == operation_count
                % 汇工序不再向外输出数据，并固定到某个本地设备上完成。
                operations(operation_id).data = 0;
                if rand() < 0.5
                    operations(operation_id).SDEV = local_device_id;
                else
                    operations(operation_id).SDEV = edge_device_count + other_terminal(local_device_count, task_id);
                end
            end

            % split_options 表示工序允许的资源拆分粒度；
            % mode 则进一步约束“候选设备 + 资源块数量”的合法组合。
            operations(operation_id).split_options = generate_task_split_options(max([D.mi]));
            operations(operation_id).mode = build_operation_modes( ...
                operations(operation_id).split_options, ...
                operations(operation_id).SDEV, ...
                D);
        end

        % 随机生成中间工序之间的 DAG 边；源/汇关系随后统一补齐。
        edge_probability = 0.2;
        for source_operation = 2:operation_count-2
            for target_operation = source_operation+1:operation_count-1
                if rand() < edge_probability
                    operations(target_operation).SIN = unique([operations(target_operation).SIN, source_operation]);
                    operations(source_operation).SOUT = unique([operations(source_operation).SOUT, target_operation]);
                end
            end
        end

        % 固定源汇：无前驱的中间工序连接源节点，无后继的中间工序连接汇节点。
        source_node = 1;
        sink_node = operation_count;
        operations(source_node).SIN = [];
        operations(sink_node).SOUT = [];

        for operation_id = 2:operation_count-1
            if isempty(operations(operation_id).SIN)
                operations(operation_id).SIN = source_node;
                operations(source_node).SOUT = unique([operations(source_node).SOUT, operation_id]);
            end
            if isempty(operations(operation_id).SOUT)
                operations(operation_id).SOUT = sink_node;
                operations(sink_node).SIN = unique([operations(sink_node).SIN, operation_id]);
            end
        end

        % ===== 首尾工序与末端传输数据约束 =====
        % 首工序和末工序仅承担任务入口/出口语义，计算量固定为 1。
        operations(source_node).cal = 1;
        operations(sink_node).cal = 1;
        % 末工序不再向外传输数据；前驱输出量保留 [20,100] 随机值。
        operations(sink_node).data = 0;
        % X3 protocol: keep predecessor output data in [20,100].

        % DFS 检查从源节点能否到达全部工序，避免生成不连通任务图。
        visited = false(1, operation_count);
        visited = dfs_visit(operations, source_node, visited);
        is_connected = all(visited);
    end

    T(task_id).O = operations;
    T(task_id).belong = local_device_id;

    %% ================== 4.1 DAG 可视化（调试时手动打开） ==================
    % edges = [];
    % for operation_id = 1:numel(operations)
    %     for successor_id = operations(operation_id).SOUT
    %         edges = [edges; operation_id, successor_id]; %#ok<AGROW>
    %     end
    % end
    % graph_obj = digraph(edges(:,1), edges(:,2));
    % figure('Name', sprintf('DAG Task %d', task_id));
    % plot(graph_obj, 'Layout', 'layered', 'NodeLabel', 1:numel(operations));
    % title(sprintf('Connected DAG of Task %d Operations', task_id));
end
end

function id=other_terminal(count,source)
others=setdiff(1:count,source);
if isempty(others), id=source; else, id=others(randi(numel(others))); end
end
