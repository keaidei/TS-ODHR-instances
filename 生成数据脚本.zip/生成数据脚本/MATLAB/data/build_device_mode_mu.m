function mu_list = build_device_mode_mu(split_options, device_block_num)
% BUILD_DEVICE_MODE_MU 根据工序可拆选项和设备资源上限生成合法模式。
% -------------------------------------------------------------------------
% 输入变量说明：
%   split_options    : 工序自身允许的拆分/资源块数量集合。
%   device_block_num : 当前设备可提供的最大资源块数量，即 D(device).mi。
%
% 输出变量说明：
%   mu_list : 当前工序在当前设备上可使用的资源块数量集合。
%
% 示例：
%   split_options = [1, 3]，device_block_num = 2，则 mu_list = [1]。
%   因为该设备最多只有 2 个资源块，无法支持 3 资源块模式。
%
% 若交集为空，说明该设备不应作为该工序候选设备，直接报错以暴露数据问题。
% -------------------------------------------------------------------------

    device_block_num = max(1, floor(device_block_num));
    mu_list = split_options(split_options <= device_block_num);

    if isempty(mu_list)
        error('候选设备资源块上限不足，无法支持该工序的任一可拆模式。');
    end
end
