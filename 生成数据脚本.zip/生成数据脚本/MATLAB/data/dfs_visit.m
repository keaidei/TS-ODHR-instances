function visited = dfs_visit(operations, operation_id, visited)
% DFS_VISIT 从指定工序出发递归访问 DAG 后继节点。
% -------------------------------------------------------------------------
% 数据生成阶段会随机添加工序依赖边。为了避免生成“源节点无法到达某些
% 工序”的不连通任务图，creat_data 会从源工序调用本函数做一次 DFS。
%
% 输入：
%   operations   : 当前任务的工序结构体数组；
%   operation_id : 当前访问的工序编号；
%   visited      : 布尔数组，visited(i)=true 表示工序 i 已可达。
% -------------------------------------------------------------------------

    visited(operation_id) = true;

    for successor_id = operations(operation_id).SOUT
        if ~visited(successor_id)
            visited = dfs_visit(operations, successor_id, visited);
        end
    end
end
