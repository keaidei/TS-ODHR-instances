% 数据集生成脚本。#ok
% 运行本文件会调用 creat_data 生成一份随机调度算例，并将 MAT 文件
% 固定保存到当前脚本所在的 data/ 目录下，避免数据集被写到项目根目录
% 或 MATLAB 当前工作目录中的其他位置。
clc; clear;

edge_device_count = 5;       % 边缘设备数量，对应 MAT 文件中的变量 m
local_device_count = 10;     % 本地设备数量，对应 MAT 文件中的变量 M
task_count = local_device_count;             % 任务总数，对应 MAT 文件中的变量 n

% 生成设备、网络和任务 DAG 等完整算例数据。
[m, M, D_num, D, b, B, n, T] = creat_data( ...
    edge_device_count, local_device_count, task_count);

% 数据集命名沿用“边缘设备数_任务数_总工序数.mat”，例如 3_10_76.mat。
operation_count = sum(arrayfun(@(task) numel(task.O), T));
data_dir = fileparts(mfilename('fullpath'));
data_file = sprintf('%d_%d_%d.mat', edge_device_count, task_count, operation_count);
data_path = fullfile(data_dir, data_file);

% 只保存求解问题所需变量，避免把脚本中的临时路径变量也写入数据集。
% 注意：m、M、D_num、D、b、B、n、T 是历史数据格式字段名，保持不变。
save(data_path, 'm', 'M', 'D_num', 'D', 'b', 'B', 'n', 'T');

fprintf('数据集已保存到：%s\n', data_path);
fprintf('任务数: %d | 总工序数: %d\n', task_count, operation_count);
