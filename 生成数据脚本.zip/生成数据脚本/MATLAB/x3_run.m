function x3_run(stage)
% x3_run('data'|'doe'|'chaos'|'compare'|'all'|'smoke')
if nargin<1, stage='smoke'; end
root=x3_setup();
assert(ismember(stage,{'data','doe','chaos','compare','all','smoke'}),'Unknown stage');
manifest=x3_generate_data();
if strcmp(stage,'data'), return; end
smoke=strcmp(stage,'smoke');
profile='formal'; repeats=10; tune_dataset='5_50';
if smoke, profile='smoke'; repeats=2; tune_dataset='4_5'; end
outdir=fullfile(root,'results',profile); if ~isfolder(outdir), mkdir(outdir); end
source_hash=x3_source_hash(root);
design=jsondecode(fileread(fullfile(root,'experiments','doe_design.json')));
algorithms={'GA','WOA','GLO','ESTA','HCHAO0','HCHAO1','HCHAO'};
tuning={'HCHAO','GA','WOA','GLO','ESTA'};
selected_path=fullfile(outdir,'selected_parameters.json');
if ismember(stage,{'doe','all','smoke'})
    selected=struct();
    selected.source_hash=source_hash; selected.profile=profile;
    for a=1:numel(tuning)
        alg=tuning{a}; d=design.(alg); means=zeros(size(d.rows,1),1); options=cell(size(means));
        for row=1:size(d.rows,1)
            opt=struct();
            for j=1:numel(d.fields), opt.(d.fields{j})=d.rows(row,j); end
            options{row}=opt;
            scores=zeros(repeats,1);
            for r=1:repeats
                job=make_job('doe',alg,tune_dataset,row,r,opt);
                result=run_job(job); scores(r)=result.best_c_sum;
            end
            means(row)=mean(scores);
        end
        [~,bestrow]=min(means);
        selected.(alg)=options{bestrow};
        selected.([alg '_row'])=bestrow;
        fprintf('Selected %s DOE row %d, AVG %.8g\n',alg,bestrow,means(bestrow));
    end
    x3_write_json(selected_path,selected);
else
    assert(isfile(selected_path),'Run x3_run(''doe'') before chaos/compare');
    selected=jsondecode(fileread(selected_path));
    assert(strcmp(selected.source_hash,source_hash),'Code changed after tuning. Use a new results directory or rerun DOE.');
end
if ismember(stage,{'chaos','all','smoke'})
    for removed=0:10
        opt=selected.HCHAO; opt.maps=setdiff(1:10,removed);
        for r=1:repeats
            run_job(make_job('chaos','HCHAO',tune_dataset,removed,r,opt));
        end
    end
end
if ismember(stage,{'compare','all','smoke'})
    instances=manifest;
    if smoke, instances=manifest(1); end
    for k=1:numel(instances)
        for a=1:numel(algorithms)
            alg=algorithms{a}; key=alg;
            if ismember(alg,{'HCHAO0','HCHAO1'}), key='HCHAO'; end
            opt=selected.(key);
            for r=1:repeats
                run_job(make_job('compare',alg,instances(k).id,0,r,opt));
            end
        end
    end
end
fprintf('Completed %s (%s). Python report command is in README.\n',stage,profile);

    function job=make_job(group,alg,id,variant,repeat,opt)
        % Repeated seeds are deliberately paired across treatments, not proof
        % of identical random draws (algorithms consume RNG differently).
        mn=sscanf(id,'%d_%d'); limit=mn(2);
        if smoke, limit=0.15; end
        offset=0; if strcmp(group,'chaos'), offset=100000; elseif strcmp(group,'compare'), offset=200000; end
        seed=20260928+offset+mn(1)*10000+mn(2)*100+repeat;
        job=struct('group',group,'algorithm',alg,'dataset',id,'variant',variant, ...
            'repeat',repeat,'seed',seed,'max_time',limit,'parameters',opt, ...
            'profile',profile,'source_hash',source_hash, ...
            'data_hash',x3_file_hash(fullfile(root,'data',[id '.mat'])));
    end
    function result=run_job(job)
        dirpath=fullfile(outdir,job.group); if ~isfolder(dirpath), mkdir(dirpath); end
        name=sprintf('%s_%s_v%02d_r%02d',job.algorithm,job.dataset,job.variant,job.repeat);
        matpath=fullfile(dirpath,[name '.mat']); jsonpath=fullfile(dirpath,[name '.json']);
        if isfile(matpath)
            stored=load(matpath,'job','output');
            assert(isequaln(stored.job,job),'Checkpoint metadata changed: %s',matpath);
            result=stored.output;
        else
            fprintf('%s %s %s variant=%d repeat=%d budget=%.2fs\n',profile,job.group,job.algorithm,job.variant,job.repeat,job.max_time);
            result=x3_run_one(job.algorithm,job.dataset,job.parameters,job.seed,job.max_time);
            output=result; temporary=[matpath '.tmp.mat'];
            save(temporary,'job','output','-v7'); movefile(temporary,matpath);
        end
        small=rmfield(result,{'best_position','best_detail'}); small.job=job;
        if strcmp(job.group,'compare')
            small.best_schedule=rmfield(result.best_detail.schedule_result,{'trans_time','resource_schedule'});
        end
        x3_write_json(jsonpath,small);
    end
end
