﻿function plot_gantt(result, D)
% PLOT_GANTT 绘制单次运行最优调度方案的资源块甘特图。
% -------------------------------------------------------------------------
% 输入：
%   result : schedule_with_detail 输出的调度结果结构体；
%   D      : 设备结构体数组，用于读取每台设备的资源块数量 mi。
%
% result.resource_schedule{device_id}{block_id} 的每一行是
%   [task_id, operation_id, start_time, finish_time]。
% -------------------------------------------------------------------------

figure('Name', 'Gantt Chart', 'Color','w'); hold on;
axis_handle = gca;
axis_handle.FontName = 'Arial';
axis_handle.FontSize = 10;
axis_handle.TickLabelInterpreter = 'tex';
colors = lines(20);

y_position = 0;
y_tick_labels = {};

for device_id = 1:numel(D)
    for block_id = 1:D(device_id).mi
        block_sequence = result.resource_schedule{device_id}{block_id};

        % 即使某个资源块没有分配操作，也保留对应行，保证纵轴完整显示全部 r_{i,j}。
        if ~isempty(block_sequence)
            for record_index = 1:size(block_sequence, 1)
                task_id = block_sequence(record_index, 1);
                operation_id = block_sequence(record_index, 2);
                start_time = block_sequence(record_index, 3);
                finish_time = block_sequence(record_index, 4);
                
                if finish_time <= start_time
                    continue;
                end
                
                rectangle('Position',[start_time, y_position, finish_time-start_time, 0.8], ...
                    'FaceColor', colors(mod(task_id-1,20)+1,:), ...
                    'EdgeColor','k');
                
                % 图中用斜体 o_{u,v} 表示任务 t_u 的第 v 个操作，保持和论文符号一致。
                text(start_time + (finish_time-start_time)/2, y_position + 0.4, ...
                    sprintf('{\\it o}_{%d,%d}', task_id, operation_id), ...
                    'HorizontalAlignment','center', ...
                    'Interpreter', 'tex', ...
                    'FontName', 'Arial', ...
                    'FontSize',8);
            end
        end
        
        % 纵轴刻度用斜体 r_{i,j} 表示设备 d_i 的第 j 个资源块。
        y_tick_labels{end+1} = sprintf('{\\it r}_{%d,%d}', device_id, block_id); %#ok<AGROW>
        y_position = y_position + 1;
    end
end

xlabel('{\it C}_{\it max}', 'Interpreter', 'tex', 'FontName', 'Arial', 'FontSize', 11);
ylabel('Resource', 'Interpreter', 'none', 'FontName', 'Arial', 'FontSize', 11);
operation_count = numel(result.finish_time);
title({'Gantt Chart'; ...
    sprintf('Operations = %d | {\\it C}_{\\it sum} = %.2f |', ...
        operation_count, result.total_task_completion_time)}, ...
    'Interpreter', 'tex', ...
    'FontName', 'Arial', ...
    'FontSize', 12, ...
    'HorizontalAlignment', 'center');

yticks((0:y_position-1) + 0.4);
yticklabels(y_tick_labels);

ylim([0 y_position]);   % 保证最后一个资源块行完整显示。

xline(result.makespan, '--k', ...
    sprintf('{\\it C}_{\\it max} = %.2f', result.makespan), ...
    'Interpreter', 'tex', ...
    'LineWidth', 1.2, ...
    'LabelOrientation', 'horizontal', ...
    'LabelHorizontalAlignment', 'left', ...
    'LabelVerticalAlignment', 'top');

grid on; hold off;

end
