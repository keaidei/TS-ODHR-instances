﻿function result_filename = make_result_filename(algorithm_name, data_file)
% make_result_filename 生成单个“算法-数据集”结果文件名。
% -------------------------------------------------------------------------
% 输入变量说明：
%   algorithm_name : 算法入口函数名称，例如 'CSO' 或 'WOA_CMS'。
%   data_file      : 数据集文件名，例如 '3_10_76.mat'。
%
% 输出变量说明：
%   result_filename : 保存到 results/ 下的 MAT 文件名。
%
% 命名规则：
%   result_filename = algorithm_name + '_' + make_file_label(data_file) + '.mat'
%   例如：CSO + 3_10_76.mat -> CSO_3_10_76.mat。
%   数据集标签先经过 make_file_label 清洗，避免特殊字符影响保存和后续读取。
% -------------------------------------------------------------------------

    result_filename = [algorithm_name, '_', make_file_label(data_file), '.mat'];
end
