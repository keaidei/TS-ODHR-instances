﻿function dataset_label = make_dataset_label(data_file)
% MAKE_DATASET_LABEL 生成图标题中显示的数据集名称。
% data_file 可能是文件名或完整路径，这里统一去掉目录和扩展名。

    [~, dataset_label, ~] = fileparts(char(data_file));
end
