﻿function draw_convergence_curves(data_files, algorithm_names, results_dir)
% draw_convergence_curves 绘制各算法在同一数据集上的收敛曲线对比图。
% -------------------------------------------------------------------------
% 该函数从 main.m 拆分，便于主脚本只保留实验流程。
% 每个算法可能独立运行多次，这里选取最终 best_score 最小的一次作为
% “代表运行”，再把它的 time_curve 和 convergence_curve 送入统一绘图函数。
%
% 注意：
%   用户要求暂不修改历史 result MAT 文件中的动态变量名读取逻辑，因此这里仍
%   使用 load(result_file, result_variable_name) + eval(...) 读取结果。
% -------------------------------------------------------------------------

    convergence_dir = fullfile(results_dir, 'convergence');
    if ~exist(convergence_dir, 'dir')
        mkdir(convergence_dir);
    end

    style_algorithm_names = {'WOA', 'GLO', 'ESTA', 'HCHAO', 'HCHAO0', 'HCHAO1'};

    for data_idx = 1:numel(data_files)
        data_file = data_files{data_idx};

        compare_time_curves = cell(numel(algorithm_names), 1);
        compare_convergence_curves = cell(numel(algorithm_names), 1);

        for alg_idx = 1:numel(algorithm_names)
            algorithm_name = algorithm_names{alg_idx};

            result_variable_name = matlab.lang.makeValidName([algorithm_name '_' erase(data_file, '.mat')]);
            result_file = fullfile(results_dir, make_result_filename(algorithm_name, data_file));

            load(result_file, result_variable_name);

            run_outputs = eval(result_variable_name);
            best_scores = cellfun(@(item) item.best_score, run_outputs);
            [~, best_run_index] = min(best_scores);

            compare_time_curves{alg_idx} = run_outputs{best_run_index}.time_curve;
            compare_convergence_curves{alg_idx} = run_outputs{best_run_index}.convergence_curve;
        end

        figure_path = fullfile(convergence_dir, ...
            ['convergence_compare_', make_file_label(data_file), '.emf']);

        plot_dataset_convergence_comparison( ...
            compare_time_curves, ...
            compare_convergence_curves, ...
            algorithm_names, ...
            data_file, ...
            figure_path, ...
            style_algorithm_names);

        focus_algorithm_names = {'HCHAO', 'HCHAO1'};
        [focus_time_curves, focus_convergence_curves, available_focus_algorithm_names] = ...
            load_focus_convergence_curves(data_file, focus_algorithm_names, results_dir);

        if numel(available_focus_algorithm_names) == numel(focus_algorithm_names)
            focus_figure_path = fullfile(convergence_dir, ...
                ['convergence_compare_', make_file_label(data_file), '_HCHAO_HCHAO1.emf']);

            plot_dataset_convergence_comparison( ...
                focus_time_curves, ...
                focus_convergence_curves, ...
                available_focus_algorithm_names, ...
                data_file, ...
                focus_figure_path, ...
                style_algorithm_names);
        else
            warning('HCHAO/HCHAO1 focus convergence curve was skipped on dataset %s because saved results are incomplete.', ...
                data_file);
        end

    end
end

function [time_curves, convergence_curves, available_algorithm_names] = ...
    load_focus_convergence_curves(data_file, algorithm_names, results_dir)
% load_focus_convergence_curves 读取指定算法的最好一次收敛曲线。

    time_curves = {};
    convergence_curves = {};
    available_algorithm_names = {};

    for alg_idx = 1:numel(algorithm_names)
        algorithm_name = algorithm_names{alg_idx};
        result_file = fullfile(results_dir, make_result_filename(algorithm_name, data_file));

        if ~exist(result_file, 'file')
            continue;
        end

        result_variable_name = matlab.lang.makeValidName([algorithm_name '_' make_file_label(data_file)]);
        loaded_result = load(result_file);

        if isfield(loaded_result, result_variable_name)
            run_outputs = loaded_result.(result_variable_name);
        else
            variable_names = fieldnames(loaded_result);
            if numel(variable_names) ~= 1
                continue;
            end
            run_outputs = loaded_result.(variable_names{1});
        end

        if isempty(run_outputs) || ~iscell(run_outputs)
            continue;
        end

        best_scores = cellfun(@(item) item.best_score, run_outputs);
        [~, best_run_index] = min(best_scores);

        time_curves{end+1, 1} = run_outputs{best_run_index}.time_curve; %#ok<AGROW>
        convergence_curves{end+1, 1} = run_outputs{best_run_index}.convergence_curve; %#ok<AGROW>
        available_algorithm_names{end+1, 1} = algorithm_name; %#ok<AGROW>
    end
end


