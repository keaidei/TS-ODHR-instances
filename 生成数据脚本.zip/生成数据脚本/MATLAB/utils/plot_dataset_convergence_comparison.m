function plot_dataset_convergence_comparison(Time_curves, Convergence_curves, algorithm_names, data_file, save_path, style_algorithm_names)
% PLOT_DATASET_CONVERGENCE_COMPARISON 绘制某一个数据集上的多算法收敛曲线对比图
% -------------------------------------------------------------------------
% 输入：
%   Time_curves        : cell 数组。Time_curves{i} 是第 i 个算法最好一次运行的时间横轴
%   Convergence_curves : cell 数组。Convergence_curves{i} 是第 i 个算法最好一次运行的当前最优值
%   algorithm_names    : cell 数组。algorithm_names{i} 是第 i 个算法名称
%   data_file          : 当前数据集文件名，例如 '3_20_148.mat'
%   save_path          : 可选。若非空，则将图保存为该路径
%
% 重要说明：
%   1. 本函数只画“每个算法多次运行中最好一次”的收敛曲线。
%   2. 横轴只使用运行时间，不使用迭代次数。
%   3. 本函数只是绘图工具，不参与算法搜索，不改变任何优化结果。
% -------------------------------------------------------------------------

    if nargin < 5
        save_path = '';
    end

    if nargin < 6 || isempty(style_algorithm_names)
        style_algorithm_names = algorithm_names;
    end

    % 图中显示的数据集名只保留“任务数_总工序数”，与甘特图标题保持一致。
    % 原始数据集文件名形如“边缘设备数_任务数_总工序数.mat”，标题中省略边缘设备数。
    dataset_label = make_dataset_label(data_file);
    dataset_parts = split(string(dataset_label), "_");
    if numel(dataset_parts) >= 3
        compact_dataset_label = dataset_parts(2) + "_" + dataset_parts(3);
    else
        compact_dataset_label = string(dataset_label);
    end

    dataset_label = char(compact_dataset_label);
    display_dataset_label = strrep(dataset_label, '_', '\_');

    figure_name = ['Convergence Comparison on ', dataset_label];
    figure_title = ['Convergence Comparison on ', display_dataset_label];

    figure('Name', figure_name, 'Color', 'w');
    hold on;
    axis_handle = gca;
    axis_handle.FontName = 'Arial';
    axis_handle.FontSize = 10;
    color_order = axis_handle.ColorOrder;

    valid_count = 0;
    legend_names = {};
    legend_handles = gobjects(0);
    max_time_seen = 0;
    marker_symbols = {'o','s','d','^','v','>','<','p','h'};

    for i = 1:numel(algorithm_names)
        t = Time_curves{i};
        y = Convergence_curves{i};

        % 如果某个算法没有记录曲线，则跳过，避免绘图报错。
        if isempty(t) || isempty(y)
            warning('Algorithm %s has no valid convergence curve on dataset %s and was skipped.', ...
                algorithm_names{i}, data_file);
            continue;
        end

        % 保证横轴和纵轴长度一致。
        len = min(length(t), length(y));
        t = t(1:len);
        y = y(1:len);

        style_idx = find(strcmp(style_algorithm_names, algorithm_names{i}), 1);
        if isempty(style_idx)
            style_idx = numel(style_algorithm_names) + valid_count + 1;
        end

        marker_symbol = marker_symbols{mod(style_idx - 1, numel(marker_symbols)) + 1};
        curve_color = color_order(mod(style_idx - 1, size(color_order, 1)) + 1, :);

        % 主线只负责展示收敛趋势；起点和终点的 marker 单独绘制。
        plot(t, y, ...
            'LineWidth', 1.5, ...
            'Color', curve_color);

        % 同一算法的起点和终点使用同一种实心符号，不同算法优先使用不同符号。
        % 若算法数超过内置 marker 数量，则用编号作补充标识。
        plot(t(1), y(1), marker_symbol, ...
            'MarkerSize', 7, ...
            'MarkerFaceColor', curve_color, ...
            'MarkerEdgeColor', 'k', ...
            'LineWidth', 1.2, ...
            'HandleVisibility', 'off');
        plot(t(end), y(end), marker_symbol, ...
            'MarkerSize', 7, ...
            'MarkerFaceColor', curve_color, ...
            'MarkerEdgeColor', 'k', ...
            'LineWidth', 1.2, ...
            'HandleVisibility', 'off');

        if style_idx > numel(marker_symbols)
            marker_text = num2str(style_idx);
            text(t(1), y(1), marker_text, ...
                'Color', curve_color, ...
                'FontWeight', 'bold', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'HandleVisibility', 'off');
            text(t(end), y(end), marker_text, ...
                'Color', curve_color, ...
                'FontWeight', 'bold', ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'HandleVisibility', 'off');
        end

        legend_handle = plot(nan, nan, ...
            'LineWidth', 1.5, ...
            'Color', curve_color, ...
            'Marker', marker_symbol, ...
            'MarkerSize', 7, ...
            'MarkerFaceColor', curve_color, ...
            'MarkerEdgeColor', 'k');

        max_time_seen = max(max_time_seen, max(t));
        valid_count = valid_count + 1;
        legend_handles(valid_count) = legend_handle;
        legend_names{valid_count} = make_algorithm_label(algorithm_names{i}); %#ok<AGROW>
    end

    xlabel('CPU_{time}', 'Interpreter', 'tex', 'FontName', 'Arial', 'FontSize', 11);
    ylabel('{\it C}_{\it sum}', 'Interpreter', 'tex', 'FontName', 'Arial', 'FontSize', 11);
    title(figure_title, 'Interpreter', 'tex', 'FontName', 'Arial', 'FontSize', 12);
    grid on;

    if valid_count > 0
        legend(legend_handles, legend_names, ...
            'Interpreter', 'tex', ...
            'Location', 'best', ...
            'FontName', 'Arial', ...
            'FontSize', 10);
        if max_time_seen > 0
            xlim([0, max_time_seen]);
        else
            xlim([0, 1]);
        end
    end

    hold off;

    if ~isempty(save_path)
        [save_dir, ~, ~] = fileparts(save_path);
        if ~exist(save_dir, 'dir')
            mkdir(save_dir);
        end
        saveas(gcf, save_path);

        % 如需批量运行后自动释放图窗，可启用下一行 close(gcf)。
        % close(gcf);
    end
end

