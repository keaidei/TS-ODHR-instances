function draw_gantt_figures(data_files, algorithm_names, results_dir)
% DRAW_GANTT_FIGURES 批量绘制各算法每次独立运行的甘特图。
% -------------------------------------------------------------------------
% 输入：
%   data_files      : 数据集文件名列表；
%   algorithm_names : 算法名称列表；
%   results_dir     : main.m 保存结果 MAT 文件的目录。
%
% 说明：
%   每次独立运行的最优调度细节保存在 output.best_detail.schedule_result 中。
%   用户要求暂不修改历史 result MAT 文件中的动态变量名读取逻辑，因此这里仍
%   使用 load(result_file, result_variable_name) + eval(...) 读取结果。
% -------------------------------------------------------------------------

    gantt_dir = fullfile(results_dir, 'gantt');
    if ~exist(gantt_dir, 'dir')
        mkdir(gantt_dir);
    end

    for data_idx = 1:numel(data_files)
        data_file = data_files{data_idx};

        [~, ~, ~, ~, ~, problem] = get_problem(data_file);

        for alg_idx = 1:numel(algorithm_names)
            algorithm_name = algorithm_names{alg_idx};

            result_variable_name = matlab.lang.makeValidName([algorithm_name '_' erase(data_file, '.mat')]);
            result_file = fullfile(results_dir, make_result_filename(algorithm_name, data_file));

            load(result_file, result_variable_name);

            for run_idx = 1:numel(eval(result_variable_name))
                % 每次独立运行保存一张甘特图，便于查看不同运行得到的调度方案。
                schedule_result = eval([result_variable_name '{run_idx}.best_detail.schedule_result']);

                plot_gantt(schedule_result, problem.D);

                % 标题第一行固定为 Gantt Chart，第二行显示“任务数_总工序数 | 算法名 | C_{sum}”。
                % 数据集文件名形如“边缘设备数_任务数_总工序数.mat”，标题中省略边缘设备数。
                dataset_label = make_dataset_label(data_file);
                dataset_parts = split(string(dataset_label), "_");
                if numel(dataset_parts) >= 3
                    compact_dataset_label = dataset_parts(2) + "_" + dataset_parts(3);
                else
                    compact_dataset_label = string(dataset_label);
                end

                display_data_file = strrep(char(compact_dataset_label), '_', '\_');
                display_algorithm_name = make_algorithm_label(algorithm_name);
                title({'Gantt Chart'; ...
                    sprintf('%s | %s | {\\it C}_{\\it sum} = %.2f', ...
                        display_data_file, display_algorithm_name, ...
                        schedule_result.total_task_completion_time)}, ...
                    'Interpreter', 'tex', ...
                    'HorizontalAlignment', 'center');

                saveas(gcf, fullfile(gantt_dir, sprintf( ...
                    'gantt_%s_%s_run_%02d.emf', ...
                    algorithm_name, make_file_label(data_file), run_idx)));

                % 如需批量运行后自动释放图窗，可启用下一行 close(gcf)。
                 close(gcf);
            end
        end
    end
end
