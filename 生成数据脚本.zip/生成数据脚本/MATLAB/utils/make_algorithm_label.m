function display_label = make_algorithm_label(algorithm_name)
% make_algorithm_label 将算法入口函数名转换为 TeX 图例/标题显示名。
% 例如入口 HCHAO0 显示为 HCHAO_{0}，入口 HCHAO1 显示为 HCHAO_{1}。

    algorithm_name = char(string(algorithm_name));
    trailing_digits = regexp(algorithm_name, '^(.*?)(\d+)$', 'tokens', 'once');

    if isempty(trailing_digits)
        display_label = strrep(algorithm_name, '_', '\_');
        return;
    end

    prefix = strrep(trailing_digits{1}, '_', '\_');
    display_label = [prefix, '_{', trailing_digits{2}, '}'];
end
