function summary_table = build_summary_table_from_results(data_files, algorithm_names, results_dir)
% build_summary_table_from_results 从已保存的结果文件重新生成汇总表。
% -------------------------------------------------------------------------
% 用法：
%   summary_table = build_summary_table_from_results();
%   summary_table = build_summary_table_from_results(data_files, algorithm_names, results_dir);
%
% 说明：
%   本函数只读取 results/ 下已有的“算法名_数据集名.mat”结果文件，不重新运行算法。
%   当 data_files 或 algorithm_names 为空时，会自动扫描 results/ 下已有结果。
% -------------------------------------------------------------------------

    if nargin < 3 || isempty(results_dir)
        project_root = fileparts(fileparts(mfilename('fullpath')));
        results_dir = fullfile(project_root, 'results');
    end

    if nargin < 1
        data_files = {};
    end

    if nargin < 2
        algorithm_names = {};
    end

    if ischar(data_files) || isstring(data_files)
        data_files = cellstr(data_files);
    end

    if ischar(algorithm_names) || isstring(algorithm_names)
        algorithm_names = cellstr(algorithm_names);
    end

    if isempty(data_files) || isempty(algorithm_names)
        [discovered_data_files, discovered_algorithm_names] = discover_saved_results(results_dir);

        if isempty(data_files)
            data_files = discovered_data_files;
        end

        if isempty(algorithm_names)
            algorithm_names = discovered_algorithm_names;
        end
    end

    summary_dataset = strings(0, 1);
    summary_algorithm = strings(0, 1);
    summary_mean_value = [];
    summary_std_value = [];
    summary_best_value = [];
    summary_worst_value = [];
    summary_best_run_index = [];
    summary_avg_cpu_time = [];
    summary_avg_evaluation_count = [];

    for data_idx = 1:numel(data_files)
        data_file = data_files{data_idx};

        for alg_idx = 1:numel(algorithm_names)
            algorithm_name = algorithm_names{alg_idx};
            result_file = fullfile(results_dir, make_result_filename(algorithm_name, data_file));

            if ~exist(result_file, 'file')
                warning('Result file not found and skipped: %s', result_file);
                continue;
            end

            run_outputs = load_run_outputs_from_result(result_file, algorithm_name, data_file);
            if isempty(run_outputs)
                warning('No valid run outputs found and skipped: %s', result_file);
                continue;
            end

            best_scores = cellfun(@(item) item.best_score, run_outputs);
            cpu_times = cellfun(@(item) item.cpu_time, run_outputs);
            evaluation_counts = cellfun(@(item) item.evaluation_count, run_outputs);
            [best_value, best_run_index] = min(best_scores);

            summary_dataset(end+1, 1) = string(data_file); %#ok<AGROW>
            summary_algorithm(end+1, 1) = string(algorithm_name); %#ok<AGROW>
            summary_mean_value(end+1, 1) = mean(best_scores); %#ok<AGROW>
            summary_std_value(end+1, 1) = std(best_scores); %#ok<AGROW>
            summary_best_value(end+1, 1) = best_value; %#ok<AGROW>
            summary_worst_value(end+1, 1) = max(best_scores); %#ok<AGROW>
            summary_best_run_index(end+1, 1) = best_run_index; %#ok<AGROW>
            summary_avg_cpu_time(end+1, 1) = mean(cpu_times); %#ok<AGROW>
            summary_avg_evaluation_count(end+1, 1) = mean(evaluation_counts); %#ok<AGROW>
        end
    end

    summary_table = table( ...
        summary_dataset, ...
        summary_algorithm, ...
        summary_mean_value, ...
        summary_std_value, ...
        summary_best_value, ...
        summary_worst_value, ...
        summary_best_run_index, ...
        summary_avg_cpu_time, ...
        summary_avg_evaluation_count, ...
        'VariableNames', {'dataset','algorithm','mean_value','std_value','best_value','worst_value','best_run_index','avg_cpu_time','avg_evaluation_count'});

    save(fullfile(results_dir, 'summary_table.mat'), 'summary_table');
    writetable(summary_table, fullfile(results_dir, 'summary_table.csv'));

    disp(summary_table);
end

function run_outputs = load_run_outputs_from_result(result_file, algorithm_name, data_file)
% 兼容当前结果文件中的动态变量名保存方式。

    result_variable_name = matlab.lang.makeValidName([algorithm_name '_' make_file_label(data_file)]);
    loaded_result = load(result_file);

    if isfield(loaded_result, result_variable_name)
        run_outputs = loaded_result.(result_variable_name);
    else
        variable_names = fieldnames(loaded_result);
        cell_variable_flags = false(numel(variable_names), 1);

        for i = 1:numel(variable_names)
            cell_variable_flags(i) = iscell(loaded_result.(variable_names{i}));
        end

        cell_variable_names = variable_names(cell_variable_flags);
        if numel(cell_variable_names) ~= 1
            run_outputs = {};
            return;
        end

        warning('Expected variable %s was not found in %s. Using %s instead.', ...
            result_variable_name, result_file, cell_variable_names{1});
        run_outputs = loaded_result.(cell_variable_names{1});
    end

    if isstruct(run_outputs)
        run_outputs = num2cell(run_outputs(:));
    end

    if ~iscell(run_outputs)
        run_outputs = {};
        return;
    end

    run_outputs = run_outputs(:);
end

function [data_files, algorithm_names] = discover_saved_results(results_dir)
% 自动识别 results/ 下已有的“算法名_设备数_任务数_总操作数.mat”文件。

    result_files = dir(fullfile(results_dir, '*.mat'));
    data_files = {};
    algorithm_names = {};

    for i = 1:numel(result_files)
        [~, file_label, ~] = fileparts(result_files(i).name);
        if strcmp(file_label, 'summary_table')
            continue;
        end

        token = regexp(file_label, '^(?<algorithm>.+)_(?<dataset>\d+_\d+_\d+)$', 'names', 'once');
        if isempty(token)
            continue;
        end

        algorithm_names{end+1, 1} = token.algorithm; %#ok<AGROW>
        data_files{end+1, 1} = [token.dataset, '.mat']; %#ok<AGROW>
    end

    algorithm_names = sort_algorithm_names(unique(algorithm_names, 'stable'));
    data_files = sort_data_files(unique(data_files, 'stable'));
end

function sorted_algorithm_names = sort_algorithm_names(algorithm_names)
% 常用算法按论文实验展示顺序排列，其他算法追加在末尾。

    preferred_order = {'WOA','GLO','ESTA','HCHAO','HCHAO0','HCHAO1'};
    sorted_algorithm_names = {};

    for i = 1:numel(preferred_order)
        if any(strcmp(algorithm_names, preferred_order{i}))
            sorted_algorithm_names{end+1, 1} = preferred_order{i}; %#ok<AGROW>
        end
    end

    for i = 1:numel(algorithm_names)
        if ~any(strcmp(sorted_algorithm_names, algorithm_names{i}))
            sorted_algorithm_names{end+1, 1} = algorithm_names{i}; %#ok<AGROW>
        end
    end
end

function sorted_data_files = sort_data_files(data_files)
% 按设备数、任务数、总操作数的数值大小排序。

    sort_keys = zeros(numel(data_files), 3);
    for i = 1:numel(data_files)
        token = regexp(data_files{i}, '^(?<edge>\d+)_(?<task>\d+)_(?<operation>\d+)\.mat$', 'names', 'once');
        if isempty(token)
            sort_keys(i, :) = [inf, inf, inf];
        else
            sort_keys(i, :) = [str2double(token.edge), str2double(token.task), str2double(token.operation)];
        end
    end

    [~, order] = sortrows(sort_keys, [1 2 3]);
    sorted_data_files = data_files(order);
end
